//
//  KIMTests.m
//  KIMTests
//
//  Created by Denis Kutlubaev on 03.08.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "KIMTests.h"
#import "ClientInfo.h"
#import "EJRegistrator.h"

@interface KIMTests() <EJRegistratorDelegate>
{
    BOOL _callbackInvoked;
}
@property(nonatomic, strong) EJRegistrator *registrator;

@end


@implementation KIMTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)test
{
    NSDate *fiveSecondsFromNow = [NSDate dateWithTimeIntervalSinceNow:5.0];
    
    ClientInfo *clientInfo = [ClientInfo shared];
    clientInfo.roughPhoneNumber = @"(925) 060-1111";
    
    STAssertNotNil(clientInfo.phone, @"Phone must not be nil");
    
    self.registrator = [[EJRegistrator alloc] init];
    BOOL success = [self.registrator registerClientWithDelegate:self];
    
    STAssertTrue(success, @"Can't connect to Ejabberd server");
    
    [[NSRunLoop currentRunLoop] runUntilDate:fiveSecondsFromNow];
    
    STAssertTrue(_callbackInvoked,
                 @"Delegate should send registratorFailedToRegisterClient or registratorDidRegisterClient. Check Ejabberd status.");
}


#pragma mark - EjabberdRegistratorDelegate

- (void)registratorFailedToRegisterClient
{
    _callbackInvoked = YES;
    STFail(@"Connection to ejabberd server failed.");
}


- (void)registratorDidRegisterClient
{
    _callbackInvoked = YES;
    NSLog(@"Ejabberd Registrator did register client.");
}

@end
