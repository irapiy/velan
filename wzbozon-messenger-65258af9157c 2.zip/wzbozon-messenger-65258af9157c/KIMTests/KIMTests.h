//
//  KIMTests.h
//  KIMTests
//
//  Created by Denis Kutlubaev on 03.08.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface KIMTests : SenTestCase

@end
