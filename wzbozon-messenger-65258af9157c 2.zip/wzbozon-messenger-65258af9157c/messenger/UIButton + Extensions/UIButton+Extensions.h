//
//  UIButton+Extensions.h
//  MailClient
//
//  Created by Denis Kutlubaev on 16.01.13.
//  Copyright (c) 2013 1Forma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Extensions)

@property(nonatomic, assign) UIEdgeInsets hitTestEdgeInsets;

@end
