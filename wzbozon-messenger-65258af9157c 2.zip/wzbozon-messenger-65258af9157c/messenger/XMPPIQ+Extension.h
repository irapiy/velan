//
//  XMPPIQ+Extension.h
//  messenger
//
//  Created by Denis Kutlubaev on 01.08.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "XMPPIQ.h"

@interface XMPPIQ (Extension)

- (NSError *)errorFromXMPPIQ;

@end
