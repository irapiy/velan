//
//  AppDelegate.h
//  messenger
//
//  Created by Denis Kutlubaev on 22.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FMDatabase;
@class WebViewController;
@class AudioViewController;
@class ChatViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UITabBarController *tabBarController;
@property (strong, nonatomic) UINavigationController *chatsNavController;
@property (nonatomic, strong) NSString *databaseName;
@property (nonatomic, strong) NSString *databasePath;
@property (nonatomic, strong) NSString *documentsDir;
@property (nonatomic, strong) FMDatabase *db;
@property (nonatomic) BOOL isActive;
@property (strong, nonatomic) WebViewController *webViewController;
@property (strong, nonatomic) AudioViewController *audioViewController;
@property (strong, nonatomic) ChatViewController *chatViewController;

@end


