//
//  XMPPContact.m
//  messenger
//
//  Created by Denis Kutlubaev on 27.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "MSGContact.h"
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"

@implementation MSGContact


- (id)init
{
    self = [super init];
    
    if (self) {
        
    }
    
    return self;
}


#pragma mark - Database operations

- (id)initWithContactID:(NSInteger)contactID jidString:(NSString *)jidString phone:(NSString *)phone name:(NSString *)name lastName:(NSString *)lastName company:(NSString *)company status:(NSString *)status imageName:(NSString *)imageName
{
    self = [super init];
    
    if (self) {
        
        _contactID = contactID;
        _jidString = jidString;
        _phone = phone;
        _name = name;
        _lastName = lastName;
        _company = company;
        _status = status;
        _imageName = imageName;
        
    }
    
    return self;
}


- (XMPPJID *)jid
{
    if (_jid == nil) {
        
        _jid = [XMPPJID jidWithString:_jidString];
        
    }
    
    return _jid;
}


- (BOOL)isOnline
{
    _isOnline = [[self.presence type] isEqualToString:@"available"];
    return _isOnline;
}


- (BOOL)isBusy
{
    _isBusy = [self.presence.status isEqualToString:LOCS(@"Busy")] || [self.presence.status isEqualToString:@"Busy"];
    return _isBusy;
}


- (BOOL)addToDb
{
    if ( ! [AppDel.db open] ) {
        return NO;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"INSERT INTO contacts (jid, phone, name, last_name, company, status, image_name) VALUES (?, ?, ?, ?, ?, ?, ?)" withArgumentsInArray:@[self.jidString, self.phone, self.name, self.lastName, self.company, self.status, self.imageName]];
    
    [AppDel.db close];
    
    return result;
}


- (BOOL)deleteFromDb
{
    if ( ! [AppDel.db open] ) {
        return NO;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"DELETE FROM contacts WHERE contact_id = ?" withArgumentsInArray:@[@(self.contactID)]];
    
    [AppDel.db close];
    
    return result;
}


+ (NSArray *)retrieveFromDb
{
    NSMutableArray *temp = [NSMutableArray new];
    
    if ( ! [AppDel.db open] ) {
        return nil;
    }
    
    NSMutableString *sql = [NSMutableString new];
    [sql appendString:@"SELECT * FROM contacts"];
    
    FMResultSet *rs = [AppDel.db executeQuery:sql];
    while ( [rs next] ) {
        
        MSGContact *contact = [[MSGContact alloc] initWithContactID:[rs intForColumn:@"contact_id"]
                                                          jidString:[rs stringForColumn:@"jid"]
                                                              phone:[rs stringForColumn:@"phone"]
                                                               name:[rs stringForColumn:@"name"]
                                                           lastName:[rs stringForColumn:@"last_name"]
                                                            company:[rs stringForColumn:@"company"]
                                                             status:[rs stringForColumn:@"status"]
                                                          imageName:[rs stringForColumn:@"image_name"]];
		[temp addObject:contact];
        
    }
    
    [rs close];
    
    [AppDel.db close];
    
	return temp;
}


- (NSArray *)messages
{
    NSString *jidUser = [[ClientInfo shared] jidString];
	
    NSMutableArray *temp = [NSMutableArray new];
    
    [temp addObjectsFromArray:[MSGMessage retrieveFromDbWithJIDFrom:self.jidString JIDTo:jidUser]];
    [temp addObjectsFromArray:[MSGMessage retrieveFromDbWithJIDFrom:jidUser JIDTo:self.jidString]];
    
    NSSortDescriptor *dateDescriptor = [[NSSortDescriptor alloc] initWithKey:@"dateDelivered" ascending:YES];
    _messages = [temp sortedArrayUsingDescriptors:@[dateDescriptor]];
    
    return _messages;
}


#pragma mark - Other methods

- (NSString *)entireChat
{
    NSMutableString *string = [NSMutableString new];
    
    for (MSGMessage *message in self.messages) {
        XMPPJID *tempJID = [XMPPJID jidWithString:message.jidFrom];
        [string appendFormat:@"%@: %@\n", tempJID.user, allTrim(message.messageBody)];
    }
    
    return string;
}


- (void)setPresence:(XMPPPresence *)presence
{
    _presence = presence;
    _status = presence.status;
    
    if (_status == nil) return;
    
    if ( ! [AppDel.db open] ) {
        return;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"UPDATE contacts SET status = ? WHERE jid = ?" withArgumentsInArray:@[self.status, self.jid]];

    QuickCheck(result);
    
    [AppDel.db close];    
}


- (NSString *)jidString
{
    if (! _jidString) {
        
        _jidString = [NSString stringWithFormat:@"%@@%@", self.phone, EJABBERD_HOST_NAME];
        
    }
    
    return _jidString;
}


- (NSString *)fullName
{
    if (! _fullName) {
        
        if (! self.lastName) {
            self.lastName = @"";
        }
    
        _fullName = [NSString stringWithFormat:@"%@ %@", self.name, self.lastName];
        
    }
    
    return _fullName;
}


- (NSXMLElement *)contactAdditionIQStanza
{
//    <iq from='juliet@example.com/balcony' type='set' id='roster_2'>
//    <query xmlns='jabber:iq:roster'>
//    <item jid='nurse@example.com'
//      name='Nurse'>
//    <group>Servants</group>
//    </item>
//    </query>
//    </iq>
    
    NSXMLElement *iqStanza = [NSXMLElement elementWithName: @"iq"];
    [iqStanza addAttributeWithName: @"type" stringValue: @"set"];
    [iqStanza addAttributeWithName: @"from" stringValue: [[ClientInfo shared] jidString]];
    NSXMLElement *queryElement = [NSXMLElement elementWithName: @"query" xmlns: @"jabber:iq:roster"];
    [iqStanza addChild: queryElement];
    NSXMLElement *item = [NSXMLElement elementWithName:@"item"];
    [item addAttributeWithName:@"jid" stringValue:self.jidString];
    [item addAttributeWithName:@"name" stringValue:self.fullName];
    NSXMLElement *group = [NSXMLElement elementWithName:@"group" stringValue:@"KIM"];
    [item addChild:group];
    [queryElement addChild:item];
    
    return iqStanza;
}


- (XMPPPresence *)subscribePresence
{
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"subscribe"];
    NSXMLElement *to = [NSXMLElement elementWithName:@"to"];
    [to setStringValue:self.jidString];
    [presence addChild:to];
    
    NSXMLElement *ask = [NSXMLElement elementWithName:@"ask"];
    [ask setStringValue:@"subscribe"];
    [presence addChild:ask];
    
    return presence;
}


- (XMPPPresence *)subscribedPresence
{
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"subscribed"];
    NSXMLElement *to = [NSXMLElement elementWithName:@"to"];
    [to setStringValue:self.jidString];
    [presence addChild:to];
    
    NSXMLElement *ask = [NSXMLElement elementWithName:@"ask"];
    [ask setStringValue:@"subscribed"];
    [presence addChild:ask];
    
    return presence;
}


@end
