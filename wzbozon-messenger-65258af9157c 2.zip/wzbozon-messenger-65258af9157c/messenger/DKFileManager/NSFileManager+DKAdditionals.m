//
//  NSFileManager+DKAdditionals.m
//
//  Created by Denis Kutlubaev on 27.04.12.
//  Copyright (c) 2012 Denis Kutlubaev. All rights reserved.
//

#import "NSFileManager+DKAdditionals.h"

@implementation NSFileManager (DKAdditionals)

- (NSArray*)retrieveAllFileNamesFromFolder:(NSString*)folderInBundle
{
    NSError *error = NULL;
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *folderPath = [[bundle resourcePath] stringByAppendingPathComponent:folderInBundle];
    NSLog(@"folder Path:%@", folderPath);
    return [self contentsOfDirectoryAtPath:folderPath error:&error];
}


- (void) createIfNotExistsInUserDocumentsTextFile:(NSString *)fileName {
    // File name should not contain an extension (txt)
    // Documents folder path
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); 
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    //create a path for the new text file
    NSString *filePath = [NSString stringWithFormat:@"%@/%@.txt", documentsDirectory, fileName];
    
    // If file already exists, delete & recreate a new one
    if ([fm fileExistsAtPath: filePath ] == YES) {
        [fm removeItemAtPath:filePath error:nil];
        [fm createFileAtPath:filePath contents:nil attributes:nil]; 
    }
    else
    {
        NSLog (@"File not found. Creating file ...");
        [fm createFileAtPath:filePath contents:nil attributes:nil];
    }
}

- (void)createIfNotExistsInUserDocumentsFolder:(NSString*)folderName {
    NSError *error = NULL;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); 
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *fullPath = [documentsDirectory stringByAppendingPathComponent:folderName];
    NSLog(@"Full Path to the folder = %@", fullPath);
    if (![self fileExistsAtPath:fullPath])
        [self createDirectoryAtPath:fullPath withIntermediateDirectories:NO attributes:nil error:&error];
    if (error)
        NSLog(@"Error while creating folder: %@ with error text: %@", folderName, [error description]);
}

- (NSString*)savePhoto:(UIImage*)photo toFolder:(NSString*)folderName {
    // Saves photo to folder in documents of the user
    // Create path to output image
    NSString *documentsDirectory = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *folderPath = [documentsDirectory stringByAppendingPathComponent:folderName];
    
    // Generate file name with current time
    NSString *fileName = [NSFileManager generateFileNameWithExtension:@"png"];
    
    NSString *fullPath = [folderPath stringByAppendingPathComponent:fileName];
    
    [UIImagePNGRepresentation(photo) writeToFile:fullPath atomically:YES];
    
    return fileName;
}

- (void)logContentsOfFolderInDocuments:(NSString*)folderName {
    NSError *error = NULL;
    
    // Create folder path
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); 
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *folderPath = [documentsDirectory stringByAppendingPathComponent:folderName];
    
    // Write out the contents of the directory to console
    NSLog(@"%@ directory: %@", folderName, [self contentsOfDirectoryAtPath:folderPath error:&error]);
    
    // Handle errors
    if (error)
        NSLog(@"Error while logging contents of folder: %@ with error text: %@", folderName, [error description]);
}

- (void)logContentsOfDocumentsFolder {
    
    NSError *error = NULL;
    
    // Point to Document directory
    NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    
    // Write out the contents of Documents directory to console
    NSLog(@"Documents directory: %@", [self contentsOfDirectoryAtPath:documentsDirectory error:&error]);
    
    // Handle errors
    if (error)
        NSLog(@"Error while logging contents of documents folder with error text: %@", [error description]);
}

- (NSMutableArray*)retrieveAllImagesFromFolder:(NSString*)folderName {
    NSMutableArray *imagesArray = [[NSMutableArray alloc] init];
    
    // Create folder path
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); 
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *folderPath = [documentsDirectory stringByAppendingPathComponent:folderName];
    
    // Read images
    NSError *error = NULL;
    NSArray *fileNames = [self contentsOfDirectoryAtPath:folderPath error:&error]; 
    NSString *fullPath;
    for (NSString *fileName in fileNames) {
        fullPath = [folderPath stringByAppendingPathComponent:fileName];
        UIImage *image = [UIImage imageWithContentsOfFile:fullPath];
        [imagesArray addObject:image];
    }
    
    NSLog(@"Count of images in folder:%@ = %d", folderName, [imagesArray count]);
    
    return imagesArray;
}

- (NSMutableArray*)retrieveAllImagesFromBundlePath:(NSString*)folderInBundle {
    
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *folderPath = [[bundle resourcePath] stringByAppendingPathComponent:folderInBundle];
    NSLog(@"folder Path:%@", folderPath);
    
    NSArray* imagePaths = [[NSBundle mainBundle] pathsForResourcesOfType:@"jpg" inDirectory:folderInBundle];
    NSMutableArray *imagesArray = [[NSMutableArray alloc] initWithCapacity:imagePaths.count];
    for (NSString* path in imagePaths)
    {
        [imagesArray addObject:[UIImage imageWithContentsOfFile:path]];
    }
    
    NSLog(@"Count of images in folder:%@ = %d", folderInBundle, [imagesArray count]);
    
    return imagesArray;
}


+ (NSString*)generateFileNameWithExtension:(NSString *)extensionString
{
    // Extension string is like @"png"
    
    NSDate *time = [NSDate date];
    NSDateFormatter* df = [NSDateFormatter new];
    [df setDateFormat:@"dd-MM-yyyy-hh-mm-ss"];
    NSString *timeString = [df stringFromDate:time];
    NSString *fileName = [NSString stringWithFormat:@"File-%@.%@", timeString, extensionString];
    
    return fileName;
}


+ (NSString *)fileSizeStringWithSize:(NSInteger)size shortVersion:(BOOL)shortVersion
{
    // Вычисление размера файла вложения
    NSString *sizeString;
    CGFloat f;
    
    if (size < 1024) {
        // Меньше килобайта
        sizeString = [NSString stringWithFormat:@"%d %@", size, @"bytes"];
    }
    else if ((size >= 1024)&&(size < (1024*1024))) {
        // Больше или равно килобайту но меньше мегабайта
        f = size / 1024.0f;
        sizeString = [NSString stringWithFormat:@"%.0f %@", f, @"kilobytes"];
    }
    else if (size >= (1024*1024)) {
        // Больше или равно мегабайту
        f = size / (1024.0f*1024.0f);
        sizeString = [NSString stringWithFormat:@"%.0f %@", f, @"megabytes"];
    }
    
    if (! shortVersion) {
        sizeString = [NSString stringWithFormat:@"%@ %@", @"Size:", sizeString];
    }
    
    return sizeString;
}


@end
