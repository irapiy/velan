//
//  NSFileManager+DKAdditionals.h
//  FLORApp
//
//  Created by Denis Kutlubaev on 27.04.12.
//  Copyright (c) 2012 Denis Kutlubaev. All rights reserved.
//
// Category to extend NSFileManager class

#import <Foundation/Foundation.h>

@interface NSFileManager (DKAdditionals)

- (void)createIfNotExistsInUserDocumentsFolder:(NSString*)folderName;

- (void)createIfNotExistsInUserDocumentsTextFile:(NSString *)fileName;

- (NSString*)savePhoto:(UIImage*)photo toFolder:(NSString*)folderName;

- (void)logContentsOfFolderInDocuments:(NSString*)folderName;

- (void)logContentsOfDocumentsFolder;

- (NSArray*)retrieveAllImagesFromFolder:(NSString*)folderName;

- (NSMutableArray*)retrieveAllImagesFromBundlePath:(NSString*)folderInBundle;

- (NSArray*)retrieveAllFileNamesFromFolder:(NSString*)folderInBundle;

+ (NSString*)generateFileNameWithExtension:(NSString*)extensionString;

+ (NSString *)fileSizeStringWithSize:(NSInteger)size shortVersion:(BOOL)shortVersion;

@end
