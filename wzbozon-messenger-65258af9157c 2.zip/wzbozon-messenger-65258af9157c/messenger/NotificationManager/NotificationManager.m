//
//  NotificationManager.m
//  SahihAlBuhari
//
//  Created by Denis Kutlubaev on 17.03.13.
//
//

#import "NotificationManager.h"

@implementation NotificationManager


+ (NotificationManager *)sharedManager
{
    static NotificationManager *sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[NotificationManager alloc] init];
    });
    
    return sharedManager;
}


- (void)setLocalNotificationForMessage:(MSGMessage *)message
{
    // Установка напоминания
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle:NSDateFormatterLongStyle];
    [dateFormatter setTimeStyle:NSDateFormatterLongStyle];
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    NSDate *nowDate = [NSDate date];
    NSDateComponents *nowDateComponents = [gregorian components:(NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit | NSHourCalendarUnit  | NSMinuteCalendarUnit | NSSecondCalendarUnit) fromDate:nowDate];
    
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    [dateComponents setDay:[nowDateComponents day]];
    [dateComponents setMonth:[nowDateComponents month]];
    [dateComponents setYear:[nowDateComponents year]];
    [dateComponents setHour:[nowDateComponents hour]];
    [dateComponents setMinute:[nowDateComponents minute]];
    [dateComponents setSecond:[nowDateComponents second] + 1];
    
    NSDate *notificationDate = [gregorian dateFromComponents:dateComponents];
    NSString *dateString = [dateFormatter stringFromDate:notificationDate];
    NSLog(@"Fire date:%@", dateString);
    
    UILocalNotification *localNotification = [[UILocalNotification alloc] init];
    localNotification.timeZone = [NSTimeZone defaultTimeZone];
    localNotification.alertAction = @"Посмотреть";
    [localNotification setSoundName:UILocalNotificationDefaultSoundName];
    
    localNotification.fireDate = notificationDate;
    
    XMPPJID *jid = [XMPPJID jidWithString:message.jidFrom];
    
    localNotification.alertBody = [NSString stringWithFormat:@"%@: %@", jid.user, message.messageBody];
    NSDictionary *userInfoDic = [NSDictionary dictionaryWithObjects:@[message.jidFrom, message.messageBody] forKeys:@[NotificationInfoKeyFrom, NotificationInfoKeyMessage]];
    [localNotification setUserInfo:userInfoDic];
    [localNotification setSoundName:@"echo_affirm1.wav"];
    
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
}


- (void)removeAllLocalNotifications
{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}


@end
