//
//  NotificationManager.h
//  SahihAlBuhari
//
//  Created by Denis Kutlubaev on 17.03.13.
//
//

#import <Foundation/Foundation.h>

@interface NotificationManager : NSObject

+ (NotificationManager*)sharedManager;

- (void)setLocalNotificationForMessage:(MSGMessage *)message;

- (void)removeAllLocalNotifications;

@end
