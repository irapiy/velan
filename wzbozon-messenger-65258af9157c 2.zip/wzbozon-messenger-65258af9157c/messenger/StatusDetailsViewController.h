//
//  AddStatusViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 17.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StatusDetailsViewController : UIViewController

@property (nonatomic, strong) NSString *status;

@end
