//
//  AudioViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 02.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import "UserAudioPickerController.h"

@interface AudioViewController : UIViewController <MPMediaPickerControllerDelegate, UserAudioPickerControllerDelegate, UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) MPMusicPlayerController *musicPlayer;
@property (nonatomic, strong) IBOutlet UIButton *playPauseButton;
@property (nonatomic, strong) IBOutlet UIButton *prevButton;
@property (nonatomic, strong) IBOutlet UIButton *nextButton;
@property (nonatomic, strong) IBOutlet UIButton *iPodLibButton;
@property (nonatomic, strong) IBOutlet UIButton *userLibButton;
@property (nonatomic, strong) IBOutlet UILabel *songLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *trackNoLabel;
@property (weak, nonatomic) IBOutlet UILabel *repeatLabel;
@property (nonatomic, strong) IBOutlet UIImageView *artworkImageView;
@property (nonatomic, strong) IBOutlet UISlider *volumeSlider;
@property (nonatomic, strong) IBOutlet UITableView *tableView;

- (IBAction)playOrPauseMusic:(id)sender;
- (IBAction)playNextSong:(id)sender;
- (IBAction)playPreviousSong:(id)sender;
- (IBAction)openMediaPicker:(id)sender;
- (IBAction)volumeSliderChanged:(id)sender;
- (IBAction)openUserLibrary:(id)sender;

- (void)playAudioFile:(NSString *)fileName;



@end
