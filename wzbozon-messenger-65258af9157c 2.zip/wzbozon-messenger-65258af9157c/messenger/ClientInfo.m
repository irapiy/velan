//
//  ClientInfo.m
//  messenger
//
//  Created by Denis Kutlubaev on 30.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "ClientInfo.h"
#import <AdSupport/ASIdentifierManager.h>
#import "MD5Hasher.h"
#import <AddressBook/AddressBook.h>
#import "MySQLConnection.h"


static ClientInfo *shared;


@implementation ClientInfo

+ (ClientInfo *)shared
{
    static dispatch_once_t once;
    
    dispatch_once(&once, ^{
        
        shared = [[ClientInfo alloc] init];
        
    });
    
    return shared;
}


- (XMPPJID *)jid
{
    if (! _jid) {
        
        _jid = [XMPPJID jidWithString:self.jidString];
    }
    
    return _jid;
}


- (NSString *)phone
{
    if (! _phone) {
        
        if (self.roughPhoneNumber) {
            _phone = [NSString stringWithFormat:@"%d%@", 7, self.roughPhoneNumber];
            _phone = [self cleanPhoneNumber:_phone];
        }
        else {
            _phone = UD_OBJECT(UDKeyPhone);
        }
    
    }
    
    return _phone;
}


- (NSString *)password
{
    if (! _password) {
        
        _password = UD_OBJECT(UDKeyPassword);
        
        if (_password == nil) {
            _password = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
            _password = [MD5Hasher md5:_password];
        }

    }
    
    return _password;
}


- (NSString *)jidString
{
    if (! _jidString) {
        
        _jidString = [NSString stringWithFormat:@"%@@%@", self.phone, EJABBERD_HOST_NAME];
    }
    
    return _jidString;
}


- (NSString *)cleanPhoneNumber:(NSString *)phoneNumber
{
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    
    NSArray *array = [phoneNumber componentsSeparatedByCharactersInSet :[NSCharacterSet whitespaceCharacterSet] ];
    phoneNumber = [array componentsJoinedByString:@""];
    
    return phoneNumber;
}


- (void)savePhoneAndPassword
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:self.phone forKey:UDKeyPhone];
    [ud setObject:self.password forKey:UDKeyPassword];
    [ud synchronize];
}


- (NSXMLElement *)registrationIQStanza
{
    NSXMLElement *iqStanza = [NSXMLElement elementWithName: @"iq"];
    [iqStanza addAttributeWithName: @"type" stringValue: @"set"];
    NSXMLElement *queryElement = [NSXMLElement elementWithName: @"query" xmlns: @"jabber:iq:register"];
    [iqStanza addChild: queryElement];
    NSXMLElement *username = [NSXMLElement elementWithName:@"username" stringValue:self.phone];
    NSXMLElement *password = [NSXMLElement elementWithName:@"password" stringValue:self.password];
    NSXMLElement *email = [NSXMLElement elementWithName:@"email" stringValue:self.email];
    NSXMLElement *name = [NSXMLElement elementWithName:@"name" stringValue:self.name];
    [queryElement addChild:username];
    [queryElement addChild:password];
    [queryElement addChild:name];
    [queryElement addChild:email];
    
    return iqStanza;
}


- (NSArray *)contacts
{
    if ([_contacts count] == 0) {
        
        _contacts = [MSGContact retrieveFromDb];
        
    }
    
    return _contacts;
}


- (NSArray *)activeContacts
{
    NSMutableArray *temp = [NSMutableArray new];
    
    for (MSGContact *contact in self.contacts) {
        if ([contact.messages count] > 0) {
            [temp addObject:contact];
        }
    }
    
    return temp;
}


- (void)createRosterFromAddressBook
{
    // Получение адресной книги (имена + номера телефонов) и отправка на сервер (пока не знаю зачем)
    CFErrorRef *error = NULL;
    ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, error);
    
    if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined) {
        ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error) {
            // First time access has been granted, add the contact
            [self continueCreatingRosterFromAddressBook];
        });
    }
    else if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized) {
        // The user has previously given access, add the contact
        [self continueCreatingRosterFromAddressBook];
    }
    else {
        // The user has previously denied access
        // Send an alert telling user to change privacy setting in settings app
        return;
    }
}


- (void)continueCreatingRosterFromAddressBook
{
    CFErrorRef *error = NULL;
    NSInteger countryCode = 7;
    ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, error);
    CFArrayRef allPeople = ABAddressBookCopyArrayOfAllPeople(addressBook);
    CFIndex numberOfPeople = ABAddressBookGetPersonCount(addressBook);
    
    for(int i = 0; i < numberOfPeople; i++) {
        
        ABRecordRef person = CFArrayGetValueAtIndex( allPeople, i );
        
        NSString *firstName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonFirstNameProperty));
        NSString *lastName = (__bridge NSString *)(ABRecordCopyValue(person, kABPersonLastNameProperty));
        NSString *name = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
        NSLog(@"Name:%@", name);
        
        ABMultiValueRef phoneNumbers = ABRecordCopyValue(person, kABPersonPhoneProperty);
        
        for (CFIndex i = 0; i < ABMultiValueGetCount(phoneNumbers); i++) {
            NSString *phoneNumber = (__bridge_transfer NSString *) ABMultiValueCopyValueAtIndex(phoneNumbers, i);
            phoneNumber = [NSString stringWithFormat:@"%d%@", countryCode, phoneNumber];
            phoneNumber = [self cleanPhoneNumber:phoneNumber];
            NSLog(@"phone:%@", phoneNumber);
            
            NSString *command = @"addcontact";
            NSMutableDictionary *params =[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                          command, @"command",
                                          phoneNumber, @"contactphone",
                                          name, @"name",
                                          nil];
            
            [[MySQLConnection shared] commandWithParams:params
                                           onCompletion:^(NSDictionary *json) {
                                               
                                               if ( [json objectForKey:@"error"]==nil ) {
                                                   
                                                   // Добавляем только тех пользователей, которые есть в roster
                                                   NSDictionary* res = [[json objectForKey:@"result"] objectAtIndex:0];
                                                   NSString *userIDFoundInEjabberdForThisContact = [res objectForKey:@"user_id"];
                                                   NSLog(@"user id:%@", userIDFoundInEjabberdForThisContact);
                                                   //if ( userIDFoundInEjabberdForThisContact ) {
                                                       
                                                       MSGContact *contact = [[MSGContact alloc] init];
                                                       contact.phone = phoneNumber;
                                                       contact.name = name;
                                                       [[EJConnection shared] addContactToRoster:contact];
                                                       
                                                   //}
                                               } else {
                                                   //error
                                                   [[[UIAlertView alloc] initWithTitle:@"Error"
                                                                               message:[json objectForKey:@"error"]
                                                                              delegate:nil
                                                                     cancelButtonTitle:@"Close"
                                                                     otherButtonTitles: nil] show];
                                               }
                                           }];
            
        }
        
        NSLog(@"=============================================");
    }
}


/*- (void)continueCreatingRosterFromAddressBook
{
    NSString *name = @"Dennis Kutlubaev";
    NSString *phoneNumber = @"7(925)-060-56-86";
    phoneNumber = [self cleanPhoneNumber:phoneNumber];
            
    NSString *command = @"addcontact";
    NSMutableDictionary *params =[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                  command, @"command",
                                  phoneNumber, @"contactphone",
                                  name, @"name",
                                  nil];
    
    [[MySQLConnection shared] commandWithParams:params
                                   onCompletion:^(NSDictionary *json) {
                                       
                                       if ( [json objectForKey:@"error"]==nil ) {
                                           
                                           // Добавляем только тех пользователей, которые есть в roster
                                           NSDictionary* res = [[json objectForKey:@"result"] objectAtIndex:0];
                                           NSLog(@"user id:%@", [res objectForKey:@"user_id"]);
                                           if ([[res objectForKey:@"user_id"] intValue] != 0) {
                                           
                                               MSGContact *contact = [[MSGContact alloc] init];
                                               contact.phone = phoneNumber;
                                               contact.name = name;
                                               [[EJConnection shared] addContactToRoster:contact];
                                           
                                           }
                                           
                                       } else {
                                           
                                           [[[UIAlertView alloc] initWithTitle:@"Error"
                                                                       message:[json objectForKey:@"error"]
                                                                      delegate:nil
                                                             cancelButtonTitle:@"Close"
                                                             otherButtonTitles: nil] show];
                                           
                                       }
                                   }];
}*/



@end
