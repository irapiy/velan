//
//  CustomCellBackground.m
//  Nanotechnology
//
//  Created by Denis Kutlubaev on 02.02.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "CustomCellBackground.h"
#import "Common.h"

@implementation CustomCellBackground

- (id)initWithFrame:(CGRect)frame andBackgroundColor:(UIColor*)bgColor hasBorderStroke:(BOOL)hasBorderStroke
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _bgColor = bgColor;
        _hasBorderStroke = hasBorderStroke;
        
    }
    return self;
}


- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGRect paperRect = self.bounds;
    
    CGContextSetFillColorWithColor(context, _bgColor.CGColor);
    CGContextFillRect(context, paperRect);
    
    // Обводка
    if (_hasBorderStroke) {
        CGRect strokeRect = paperRect;
        strokeRect.size.height -= 1;
        strokeRect = rectFor1PxStroke(strokeRect);
        CGContextSetStrokeColorWithColor(context, [UIColor whiteColor].CGColor);
        CGContextSetLineWidth(context, 1.0);
        CGContextStrokeRect(context, strokeRect);
        
        
        // Отделяющая линия
        CGPoint startPoint = CGPointMake(paperRect.origin.x,
                                         paperRect.origin.y + paperRect.size.height - 1);
        CGPoint endPoint = CGPointMake(paperRect.origin.x + paperRect.size.width - 1,
                                       paperRect.origin.y + paperRect.size.height - 1);
        
        draw1PxStroke(context, startPoint, endPoint, RGB(0xD9D9D9).CGColor);
        
        
        startPoint.y -= 1;
        endPoint.y -= 1;
        draw1PxStroke(context, startPoint, endPoint, _bgColor.CGColor);
    }
}


@end
