//
//  CustomCellBackground.h
//  Nanotechnology
//
//  Created by Denis Kutlubaev on 02.02.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellBackground : UIView

@property (nonatomic, strong) UIColor *bgColor;
@property (nonatomic) BOOL hasBorderStroke;

- (id)initWithFrame:(CGRect)frame andBackgroundColor:(UIColor*)bgColor hasBorderStroke:(BOOL)hasBorderStroke;

@end
