//
//  EjabberdRegistrator.h
//  messenger
//
//  Created by Denis Kutlubaev on 30.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

// Этот класс предназначен для регистрации пользователя
// Он использует логин и пароль по умолчанию для соединения с сервером и регистрирует клиента по номеру телефона

#import <Foundation/Foundation.h>

@class ClientInfo;


@protocol EJRegistratorDelegate <NSObject>

- (void)registratorDidRegisterClient;
- (void)registratorFailedToRegisterClient;

@end


@interface EJRegistrator : NSObject

// XMPP поток, предназначенный для регистрации пользователя
@property (strong, nonatomic) XMPPStream *xmppStream;

@property (unsafe_unretained, nonatomic) id <EJRegistratorDelegate> delegate;


+ (EJRegistrator *)sharedRegistrator;


- (BOOL)registerClientWithDelegate:(id <EJRegistratorDelegate>)delegate;

@end
