//
//  ContactsViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 25.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactsTableViewController : UITableViewController <UISearchBarDelegate, UISearchDisplayDelegate>

@property (nonatomic) BOOL selectionMode;

@end
