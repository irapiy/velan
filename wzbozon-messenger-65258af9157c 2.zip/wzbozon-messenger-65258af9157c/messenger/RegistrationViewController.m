//
//  RegistrationViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 25.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "RegistrationViewController.h"

@interface RegistrationViewController ()

@property(nonatomic, strong) EJRegistrator *registrator;

@end

@implementation RegistrationViewController


#pragma mark - View lifecycle

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        // Custom initialization
        
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectionFinished) name:CONNECTION_FINISHED object:nil];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [_loginField becomeFirstResponder];
}


#pragma mark - Other methods

- (IBAction)signInClicked:(id)sender
{
    ClientInfo *clientInfo = [ClientInfo shared];
    clientInfo.roughPhoneNumber = _loginField.text;
    [[MySQLConnection shared] loginUserWithDelegate:self];
}


- (void)dismiss
{
    AppDel.window.rootViewController = AppDel.tabBarController;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    int length = [self getLength:textField.text];
    
    if(length == 10)
    {
        if(range.length == 0)
            return NO;
    }
    
    if(length == 3)
    {
        NSString *num = [self formatNumber:textField.text];
        textField.text = [NSString stringWithFormat:@"(%@) ",num];
        if(range.length > 0)
            textField.text = [NSString stringWithFormat:@"%@",[num substringToIndex:3]];
    }
    else if(length == 6)
    {
        NSString *num = [self formatNumber:textField.text];
        textField.text = [NSString stringWithFormat:@"(%@) %@-",[num  substringToIndex:3],[num substringFromIndex:3]];
        if(range.length > 0)
            textField.text = [NSString stringWithFormat:@"(%@) %@",[num substringToIndex:3],[num substringFromIndex:3]];
    }
    
    return YES;
}


- (NSString*)formatNumber:(NSString*)mobileNumber
{
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    NSLog(@"%@", mobileNumber);
    
    int length = [mobileNumber length];
    if(length > 10)
    {
        mobileNumber = [mobileNumber substringFromIndex: length-10];
        NSLog(@"%@", mobileNumber);
        
    }
    return mobileNumber;
}


- (int)getLength:(NSString*)mobileNumber
{
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    int length = [mobileNumber length];
    
    return length;
}


#pragma mark - MySQLConnectionDelegate

// Login
- (void)userDidLogin
{
    [[ClientInfo shared] setLoggedIn:YES];
    [[ClientInfo shared] savePhoneAndPassword];
    
    // Пользователь уже есть в базе, но нужно его регистрировать в Ejabberd все равно
    self.registrator = [[EJRegistrator alloc] init];
    [self.registrator registerClientWithDelegate:self];
}


- (void)userFailedToLogin
{
    [[ClientInfo shared] setLoggedIn:NO];
    [[MySQLConnection shared] registerUserWithDelegate:self];
}


// Register
- (void)userDidRegister
{
    [[ClientInfo shared] setRegistered:YES];
    self.registrator = [[EJRegistrator alloc] init];
    [self.registrator registerClientWithDelegate:self];
}


- (void)userFailedToRegister
{
    [[ClientInfo shared] setRegistered:NO];
}


#pragma mark - EjabberdRegistratorDelegate

- (void)registratorFailedToRegisterClient
{
    NSLog(@"Error: Ejabberd Registrator failed to register client.");
}


- (void)registratorDidRegisterClient
{
    [[ClientInfo shared] savePhoneAndPassword];
    NSLog(@"Ejabberd Registrator did register client.");
    [SVProgressHUD show];
    [[EJConnection shared] connect];
}


- (void)connectionFinished
{
    [[ClientInfo shared] createRosterFromAddressBook];
    [SVProgressHUD dismiss];
    [self dismiss];
}


@end
