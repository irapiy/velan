//
//  XMPPContact.h
//  messenger
//
//  Created by Denis Kutlubaev on 27.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDXML.h"

@class XMPPPresence;
@class XMPPJID;

@interface MSGContact : NSObject

@property (nonatomic) NSInteger contactID;
@property (nonatomic, strong) NSString *jidString;
@property (nonatomic, strong) NSString *phone;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *lastName;
@property (nonatomic, strong) NSString *company;
@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *imageName;
@property (nonatomic, strong) NSString *fullName;

// Subscription + Group

@property (nonatomic) BOOL isOnline;
@property (nonatomic) BOOL isBusy;
@property (nonatomic, strong) NSArray *messages;

@property (nonatomic, strong) XMPPPresence *presence;
@property (nonatomic, strong) XMPPJID *jid;


- (id)initWithContactID:(NSInteger)contactID jidString:(NSString *)jidString phone:(NSString *)phone name:(NSString *)name lastName:(NSString *)lastName company:(NSString *)company status:(NSString *)status imageName:(NSString *)imageName;

- (BOOL)addToDb;

- (BOOL)deleteFromDb;

+ (NSArray *)retrieveFromDb;

- (NSString *)entireChat;

- (NSXMLElement *)contactAdditionIQStanza;

- (XMPPPresence *)subscribePresence;
- (XMPPPresence *)subscribedPresence;

@end
