//
//  ViewController.h
//
//  Created by Alex Barinov
//  Project home page: http://alexbarinov.github.com/UIBubbleTableView/
//
//  This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//  To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/
//

#import <UIKit/UIKit.h>
#import "UIBubbleTableViewDataSource.h"
#import "HPGrowingTextView.h"

@class MSGContact;

@interface ChatViewController : UIViewController <UIBubbleTableViewDataSource, HPGrowingTextViewDelegate, UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIGestureRecognizerDelegate>

@property (nonatomic, strong) MSGContact *contact;
@property (nonatomic, strong) UIBubbleTableView *bubbleTable;
@property (nonatomic, strong) HPGrowingTextView *textView;
@property (nonatomic, strong) UIView *containerView;
@property (nonatomic) BOOL isVisible;

- (BOOL)isChatOpenedWith:(XMPPJID *)xmppJID;

@end
