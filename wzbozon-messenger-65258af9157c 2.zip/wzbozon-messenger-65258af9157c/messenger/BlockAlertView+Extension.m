//
//  BlockAlertView+Extension.m
//  messenger
//
//  Created by Denis Kutlubaev on 01.08.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "BlockAlertView+Extension.h"

@implementation BlockAlertView (Extension)

+ (void)showError:(NSString *)msg
{
    BlockAlertView *errorAlert = [[BlockAlertView alloc] initWithTitle:LOCS(@"Error") message:msg];
    [errorAlert setCancelButtonWithTitle:LOCS(@"Ok") block:nil];
    [errorAlert show];
}

@end
