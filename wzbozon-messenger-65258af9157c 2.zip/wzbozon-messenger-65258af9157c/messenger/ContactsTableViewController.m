//
//  ContactsViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 25.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "ContactsTableViewController.h"
#import "RegistrationViewController.h"
#import "ChatViewController.h"

@interface ContactsTableViewController ()
{
    NSArray *_tableData;
    UIRefreshControl *_refreshControl;
    
    UISearchBar *_searchBar;
    UISearchDisplayController *_searchDisplayController;
    NSMutableArray *_filteredTableData;
}
@end



@implementation ContactsTableViewController


#pragma mark - View lifecycle

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    
    if (self) {
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"111-user_active"]
                      withFinishedUnselectedImage:[UIImage imageNamed:@"111-user"]];
        self.title = LOCS(@"Contacts");
        
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _refreshControl = [[UIRefreshControl alloc] init];
    _refreshControl.tintColor = [UIColor blackColor];
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:LOCS(@"Pull to Refresh")];
    NSRange fullRange = NSMakeRange(0, [string length]);
    [string addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:fullRange];
    [string addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Georgia" size:17] range:fullRange];
    [_refreshControl setAttributedTitle:string];
    [_refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
    [self setRefreshControl:_refreshControl];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadData) name:CONTACTS_CHANGED object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectionFinished) name:CONNECTION_FINISHED object:nil];
    
    [self loadData];
    
    EJConnection *engine = [EJConnection shared];
    
    if (! [engine.xmppStream isConnected]) {
        self.navigationItem.title = LOCS(@"Connecting ...");
        [engine connect];
    }
    else {
        self.navigationItem.title = LOCS(@"Contacts");
    }
    
    // Search bar
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    _searchBar.delegate = self;
    _searchBar.placeholder = LOCS(@"Search");
    _searchBar.text = @"";
    _searchBar.tintColor = RGB(0x000000);
    _searchBar.autocorrectionType = UITextAutocorrectionTypeNo;
    self.tableView.tableHeaderView = _searchBar;
    
    _searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:_searchBar contentsController:self];
    _searchDisplayController.delegate = self;
    _searchDisplayController.searchResultsDataSource = self;
    _searchDisplayController.searchResultsDelegate = self;
    
    _filteredTableData = [NSMutableArray new];

}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [[EJConnection shared] resendMyPresence];
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger count = 0;
    
    if ( tableView == self.tableView ) {
        count = [_tableData count];
    }
    else if ( tableView == self.searchDisplayController.searchResultsTableView ) {
        count = [_filteredTableData count];
    }
    
    return count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        
    }
    
    MSGContact *contact = nil;
    if ( tableView == self.tableView ) {
        contact = _tableData[indexPath.row];
    }
    else if ( tableView == self.searchDisplayController.searchResultsTableView ) {
        contact = _filteredTableData[indexPath.row];
    }
    
    cell.textLabel.text = contact.fullName;
    cell.detailTextLabel.text = [contact.presence status];
    
    UIImageView *onlineView = [[UIImageView alloc] initWithFrame:CGRectMake(295, 26, 18, 18)];
    NSString *imageName = contact.isOnline ? @"Online" : @"Offline";
    
    if (contact.isBusy) imageName = @"Busy";
    
    [onlineView setImage:[UIImage imageNamed:imageName]];
    onlineView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [cell.contentView addSubview:onlineView];
    
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MSGContact *contact = nil;
    if ( tableView == self.tableView ) {
        contact = _tableData[indexPath.row];
    }
    else if ( tableView == self.searchDisplayController.searchResultsTableView ) {
        contact = _filteredTableData[indexPath.row];
    }
    
    AppDel.tabBarController.selectedIndex = 1;
    
    AppDel.chatViewController = [[ChatViewController alloc] initWithNibName:nil bundle:nil];
    AppDel.chatViewController.hidesBottomBarWhenPushed = YES;
    AppDel.chatViewController.contact = contact;
    [AppDel.chatsNavController pushViewController:AppDel.chatViewController animated:YES];
}


#pragma mark - UISearchDisplayControllerDelegate

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    if ([allTrim(searchString) length] == 0) return NO;
    
    [self filterContentForSearchText:searchString];
    
    return YES;
}


#pragma mark - Content Filtering

- (void)filterContentForSearchText:(NSString*)searchText
{
	[_filteredTableData removeAllObjects];
    
	for (MSGContact *contact in _tableData)
	{
        NSRange r = [contact.name rangeOfString:searchText options:NSCaseInsensitiveSearch];
        NSRange r1 = [contact.lastName rangeOfString:searchText options:NSCaseInsensitiveSearch];
        if ((r.location != NSNotFound)||(r1.location != NSNotFound))
        {
            [_filteredTableData addObject:contact];
        }
	}
}


#pragma mark - UISearchBarDelegate

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
	[self loadData];
	
	[searchBar resignFirstResponder];
	searchBar.text = @"";
}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
	[searchBar resignFirstResponder];
}


#pragma mark - Other methods

- (void)loadData
{
    _tableData = [[ClientInfo shared] contacts];
    
    [self.tableView reloadData];
}


- (void)connectionFinished
{
    self.navigationItem.title = LOCS(@"Contacts");
}


- (void)refresh:(id)sender
{
    _refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:LOCS(@"Refreshing data...")];
    
    [[EJConnection shared] retrieveAllContacts];
    [self loadData];
    
    NSString *dateString = [NSDateFormatter localizedStringFromDate:[NSDate date]
                                                          dateStyle:NSDateFormatterMediumStyle
                                                          timeStyle:NSDateFormatterShortStyle];
    NSString *lastUpdated = [NSString stringWithFormat:@"%@ %@", LOCS(@"Last updated on"), dateString];
    
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:lastUpdated];
    NSRange fullRange = NSMakeRange(0, [string length]);
    [string addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:fullRange];
    [string addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Georgia" size:17] range:fullRange];
    [_refreshControl setAttributedTitle:string];

    [_refreshControl endRefreshing];
}

@end
