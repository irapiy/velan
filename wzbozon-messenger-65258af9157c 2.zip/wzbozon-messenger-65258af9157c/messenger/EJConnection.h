//
//  XMPPEngine.h
//  messenger
//
//  Created by Denis Kutlubaev on 27.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>

@class XMPPStream;
@class XMPPJID;
@class MSGMessage;
@class MSGContact;
@class ClientInfo;

@interface EJConnection : NSObject //<XMPPPingDelegate>

@property (strong, nonatomic) XMPPStream *xmppStream;

+ (EJConnection *)shared;

- (BOOL)connect;

- (void)disconnect;

- (void)retrieveAllContacts;

- (void)sendMessage:(MSGMessage *)message;

- (void)sendPrintNotificationToContact:(MSGContact *)contact;

- (void)updateCurrentStatus;

- (void)resendMyPresence;

- (void)registerOnServer;

- (void)addContactToRoster:(MSGContact *)contact;

@end
