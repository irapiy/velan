//
//  BNHtmlPdfKitPageRenderer.h
//  messenger
//
//  Created by Denis Kutlubaev on 23.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BNHtmlPdfKitPageRenderer : UIPrintPageRenderer

@property (nonatomic, assign) CGFloat topAndBottomMarginSize;
@property (nonatomic, assign) CGFloat leftAndRightMarginSize;

@end
