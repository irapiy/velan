//
//  BNHtmlPdfKitPageRenderer.m
//  messenger
//
//  Created by Denis Kutlubaev on 23.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "BNHtmlPdfKitPageRenderer.h"

@implementation BNHtmlPdfKitPageRenderer

@synthesize topAndBottomMarginSize = _topAndBottomMarginSize;
@synthesize leftAndRightMarginSize = _leftAndRightMarginSize;

- (CGRect)paperRect {
	return UIGraphicsGetPDFContextBounds();
}

- (CGRect)printableRect {
	return CGRectInset([self paperRect], _leftAndRightMarginSize, _topAndBottomMarginSize);
}

@end
