//
//  MSGBrowserBookmarkItem.m
//  messenger
//
//  Created by Denis Kutlubaev on 17.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "MSGBrowserBookmarkItem.h"
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"

@implementation MSGBrowserBookmarkItem

- (id)initWithPageID:(NSInteger)pageID name:(NSString *)name address:(NSString *)address dateAdded:(NSInteger)dateAdded
{
    self = [super init];
    
    if (self) {
        
        _pageID = pageID;
        _name = name;
        _address = address;
        _dateAdded = dateAdded;
        
    }
    
    return self;
    
}


#pragma mark - Database operations

- (BOOL)addToDb
{
    if ( ! [AppDel.db open] ) {
        return NO;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"INSERT INTO browser_bookmarks (name, address, date_added) VALUES (?, ?, ?)" withArgumentsInArray:@[self.name, self.address, @(self.dateAdded)]];
    
    [AppDel.db close];
    
    return result;
}


- (BOOL)deleteFromDb
{
    if ( ! [AppDel.db open] ) {
        return NO;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"DELETE FROM browser_bookmarks WHERE page_id = ?" withArgumentsInArray:@[@(self.pageID)]];
    
    [AppDel.db close];
    
    return result;
}


+ (NSArray *)retrieveFromDb
{
    NSMutableArray *temp = [NSMutableArray new];
    
    if ( ! [AppDel.db open] ) {
        return nil;
    }
    
    NSMutableString *sql = [NSMutableString new];
    [sql appendString:@"SELECT * FROM browser_bookmarks"];
    
    FMResultSet *rs = [AppDel.db executeQuery:sql];
    while ( [rs next] ) {
        
        MSGBrowserBookmarkItem *item = [[MSGBrowserBookmarkItem alloc] initWithPageID:[rs intForColumn:@"page_id"] name:[rs stringForColumn:@"name"] address:[rs stringForColumn:@"address"] dateAdded:[rs intForColumn:@"date_added"]];
		[temp addObject:item];
        
    }
    [rs close];
    
    [AppDel.db close];
    
	return temp;
}

@end
