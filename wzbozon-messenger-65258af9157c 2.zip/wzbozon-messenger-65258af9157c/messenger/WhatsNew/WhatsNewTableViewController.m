//
//  WhatsNewViewController.m
//  SahihAlBuhari
//
//  Created by Denis Kutlubaev on 22.07.12.
//  Copyright (c) 2012 Alwawee. All rights reserved.
//

#import "WhatsNewTableViewController.h"
#import "CustomCellBackground.h"

@interface WhatsNewTableViewController ()
{
    NSDictionary *_tableData;
    NSArray *_sectionNames;
}
@end

@implementation WhatsNewTableViewController


- (void)loadView
{
    [super loadView];
    
    self.title = LOCS(@"Release Notes");
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.backgroundView = nil;
    
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelClicked:)];
    self.navigationItem.leftBarButtonItem = cancelButton;
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"WhatsNew" ofType:@"plist"];
    _tableData = [NSDictionary dictionaryWithContentsOfFile:path];
    
    NSArray *temp = [_tableData allKeys];
    for (NSString *string in temp) {
        
    }
    
    _sectionNames = [[_tableData allKeys] sortedArrayUsingComparator:^(id a, id b) {
        
        NSArray *components_a = [a componentsSeparatedByString:@"."];
        NSArray *components_b = [b componentsSeparatedByString:@"."];
        
        if ([components_a[0] intValue] < [components_b[0] intValue]) {
            return NSOrderedDescending;
        }
        else if ([components_a[0] intValue] > [components_b[0] intValue]){
            return NSOrderedAscending;
        }
        else {
            if ([components_a[1] intValue] < [components_b[1] intValue]) {
                return NSOrderedDescending;
            }
            else if ([components_a[1] intValue] > [components_b[1] intValue]){
                return NSOrderedAscending;
            }
            else {
                if ([components_a[2] intValue] < [components_b[2] intValue]) {
                    return NSOrderedDescending;
                }
                else if ([components_a[2] intValue] > [components_b[2] intValue]){
                    return NSOrderedAscending;
                }
                else {
                    if ([components_a[3] intValue] < [components_b[3] intValue]) {
                        return NSOrderedDescending;
                    }
                    else if ([components_a[3] intValue] > [components_b[3] intValue]){
                        return NSOrderedAscending;
                    }
                }
            }
        }
        
        return NSOrderedSame;
    }];
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [_sectionNames count];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *sectionName = _sectionNames[section];
    return [_tableData[sectionName] count];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundView = [[CustomCellBackground alloc] initWithFrame:cell.bounds andBackgroundColor:RGB(0xf7f7f7) hasBorderStroke:YES];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.textLabel.font = [UIFont fontWithName:@"Georgia" size:17];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.textLabel.numberOfLines = 3;
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.imageView.image = [UIImage imageNamed:@"28-star"];
    }
    
    NSString *sectionName = _sectionNames[indexPath.section];
    cell.textLabel.text = _tableData[sectionName][indexPath.row];
    
    return cell;
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [NSString stringWithFormat:@"Версия №%@", _sectionNames[section]];
}


#pragma mark - Other methods

- (void)cancelClicked:(id)sender
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}


@end
