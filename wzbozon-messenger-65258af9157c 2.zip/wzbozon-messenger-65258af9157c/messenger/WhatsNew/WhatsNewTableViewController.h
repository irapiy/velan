//
//  WhatsNewViewController.h
//  SahihAlBuhari
//
//  Created by Denis Kutlubaev on 22.07.12.
//  Copyright (c) 2012 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WhatsNewTableViewController : UITableViewController

@end
