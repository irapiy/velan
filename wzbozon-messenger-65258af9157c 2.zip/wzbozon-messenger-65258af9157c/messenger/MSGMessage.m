//
//  MSGMessage.m
//  messenger
//
//  Created by Denis Kutlubaev on 29.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "MSGMessage.h"
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"

@implementation MSGMessage


#pragma mark - Database operations

- (id)initWithMessageID:(NSInteger)messageID jidFrom:(NSString *)jidFrom jidTo:(NSString *)jidTo messageBody:(NSString *)messageBody dateDelivered:(NSInteger)dateDelivered
{
    self = [super init];
    
    if (self) {
        
        _messageID = messageID;
        _jidFrom = jidFrom;
        _jidTo = jidTo;
        _messageBody = messageBody;
        _dateDelivered = dateDelivered;
        
    }
    
    return self;
}


- (BOOL)addToDb
{
    if ( ! [AppDel.db open] ) {
        return NO;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"INSERT INTO messages (jid_from, jid_to, message_body, date_delivered) VALUES (?, ?, ?, ?)" withArgumentsInArray:@[self.jidFrom, self.jidTo, self.messageBody, @(self.dateDelivered)]];
    
    [AppDel.db close];
    
    return result;
}


- (BOOL)deleteFromDb
{
    if ( ! [AppDel.db open] ) {
        return NO;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"DELETE FROM messages WHERE message_id = ?" withArgumentsInArray:@[@(self.messageID)]];
    
    [AppDel.db close];
    
    return result;
}


+ (NSArray *)retrieveFromDb
{
    NSMutableArray *temp = [NSMutableArray new];
    
    if ( ! [AppDel.db open] ) {
        return nil;
    }
    
    NSMutableString *sql = [NSMutableString new];
    [sql appendString:@"SELECT * FROM messages"];
    
    FMResultSet *rs = [AppDel.db executeQuery:sql];
    while ( [rs next] ) {
        
        MSGMessage *message = [[MSGMessage alloc] initWithMessageID:[rs intForColumn:@"message_id"]
                                                            jidFrom:[rs stringForColumn:@"jid_from"]
                                                              jidTo:[rs stringForColumn:@"jid_to"]
                                                        messageBody:[rs stringForColumn:@"message_body"]
                                                      dateDelivered:[rs intForColumn:@"date_delivered"]];
		[temp addObject:message];
        
    }
    
    [rs close];
    
    [AppDel.db close];
    
	return temp;
}


+ (NSArray *)retrieveFromDbWithJIDFrom:(NSString *)jidFrom JIDTo:(NSString *)jidTo
{
    NSMutableArray *temp = [NSMutableArray new];
    
    if ( ! [AppDel.db open] ) {
        return nil;
    }
    
    FMResultSet *rs = [AppDel.db executeQuery:@"SELECT * FROM messages WHERE jid_from = ? AND jid_to = ? ORDER BY date_delivered DESC LIMIT 10" withArgumentsInArray:@[jidFrom, jidTo]];
    while ( [rs next] ) {
        
        MSGMessage *message = [[MSGMessage alloc] initWithMessageID:[rs intForColumn:@"message_id"]
                                                            jidFrom:[rs stringForColumn:@"jid_from"]
                                                              jidTo:[rs stringForColumn:@"jid_to"]
                                                        messageBody:[rs stringForColumn:@"message_body"]
                                                      dateDelivered:[rs intForColumn:@"date_delivered"]];
		[temp addObject:message];
        
    }
    
    [rs close];
    
    [AppDel.db close];
    
	return temp;
}


@end
