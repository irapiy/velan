//
//  ChatsTableViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 27.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "ChatsTableViewController.h"
#import "ChatViewController.h"


@interface ChatsTableViewController ()
{
    NSArray *_tableData;
}

@end



@implementation ChatsTableViewController


#pragma mark - View lifecycle

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"286-speechbubble_active"]
                      withFinishedUnselectedImage:[UIImage imageNamed:@"286-speechbubble"]];
        self.title = LOCS(@"Chats");
        
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self loadData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadData) name:MESSAGES_CHANGED object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadData) name:CONTACTS_CHANGED object:nil];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_tableData count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    MSGContact *contact = _tableData[indexPath.row];
    
    cell.textLabel.text = contact.fullName;
    cell.detailTextLabel.text = [[contact.messages lastObject] messageBody];
    
    UIImage *image = [UIImage imageNamed:@"missingAvatar"];
    cell.imageView.image = image;
    
    UIImageView *onlineView = [[UIImageView alloc] initWithFrame:CGRectMake(295, 26, 18, 18)];
    NSString *imageName = contact.isOnline ? @"Online" : @"Offline";
    
    if (contact.isBusy) imageName = @"Busy";
    
    [onlineView setImage:[UIImage imageNamed:imageName]];
    onlineView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [cell.contentView addSubview:onlineView];
    
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AppDel.tabBarController.selectedIndex = 1;
    
    AppDel.chatViewController = [[ChatViewController alloc] initWithNibName:nil bundle:nil];
    AppDel.chatViewController.hidesBottomBarWhenPushed = YES;
    AppDel.chatViewController.contact = _tableData[indexPath.row];
    [AppDel.chatsNavController pushViewController:AppDel.chatViewController animated:YES];
}


#pragma mark - Other methods

- (void)loadData
{
    _tableData = [[ClientInfo shared] activeContacts];
    
    [self.tableView reloadData];
}

@end
