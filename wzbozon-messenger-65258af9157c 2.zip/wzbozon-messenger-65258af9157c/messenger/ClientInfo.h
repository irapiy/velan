//
//  ClientInfo.h
//  messenger
//
//  Created by Denis Kutlubaev on 30.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>

// Данный класс содержит всю информацию по текущему пользователю

@interface ClientInfo : NSObject

// Сырой номер телефона, переданный из текстового поля формата (925)060-5686
@property (strong, nonatomic) NSString *roughPhoneNumber;

@property (strong, nonatomic) NSString *phone;
@property (strong, nonatomic) NSString *password;
@property (strong, nonatomic) NSString *jidString;
@property (strong, nonatomic) NSString *email;
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSArray *contacts;
@property (strong, nonatomic) NSArray *activeContacts;
@property (strong, nonatomic) XMPPJID *jid;
@property (nonatomic) BOOL loggedIn;
@property (nonatomic) BOOL registered;

+ (ClientInfo *)shared;

- (void)savePhoneAndPassword;

- (NSXMLElement *)registrationIQStanza;

- (void)createRosterFromAddressBook;

@end
