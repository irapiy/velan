//
//  MCCircleButton.m
//  MailClient
//
//  Created by Denis Kutlubaev on 23.01.13.
//  Copyright (c) 2013 1Forma. All rights reserved.
//

#import "MCCircleButton.h"
#import "UIButton+Extensions.h"
#import <QuartzCore/QuartzCore.h>

@interface MCCircleButton()
{
    UIImageView *_buttonBg;
    UIButton *_button;
}

@end

@implementation MCCircleButton

- (BOOL)canBecomeFirstResponder
{
    return YES; // Для отлавления Shake события
}


- (void)setButtonAlpha:(CGFloat)buttonAlpha
{
    _buttonAlpha = buttonAlpha;
    _buttonBg.alpha = buttonAlpha;
}


- (void)setButtonBackgroundColor:(UIColor *)buttonBackgroundColor
{
    _buttonBackgroundColor = buttonBackgroundColor;
    _buttonBg.backgroundColor = buttonBackgroundColor;
}


- (id)initWithFrame:(CGRect)frame target:(id)target action:(SEL)action imageName:(NSString*)imageName
{
    self = [super initWithFrame:frame];
    if (self) {
        
        UIImage *image = [UIImage imageNamed:imageName];
        CGFloat imageWidth = image.size.width;
        CGFloat hitEdgeInset = frame.size.width - imageWidth;
        CGFloat buttonWidth = image.size.width + hitEdgeInset;
        
        self.backgroundColor = [UIColor clearColor];
        _buttonBg = [[UIImageView alloc] initWithFrame:self.bounds];
        _buttonBg.layer.cornerRadius = buttonWidth / 2.0;
        _buttonBg.alpha = 0.1;
        _buttonBg.backgroundColor = [UIColor blackColor];
        [self addSubview:_buttonBg];
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.hitTestEdgeInsets = UIEdgeInsetsMake(-hitEdgeInset, -hitEdgeInset, -hitEdgeInset, -hitEdgeInset);
        [_button setFrame:CGRectMake(0, 0, imageWidth, imageWidth)];
        [_button setImage:image forState:UIControlStateNormal];
        [_button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_button];
        _button.center = CGPointMake(buttonWidth/2.0, buttonWidth/2.0);
        [self bringSubviewToFront:_button];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
