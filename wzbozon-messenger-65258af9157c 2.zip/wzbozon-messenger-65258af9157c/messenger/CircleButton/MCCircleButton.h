//
//  MCCircleButton.h
//  MailClient
//
//  Created by Denis Kutlubaev on 23.01.13.
//  Copyright (c) 2013 1Forma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MCCircleButton : UIView
{

}

@property (nonatomic, strong) UIColor *buttonBackgroundColor;
@property (nonatomic) CGFloat buttonAlpha;

- (id)initWithFrame:(CGRect)frame target:(id)target action:(SEL)action imageName:(NSString*)imageName;

@end
