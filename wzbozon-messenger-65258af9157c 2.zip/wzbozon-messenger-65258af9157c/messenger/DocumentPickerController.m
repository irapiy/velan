//
//  UserAudioTableViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 04.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "DocumentPickerController.h"
#import "NSFileManager+DKAdditionals.h"
#import <MediaPlayer/MediaPlayer.h>
#import "WebViewController.h"
#import "AudioViewController.h"

@interface DocumentPickerController ()
{
    NSMutableArray *_tableData;
    NSDictionary *_fileTypesDic;
    UIRefreshControl *_refreshControl;
}

@end

@implementation DocumentPickerController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
        _fileTypesDic = @{
                          @"application/msword": @"doc",
                          @"application/vnd.ms-excel": @"xls",
                          @"application/vnd.ms-powerpoint": @"ppt",
                          @"application/vnd.openxmlformats-officedocument.wordprocessingml.document": @"doc",
                          @"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": @"xls",
                          @"application/vnd.openxmlformats-officedocument.presentationml.presentation": @"ppt",
                          @"application/pdf": @"pdf",
                          @"text/plain": @"txt",
                          @"text/rtf": @"rtf",
                          @"text/x-rtf": @"rtf",
                          @"text/richtext": @"rtf",
                          @"text/html": @"html",
                          @"application/octet-stream": @"txt",
                          @"image/jpeg": @"jpg",
                          @"image/png": @"png",
                          @"image/tiff": @"tiff",
                          @"image/gif": @"gif",
                          @"image/bmp": @"bmp",
                          @"audio/mpeg": @"mp3",
                          @"image/jpg": @"jpg"
                          };
        
    }
    return self;
}


- (void)loadView
{
    [super loadView];
    
    self.title = LOCS(@"Documents");
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.backgroundView = nil;
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    _refreshControl = [[UIRefreshControl alloc] init];
    _refreshControl.tintColor = [UIColor blackColor];
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:LOCS(@"Pull to Refresh")];
    NSRange fullRange = NSMakeRange(0, [string length]);
    [string addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:fullRange];
    [string addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Georgia" size:17] range:fullRange];
    [_refreshControl setAttributedTitle:string];
    [_refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
    [self setRefreshControl:_refreshControl];
    
    [self loadData];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_tableData count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text = _tableData[indexPath.row];
    
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *item = _tableData[indexPath.row];
    NSString *fileExtension = [item pathExtension];
    NSString *filePath = [AppDel.documentsDir stringByAppendingPathComponent:item];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    
    
    if ([fileExtension isEqualToString:@"mp3"]) {
        AppDel.tabBarController.selectedIndex = 3;
        [AppDel.audioViewController playAudioFile:item];
    }
    else if ([fileExtension isEqualToString:@"webpage"]) {
        AppDel.tabBarController.selectedIndex = 2;
        NSArray *allTypes = [_fileTypesDic allKeysForObject:@"html"];
        NSString *mimeType = ([allTypes count] > 0) ? allTypes[0] : nil;
        [AppDel.webViewController.mainWebView loadData:data MIMEType:mimeType textEncodingName:@"utf-8" baseURL:[NSURL URLWithString:@""]];
        AppDel.webViewController.topTitle = item;
    }
    else {
        NSArray *allTypes = [_fileTypesDic allKeysForObject:fileExtension];
        NSString *mimeType = ([allTypes count] > 0) ? allTypes[0] : nil;
        AppDel.tabBarController.selectedIndex = 2;
        [AppDel.webViewController.mainWebView loadData:data MIMEType:mimeType textEncodingName:@"utf-8" baseURL:[NSURL URLWithString:@""]];
        AppDel.webViewController.topTitle = item;
    }
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        NSString *item = _tableData[indexPath.row];
        NSError *error = nil;
        NSString *filePath = [AppDel.documentsDir stringByAppendingPathComponent:item];
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
        [_tableData removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    
    }
}


#pragma mark - Other methods

- (void)loadData
{
    NSArray *dirContents = [[NSFileManager defaultManager]contentsOfDirectoryAtPath:AppDel.documentsDir error:nil];
    NSPredicate *fltr = [NSPredicate predicateWithFormat:@"self CONTAINS '.'"];
    _tableData = [NSMutableArray arrayWithArray:[dirContents filteredArrayUsingPredicate:fltr]];
    [_tableData removeObject:@"messenger.sqlite"];
    
    if ([_tableData count] == 0) {
        [SVProgressHUD showErrorWithStatus:LOCS(@"No documents yet.")];
    }
    
    [self.tableView reloadData];
}


- (void)cancelClicked:(id)sender
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}


- (void)refresh:(id)sender
{
    _refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:LOCS(@"Refreshing data...")];
    
    [self loadData];
    
    NSString *dateString = [NSDateFormatter localizedStringFromDate:[NSDate date]
                                                          dateStyle:NSDateFormatterMediumStyle
                                                          timeStyle:NSDateFormatterShortStyle];
    NSString *lastUpdated = [NSString stringWithFormat:@"%@ %@", LOCS(@"Last updated on"), dateString];
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:lastUpdated];
    NSRange fullRange = NSMakeRange(0, [string length]);
    [string addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:fullRange];
    [string addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Georgia" size:17] range:fullRange];
    [_refreshControl setAttributedTitle:string];
    
    [_refreshControl endRefreshing];
}


@end
