//
//  ChatDelegate.h
//  messenger
//
//  Created by Denis Kutlubaev on 25.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ChatDelegate <NSObject>

- (void)newBuddyOnline:(NSString *)buddyName;

- (void)buddyWentOffline:(NSString *)buddyName;

- (void)didDisconnect;

- (void)didReceiveAllContacts:(NSArray *)contacts;

@end
