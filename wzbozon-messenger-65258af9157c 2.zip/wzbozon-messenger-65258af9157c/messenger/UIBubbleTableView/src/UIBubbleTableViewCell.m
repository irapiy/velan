//
//  UIBubbleTableViewCell.m
//
//  Created by Alex Barinov
//  Project home page: http://alexbarinov.github.com/UIBubbleTableView/
//
//  This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//  To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/
//

#import <QuartzCore/QuartzCore.h>
#import "UIBubbleTableViewCell.h"
#import "NSBubbleData.h"
#import "ChatViewController.h"
#import "HPGrowingTextView.h"
#import "HPTextViewInternal.h"

@interface UIBubbleTableViewCell ()
{
    UITextField *_tempField;
}

@property (nonatomic, retain) UIImageView *bubbleImage;
@property (nonatomic, retain) UIImageView *avatarImage;

- (void) setupInternalData;

@end

@implementation UIBubbleTableViewCell

@synthesize data = _data;
@synthesize bubbleImage = _bubbleImage;
@synthesize showAvatar = _showAvatar;
@synthesize avatarImage = _avatarImage;

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
	[self setupInternalData];
}

#if !__has_feature(objc_arc)
- (void) dealloc
{
    self.data = nil;
    self.customView = nil;
    self.bubbleImage = nil;
    self.avatarImage = nil;
    [super dealloc];
}
#endif

- (void)setDataInternal:(NSBubbleData *)value
{
	self.data = value;
	[self setupInternalData];
}

- (void) setupInternalData
{
    UILongPressGestureRecognizer *gr = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(bubbleClicked:)];
    [self addGestureRecognizer:gr];
    
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (!self.bubbleImage)
    {
#if !__has_feature(objc_arc)
        self.bubbleImage = [[[UIImageView alloc] init] autorelease];
#else
        self.bubbleImage = [[UIImageView alloc] init];        
#endif
        [self addSubview:self.bubbleImage];
    }
    
    NSBubbleType type = self.data.type;
    
    CGFloat width = self.data.view.frame.size.width;
    CGFloat height = self.data.view.frame.size.height;

    CGFloat x = (type == BubbleTypeSomeoneElse) ? 0 : self.frame.size.width - width - self.data.insets.left - self.data.insets.right;
    CGFloat y = 0;
    
    // Adjusting the x coordinate for avatar
    if (self.showAvatar)
    {
        [self.avatarImage removeFromSuperview];
#if !__has_feature(objc_arc)
        self.avatarImage = [[[UIImageView alloc] initWithImage:(self.data.avatar ? self.data.avatar : [UIImage imageNamed:@"missingAvatar.png"])] autorelease];
#else
        self.avatarImage = [[UIImageView alloc] initWithImage:(self.data.avatar ? self.data.avatar : [UIImage imageNamed:@"missingAvatar.png"])];
#endif
        self.avatarImage.layer.cornerRadius = 9.0;
        self.avatarImage.layer.masksToBounds = YES;
        self.avatarImage.layer.borderColor = [UIColor colorWithWhite:0.0 alpha:0.2].CGColor;
        self.avatarImage.layer.borderWidth = 1.0;
        
        CGFloat avatarX = (type == BubbleTypeSomeoneElse) ? 2 : self.frame.size.width - 52;
        CGFloat avatarY = self.frame.size.height - 50;
        
        self.avatarImage.frame = CGRectMake(avatarX, avatarY, 50, 50);
        [self addSubview:self.avatarImage];
        
        CGFloat delta = self.frame.size.height - (self.data.insets.top + self.data.insets.bottom + self.data.view.frame.size.height);
        if (delta > 0) y = delta;
        
        if (type == BubbleTypeSomeoneElse) x += 54;
        if (type == BubbleTypeMine) x -= 54;
    }

    [self.customView removeFromSuperview];
    self.customView = self.data.view;
    self.customView.frame = CGRectMake(x + self.data.insets.left, y + self.data.insets.top, width, height);
    
    [self.contentView addSubview:self.customView];

    if (type == BubbleTypeSomeoneElse)
    {
        self.bubbleImage.image = [[UIImage imageNamed:@"bubbleSomeone.png"] stretchableImageWithLeftCapWidth:20 topCapHeight:13];

    }
    else {
        self.bubbleImage.image = [[UIImage imageNamed:@"bubbleMine.png"] stretchableImageWithLeftCapWidth:13 topCapHeight:13];
    }

    self.bubbleImage.frame = CGRectMake(x, y, width + self.data.insets.left + self.data.insets.right, height + self.data.insets.top + self.data.insets.bottom);
    
    CGRect myDateFrame = CGRectMake(self.customView.frame.origin.x + self.customView.frame.size.width - 40, self.customView.frame.origin.y + self.customView.frame.size.height + 5, 45, 15);
    CGRect someoneDateFrame = CGRectMake(self.customView.frame.origin.x, self.customView.frame.origin.y + self.customView.frame.size.height + 5, 45, 15);
    
    UILabel *dateLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    dateLabel.frame = (self.data.type == BubbleTypeMine) ? myDateFrame : someoneDateFrame;
    dateLabel.textAlignment = (self.data.type == BubbleTypeMine) ? NSTextAlignmentRight : NSTextAlignmentLeft;
    dateLabel.font = REG_FONT(10);
    dateLabel.backgroundColor = [UIColor clearColor];
    dateLabel.textColor = RGB(0xbbbbbb);
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateStyle:NSDateFormatterNoStyle];
    [df setTimeStyle:NSDateFormatterShortStyle];
    NSDate *dateDelivered = [NSDate dateWithTimeIntervalSince1970:self.data.message.dateDelivered];
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:[df stringFromDate:dateDelivered]];
    NSRange range = NSMakeRange(0, [attString length]);
    [attString addAttribute:NSFontAttributeName value:dateLabel.font range:range];
    [attString addAttribute:NSForegroundColorAttributeName value:dateLabel.textColor range:range];
    NSShadow* shadow = [[NSShadow alloc] init];
    shadow.shadowColor = RGB(0x333333);
    shadow.shadowOffset = CGSizeMake(0.0f, -1.0f);
    [attString addAttribute:NSShadowAttributeName value:shadow range:range];
    
    dateLabel.attributedText = attString;
    
    [self.contentView addSubview:dateLabel];
    
    /*UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"missingAvatar"]];
    CGRect myImageFrame = CGRectMake(SCREEN_WIDTH - 25 - 5, dateLabel.frame.origin.y + dateLabel.frame.size.height - 25 - 3, 25, 25);
    CGRect someoneImageFrame = CGRectMake(5, dateLabel.frame.origin.y + dateLabel.frame.size.height - 25 -  3, 25, 25);
    image.frame = (self.data.type == BubbleTypeMine) ? myImageFrame : someoneImageFrame;
    [self.contentView addSubview:image];*/
}


- (void)bubbleClicked:(id)sender
{
    NSLog(@"Bubble clicked");
    
    if ([AppDel.chatViewController.textView isFirstResponder]) {
        AppDel.chatViewController.textView.internalTextView.overrideNextResponder = self;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(menuDidHide:)
                                                     name:@"UIMenuControllerDidHideMenuNotification" object:nil];
    } else {
        [self becomeFirstResponder];
    }
    
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    [menuController setTargetRect:self.customView.frame inView:self];
    [menuController setMenuVisible:YES animated:YES];
}


- (void)menuDidHide:(NSNotification*)notification
{
    AppDel.chatViewController.textView.internalTextView.overrideNextResponder = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:@"UIMenuControllerDidHideMenuNotification" object:nil];
}


- (BOOL)canBecomeFirstResponder
{
    return YES;
}


- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (action == @selector(copy:))
    {
        return YES;
    }
    else if (action == @selector(delete:))
    {
        return YES;
    }
    
    return NO;
}


- (void)copy:(id)sender
{
    // Здесь вернуть старую картинку
    
    [[UIPasteboard generalPasteboard] setString:self.data.text];
}


- (void)delete:(id)sender
{
    [self.data.message deleteFromDb];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:MESSAGES_CHANGED object:nil];
}



@end
