//
//  EjabberdRegistrator.m
//  messenger
//
//  Created by Denis Kutlubaev on 30.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "EJRegistrator.h"
#import "XMPPIQ+Extension.h"


static EJRegistrator *sharedRegistrator;


@interface EJRegistrator()

@property (nonatomic, strong) ClientInfo *clientInfo;

@end



@implementation EJRegistrator


+ (EJRegistrator *)sharedRegistrator
{
    static dispatch_once_t once;
    
    dispatch_once(&once, ^{
        
        sharedRegistrator = [[EJRegistrator alloc] init];
        
    });
    
    return sharedRegistrator;
}


- (BOOL)registerClientWithDelegate:(id <EJRegistratorDelegate>)delegate
{
    // соединение
    
    self.clientInfo = [ClientInfo shared];
    self.delegate = delegate;
    
    NSError *error = nil;
    
    if ( ! [self.xmppStream connectWithTimeout:EJABBERD_CONNECTION_TIMEOUT error:&error] )
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                            message:[NSString stringWithFormat:@"Can't connect to server %@", [error localizedDescription]]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
        [alertView show];
        
        return NO;
    }
    
    return YES;
}


#pragma mark - XMPP

- (XMPPStream *)xmppStream
{
    if ( _xmppStream == nil ) {
        
        _xmppStream = [[XMPPStream alloc] init];
        [_xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        XMPPJID *jid = [XMPPJID jidWithString:EJABBERD_DEFAULT_LOGIN];
        [_xmppStream setMyJID:jid];
        [_xmppStream setHostName:EJABBERD_HOST_NAME];
        [_xmppStream setHostPort:EJABBERD_HOST_PORT];
        [_xmppStream setAutoStartTLS:EJABBERD_TLS];
#if !TARGET_IPHONE_SIMULATOR
        {
            _xmppStream.enableBackgroundingOnSocket = YES;
        }
#endif
    }
    
    return _xmppStream;
}


- (void)xmppStream:(XMPPStream *)sender didReceiveError:(NSXMLElement *)error
{
    [self.delegate registratorFailedToRegisterClient];
}


- (void)xmppStreamDidConnect:(XMPPStream *)sender
{
    NSLog(@"Registration XMPP Stream connected.");
    
    NSLog(@"Sending register request ...");
    
    [self.xmppStream sendElement:[self.clientInfo registrationIQStanza]];
}


- (BOOL)xmppStream:(XMPPStream *)sender didReceiveIQ:(XMPPIQ *)iq
{
    /*if ([iq isErrorIQ]) {
        
        [BlockAlertView showError:[iq errorFromXMPPIQ]];
        [self.delegate registratorFailedToRegisterClient];
        
    }
    else if ([iq isResultIQ]) {*/
        
        NSLog(@"New user added");
        [self.xmppStream disconnect];
        [self.delegate registratorDidRegisterClient];
        
    //}
    
    return YES;
}


@end
