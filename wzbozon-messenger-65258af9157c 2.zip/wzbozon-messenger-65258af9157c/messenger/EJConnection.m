//
//  XMPPEngine.m
//  messenger
//
//  Created by Denis Kutlubaev on 27.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "EJConnection.h"
#import "MSGMessage.h"
#import "MSGFile.h"
#import "MSGContact.h"
#import "NotificationManager.h"
#import "XMPPMessage+XEP_0085.h"
#import "ChatViewController.h"

static EJConnection *shared;

NSString *const EJConnectionErrorDomain = @"EJConnectionErrorDomain";

@interface EJConnection()
{
    NSMutableArray *_presencesArray;
}

@end


@implementation EJConnection


+ (EJConnection *)shared
{
    static dispatch_once_t once;
    
    dispatch_once(&once, ^{
        
        shared = [[EJConnection alloc] init];
        
    });
    
    return shared;
}


- (XMPPStream *)xmppStream
{
    if ( _xmppStream == nil ) {
        
        _xmppStream = [[XMPPStream alloc] init];
        [_xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
    }
    
    return _xmppStream;
}


- (BOOL)connect
{
    BOOL tls = NO;
    
    ClientInfo *clientInfo = [ClientInfo shared];
    
    if ( [self.xmppStream isConnected] ) {
        
        NSError *error = nil;
        [self.xmppStream authenticateWithPassword:clientInfo.password error:&error];
        return YES;
    }
    
    [self.xmppStream setMyJID:clientInfo.jid];
    [self.xmppStream setHostName:EJABBERD_HOST_NAME];
    [self.xmppStream setHostPort:EJABBERD_HOST_PORT];
    [self.xmppStream setAutoStartTLS:tls];
    
#if !TARGET_IPHONE_SIMULATOR
	{
		self.xmppStream.enableBackgroundingOnSocket = YES;
	}
#endif
    
    NSError *error = nil;
    
    if ( ! [self.xmppStream connectWithTimeout:EJABBERD_CONNECTION_TIMEOUT error:&error] )
    {
        [SVProgressHUD dismiss];
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                            message:[NSString stringWithFormat:@"Can't connect to server %@", [error localizedDescription]]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
        [alertView show];
        
        return NO;
    }
    
    return YES;
}


- (void)disconnect
{
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"unavailable"];
    [_xmppStream sendElement:presence];
    
    [_xmppStream disconnect];
}


- (void)updateCurrentStatus
{
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"available"];
    NSXMLElement *priority = [NSXMLElement elementWithName:@"status"];
    [priority setStringValue:UD_OBJECT(UDKeyCurrentStatus)];
    [presence addChild:priority];
    [_xmppStream sendElement:presence];
}


- (void)retrieveAllContacts
{
    NSXMLElement *queryElement = [NSXMLElement elementWithName: @"query" xmlns: @"jabber:iq:roster"];
    
    NSXMLElement *iqStanza = [NSXMLElement elementWithName: @"iq"];
    [iqStanza addAttributeWithName: @"type" stringValue: @"get"];
    [iqStanza addChild: queryElement];
    
    [_xmppStream sendElement: iqStanza];
}


#pragma mark - XMPP Delegate


- (void)xmppStream:(XMPPStream *)sender didReceiveError:(NSXMLElement *)error
{
    NSLog(@"Error: %@", error);
}


- (void)xmppStreamDidConnect:(XMPPStream *)sender
{
    NSLog(@"XMPP Stream connected!");
    
    NSError *error = nil;

    NSLog(@"User:%@", [[ClientInfo shared] phone]);
    NSLog(@"Password:%@", [[ClientInfo shared] password]);
    
    [_xmppStream authenticateWithPassword:[[ClientInfo shared] password] error:&error];
}


- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender
{
    [[EJConnection shared] updateCurrentStatus];
    
    if ([[[ClientInfo shared] contacts] count] == 0) {
        [self retrieveAllContacts];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:CONNECTION_FINISHED object:nil];
}


- (void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(NSXMLElement *)error
{
    [SVProgressHUD dismiss];
    
    [BlockAlertView showError:[NSString stringWithFormat:@"XMPP Stream did not authenticate:\n %@", error]];
}


- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message
{
    // Обработка ошибок
    // <message xmlns="jabber:client" from="75556106679@localhost" to="79250605686@localhost/3000636279137639370750278" type="error"><body>Asf </body><error code="503" type="cancel"><service-unavailable xmlns="urn:ietf:params:xml:ns:xmpp-stanzas"/></error></message>
    
    NSString *type = [[message attributeForName:@"type"] stringValue];
    if ([type isEqualToString:@"error"]) {
        NSLog(@"Error:\n %@", message);
        return;
    }
    
    // Формирование принятого сообщения
    
    NSString *from = [[message attributeForName:@"from"] stringValue];
    XMPPJID *xmppJIDFrom = [XMPPJID jidWithString:from];
    NSString *jidFrom = [xmppJIDFrom bare];
    NSString *jidMe = [[ClientInfo shared] jidString];
    if ( [jidFrom isEqualToString:jidMe] ) return; // Если принято собственное сообщение, выходим
    NSString *messageBody = message.body;
    NSInteger dateDelivered = [[NSDate date] timeIntervalSince1970];
    MSGMessage *myMessage = [[MSGMessage alloc] initWithMessageID:0 jidFrom:jidFrom jidTo:jidMe messageBody:messageBody dateDelivered:dateDelivered];
    myMessage.xmppMessage = message;
    
    // Получили новое сообщение:
    
    // Если приложение не активно и нет статуса, то нужно добавить сообщение а затем выставить уведомление.
    if ((! AppDel.isActive) && (! message.hasChatState)) {
        if ([allTrim(myMessage.messageBody) length] == 0) return;
        [myMessage addToDb];
        [[NotificationManager sharedManager] setLocalNotificationForMessage:myMessage];
        [UIApplication sharedApplication].applicationIconBadgeNumber += 1;
    }
    // Если приложение активно и чат открыт и есть статус, то показать статус
    else if ((message.hasChatState) && ([AppDel.chatViewController.contact.jid isEqualToJID:xmppJIDFrom options:XMPPJIDCompareBare])) {
        if (message.isComposingChatState) {
                [[NSNotificationCenter defaultCenter] postNotificationName:CONTACT_IS_TYPING object:nil];
        }
    }
    // Если приложение активно и чат с данным контактом не открыт, то добавить сообщение и прислать уведомление внутреннее
    else if (! [AppDel.chatViewController isChatOpenedWith:xmppJIDFrom]) {
        if ([allTrim(myMessage.messageBody) length] == 0) return;
        [myMessage addToDb];
        [[NotificationManager sharedManager] setLocalNotificationForMessage:myMessage];
    }
    // Если приложение активно и чат открыт, но нет статуса, добавить сообщение и убрать статус
    else if ([AppDel.chatViewController isChatOpenedWith:xmppJIDFrom] && (! message.hasChatState)) {
        if ([allTrim(myMessage.messageBody) length] == 0) return;
        [myMessage addToDb];
        [[SoundManager sharedSoundManager] shootChatReceivedSound];
        [[NSNotificationCenter defaultCenter] postNotificationName:CONTACT_FINISHED_TYPING object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:MESSAGES_CHANGED object:nil];
    }
}


- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence
{
    XMPPJID *jid = [presence from];
    
    if ([jid isEqualToJID:self.xmppStream.myJID options:XMPPJIDCompareBare]) return;
    
    NSString *type = [[presence attributeForName:@"type"] stringValue];
    if ([type isEqualToString:@"available"]) {
        //if ([[ClientInfo shared] contacts]) {
        for (MSGContact *contact in [[ClientInfo shared] contacts]) {
            
            if ( [contact.jid isEqualToJID:jid options:XMPPJIDCompareBare] ) {
                
                contact.presence = presence;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:CONTACTS_CHANGED object:nil];
                
                break;
                
            }
            
        }
        //}
    //    else {
    //        
    //        if (! _presencesArray) _presencesArray = [NSMutableArray new];
    //        [_presencesArray addObject:presence];
    //
    //    }
    }
    else if ([type isEqualToString:@"subscribed"]) {
        for (MSGContact *contact in [[ClientInfo shared] contacts]) {
            
            if ( [contact.jid isEqualToJID:jid options:XMPPJIDCompareBare] ) {
                
                contact.presence = presence;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:CONTACTS_CHANGED object:nil];
                
                break;
                
            }
            
        }
    }
    else {
        NSLog(@"Another type. Check presence:%@", presence);
    }
}


- (BOOL)xmppStream:(XMPPStream *)sender didReceiveIQ:(XMPPIQ *)iq
{
    NSXMLElement *queryElement = [iq elementForName:@"query" xmlns:@"jabber:iq:roster"];
    if (queryElement) {
        NSString *type = [[iq attributeForName:@"type"] stringValue];
        if ([type isEqualToString:@"result"]) {
            [self contactsReceived:queryElement];
        }
        else if ([type isEqualToString:@"set"]) {
            NSString *ask = [[iq attributeForName:@"ask"] stringValue];
            if ([ask isEqualToString:@"subscribe"]) {
                [self subscribeReceived:queryElement];
            }
        }
    }
    
    return NO;
}


- (void)xmppStream:(XMPPStream *)sender didSendMessage:(XMPPMessage *)message
{
    NSLog(@"Messange sent!");
    
    if (! message.hasChatState) {
        [[SoundManager sharedSoundManager] shootChatSentSound];
    }
}


- (void)resendMyPresence
{
    [self.xmppStream resendMyPresence];
}


- (void)sendMessage:(MSGMessage *)message
{
    NSXMLElement *body = [NSXMLElement elementWithName:@"body"];
    [body setStringValue:message.messageBody];
    
    NSXMLElement *msg = [NSXMLElement elementWithName:@"message"];
    [msg addAttributeWithName:@"type" stringValue:@"chat"];
    [msg addAttributeWithName:@"to" stringValue:message.jidTo];
    [msg addChild:body];
    
    NSLog(@"Sending message:%@", msg);
    
    [[self xmppStream] sendElement:msg];
    
    [message addToDb];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:MESSAGES_CHANGED object:nil];
}


- (void)sendPrintNotificationToContact:(MSGContact *)contact
{
    XMPPJID *jidTo = [XMPPJID jidWithString:contact.jidString];
    XMPPMessage *msg = [XMPPMessage messageWithType:@"chat" to:jidTo];
    [msg addComposingChatState];
    NSLog(@"Sending message:%@", msg.XMLString);
    
    [[self xmppStream] sendElement:msg];
}


- (void)addContactToRoster:(MSGContact *)contact
{
    NSLog(@"Registration XMPP Stream connected.");
    
    NSLog(@"Sending register request ...");
    
    [self.xmppStream sendElement:[contact contactAdditionIQStanza]];
}


- (void)contactsReceived:(NSXMLElement *)queryElement
{
    NSArray *itemElements = [queryElement elementsForName:@"item"];
    NSMutableArray *temp = [NSMutableArray new];
    
    for (NSXMLElement *element in itemElements) {
        
        NSString *jidString = [[element attributeForName:@"jid"] stringValue];
        XMPPJID *jid = [XMPPJID jidWithString:jidString];
        
        MSGContact *contact = [[MSGContact alloc] initWithContactID:0 jidString:[jid bare] phone:@"" name:[[element attributeForName:@"name"] stringValue] lastName:@"" company:@"" status:@"" imageName:@""];
        contact.jid = jid;
        
        if ([contact.jid.user length] > 0) {
            
            [temp addObject:contact];
            [contact addToDb];
            
        }
        
        [self.xmppStream sendElement:[contact subscribePresence]];
    }
    
//        [[ClientInfo shared] setContacts:temp];
//        for (XMPPPresence *presence in _presencesArray) {
//            XMPPJID *jid = [presence from];
//            
//            for (MSGContact *contact in [[ClientInfo shared] contacts]) {
//                if ( [contact.jid isEqualToJID:jid options:XMPPJIDCompareBare] ) {
//                    contact.presence = presence;
//                    break;
//                }
//            }
//        }
//        _presencesArray = nil;
        
    [[NSNotificationCenter defaultCenter] postNotificationName:CONTACTS_CHANGED object:nil];
}


- (void)subscribeReceived:(NSXMLElement *)queryElement
{
    NSArray *itemElements = [queryElement elementsForName:@"item"];
    NSMutableArray *temp = [NSMutableArray new];
    
    for (NSXMLElement *element in itemElements) {
        
        NSString *jidString = [[element attributeForName:@"jid"] stringValue];
        XMPPJID *jid = [XMPPJID jidWithString:jidString];
        
        MSGContact *contact = [[MSGContact alloc] initWithContactID:0 jidString:[jid bare] phone:@"" name:[[element attributeForName:@"name"] stringValue] lastName:@"" company:@"" status:@"" imageName:@""];
        contact.jid = jid;
        
        if ([contact.jid.user length] > 0) {
            
            [temp addObject:contact];
            [contact addToDb];
            
        }
        
        [self.xmppStream sendElement:[contact subscribedPresence]];
    }
}


@end
