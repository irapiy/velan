


@interface MMAnimatedGradientLabel : UILabel {
    
    NSString *textToDisplay;
    int text_length;
    
    CGGradientRef gradient;
    
    int current_position_x;
    NSTimer *timer;
    
    CGPoint alignment;
    
    CGGlyph *_glyphs;
}

//@property (nonatomic, strong) UIColor *

- (id)initWithString:(NSString *)_string;

- (void) startAnimation;
- (void) toggle;


@end