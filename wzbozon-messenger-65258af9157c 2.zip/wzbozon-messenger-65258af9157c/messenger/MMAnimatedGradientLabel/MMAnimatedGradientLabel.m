#define RGB_COMPONENTS(r, g, b, a) (r) / 255.0f, (g) / 255.0f, (b) / 255.0f, (a)


#define MM_TEXT_TO_DISPLAY @"default"

#define MM_FONT [UIFont fontWithName:@"Georgia" size:40]
#define MM_FONT_COLOR [UIColor greenColor];

#define MM_SHADOW_ENABLED NO
#define MM_SHADOW_COLOR [UIColor blackColor]
#define MM_SHADOW_OFFSET CGSizeMake(1,1)


#define MM_CONTENT_EDGE_INSETS UIEdgeInsetsMake(0, 10, 0, 10)


#define MM_TIMER_INTERVAL 0.03f
#define MM_HORIZONTAL_SPAN 4



#import "MMAnimatedGradientLabel.h"


@interface MMAnimatedGradientLabel ()

- (CGRect) calculateFrame;
- (BOOL) isAnimating;

@end


@implementation MMAnimatedGradientLabel

// Missing in standard headers.
extern void CGFontGetGlyphsForUnichars(CGFontRef, const UniChar[], const CGGlyph[], size_t);

- (id) init {
    
    textToDisplay = MM_TEXT_TO_DISPLAY;
    
    return [self initWithFrame:[self calculateFrame]];
}

- (id)initWithString:(NSString *)_string {
    
    textToDisplay = _string;
    
    return [self initWithFrame:[self calculateFrame]];
}

- (id) initWithFrame:(CGRect)frame {
    
    if (self = [super initWithFrame:frame]) {
        
        // set default values
        //
        self.textAlignment = NSTextAlignmentLeft;
        self.backgroundColor = [UIColor clearColor];
        self.font = MM_FONT;
        self.text = textToDisplay;
        self.textColor = MM_FONT_COLOR;
        
        if (MM_SHADOW_ENABLED) {
            self.shadowColor = MM_SHADOW_COLOR;
            self.shadowOffset = MM_SHADOW_OFFSET;
        }
        
        text_length = -1;
        
        CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();
        CGFloat colors[] = { RGB_COMPONENTS(0, 0, 255, 0.0), RGB_COMPONENTS(0, 0, 150, 0.5), RGB_COMPONENTS(0, 0, 50, 0.0) };
        
        gradient = CGGradientCreateWithColorComponents(rgb, colors, NULL, sizeof(colors)/(sizeof(colors[0])*4));
        CGColorSpaceRelease(rgb);
        
        current_position_x = -(frame.size.width/2);
    }
    
    return self;
}

- (CGRect) calculateFrame {
    
    CGSize size = [textToDisplay sizeWithFont:MM_FONT];
    
    return CGRectMake(0, 0, size.width + MM_CONTENT_EDGE_INSETS.left + MM_CONTENT_EDGE_INSETS.right, size.height + MM_CONTENT_EDGE_INSETS.top + MM_CONTENT_EDGE_INSETS.bottom);
}

- (void) tick:(NSTimer*)theTimer {
    
    if (current_position_x < self.frame.size.width)
        current_position_x += MM_HORIZONTAL_SPAN;
    else
        current_position_x = -(self.frame.size.width/2);
    
    [self setNeedsDisplay];
}

- (void) startAnimation {
    timer = [[NSTimer alloc] initWithFireDate:[NSDate date]
                    interval:MM_TIMER_INTERVAL
                    target:self
                    selector:@selector(tick:)
                    userInfo:nil
                    repeats:YES
             ];
    
    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
}

- (void) toggle {
    
    if (!timer) {
        timer = [[NSTimer alloc] initWithFireDate:[NSDate date]
                        interval:MM_TIMER_INTERVAL
                        target:self
                        selector:@selector(tick:)
                        userInfo:nil
                        repeats:YES];
        
        [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
    }
    else {
        [timer invalidate];
        timer = nil;
            
        current_position_x = -(self.frame.size.width/2);
        [self setNeedsDisplay];
    }
}

- (BOOL) isAnimating {

    return timer ? YES : NO;
}

- (void) drawRect:(CGRect)rect {
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    UIFont *ufont = self.font;
    
    // Get drawing font.
    CGFontRef font = CGFontCreateWithFontName((__bridge  CFStringRef)[ufont fontName]);
    CGContextSetFont(ctx, font);
    CGFontRelease(font);
        
    CGContextSetFontSize(ctx, [ufont pointSize]);
    
    // Calculate text drawing point only first time
    //
    if (text_length == -1) {
        
        // Transform text characters to unicode glyphs.
        text_length = [[self text] length];
        //unichar chars[text_length];
       // [[self text] getCharacters:chars range:NSMakeRange(0, text_length)];
        
        char* chars = malloc(sizeof(char) * (text_length + 1));
        [[self text] getCString:chars maxLength: (text_length + 1) encoding: NSUTF8StringEncoding];

        
        
        _glyphs = malloc(sizeof(CGGlyph) * text_length);
        for (int i = 0; i < text_length; i ++) _glyphs[i] = chars[i] - 29;
        
        free(chars);
        
        // Measure text dimensions.
        CGContextSetTextDrawingMode(ctx, kCGTextInvisible);
        CGContextSetTextPosition(ctx, 0, 0);
        CGContextShowGlyphs(ctx, _glyphs, text_length);
        CGPoint textEnd = CGContextGetTextPosition(ctx);
                
        // Calculate text drawing point.
        CGPoint anchor = CGPointMake(textEnd.x * (-0.5), [ufont pointSize] * (-0.25));
        CGPoint p = CGPointApplyAffineTransform(anchor, CGAffineTransformMake(1, 0, 0, -1, 0, 1));
        
        if ([self textAlignment] == NSTextAlignmentCenter)
            alignment.x = [self bounds].size.width * 0.5 + p.x;
        else if ([self textAlignment] == NSTextAlignmentLeft)
            alignment.x = 0;
        else
            alignment.x = [self bounds].size.width - textEnd.x;
        
        alignment.y = [self bounds].size.height * 0.5 + p.y;
    }
    
    // Flip back mirrored text.
    CGContextSetTextMatrix(ctx, CGAffineTransformMakeScale(1, -1));
    
    // Draw shadow.
    CGContextSaveGState(ctx);
    CGContextSetTextDrawingMode(ctx, kCGTextFill);
    CGContextSetFillColorWithColor(ctx, [[self textColor] CGColor]);
    CGContextSetShadowWithColor(ctx, [self shadowOffset], 0, [[self shadowColor] CGColor]);
    CGContextShowGlyphsAtPoint(ctx, alignment.x, alignment.y, _glyphs, text_length);
    CGContextRestoreGState(ctx);
    
    // Draw text clipping path.
    CGContextSetTextDrawingMode(ctx, kCGTextClip);
    CGContextShowGlyphsAtPoint(ctx, alignment.x, alignment.y, _glyphs, text_length);
    
    // Restore text mirroring.
    CGContextSetTextMatrix(ctx, CGAffineTransformIdentity);
    
    if ([self isAnimating]) {
        // Fill text clipping path with gradient.
        CGPoint start = CGPointMake(rect.origin.x + current_position_x, rect.origin.y);
        CGPoint end = CGPointMake(rect.size.width/7 + current_position_x, rect.origin.y);
        
        CGContextDrawLinearGradient(ctx, gradient, start, end, 0);
    }
    
}


- (void) dealloc {
    
    free(_glyphs);
    [timer invalidate];
    CGGradientRelease(gradient);
}

@end