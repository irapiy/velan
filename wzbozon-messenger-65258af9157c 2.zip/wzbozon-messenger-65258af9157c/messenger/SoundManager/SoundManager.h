//
//  SoundManager.h
//  MailClient
//
//  Created by kramnik on 16.05.13.
//  Copyright (c) 2013 1Forma. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SoundManager : NSObject

@property (nonatomic) BOOL usesAudioToolbox;

+ (SoundManager*)sharedSoundManager;

- (void)shootSuccessSound;

- (void)shootErrorSound;

- (void)shootPageFlipSound;

- (void)shootChatReceivedSound;

- (void)shootChatSentSound;

@end
