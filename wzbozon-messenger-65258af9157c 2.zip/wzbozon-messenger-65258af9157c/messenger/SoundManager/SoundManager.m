//
//  SoundManager.m
//  MailClient
//
//  Created by kramnik on 16.05.13.
//  Copyright (c) 2013 1Forma. All rights reserved.
//

#import "SoundManager.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioServices.h>

static SoundManager *sharedSoundManager;

@interface SoundManager()
{
    NSDate *_lastPlayDate;
    
    AVAudioPlayer *_successPlayer;
    AVAudioPlayer *_errorPlayer;
    AVAudioPlayer *_pageFlipPlayer;
    AVAudioPlayer *_chatSentPlayer;
    AVAudioPlayer *_chatReceivedPlayer;
    
    SystemSoundID _successSoundID;
    SystemSoundID _errorSoundID;
    SystemSoundID _pageFlipSoundID;
    SystemSoundID _chatSentSoundID;
    SystemSoundID _chatReceivedSoundID;
}

@end


@implementation SoundManager


- (id)init
{
    self = [super init];
    
    if (self) {
        
        _usesAudioToolbox = YES;

        NSString *path = [[NSBundle mainBundle] pathForResource:@"blip1" ofType:@"wav"];
        NSURL *url = [NSURL fileURLWithPath:path];
        if (_usesAudioToolbox) AudioServicesCreateSystemSoundID((__bridge CFURLRef)url, &_successSoundID);
        else _successPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:NULL];
        
        path =  [[NSBundle mainBundle] pathForResource:@"bass_deny" ofType:@"wav"];
        url = [NSURL fileURLWithPath:path];
        if (_usesAudioToolbox) AudioServicesCreateSystemSoundID((__bridge CFURLRef)url, &_errorSoundID);
        else _errorPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:NULL];
        
        path =  [[NSBundle mainBundle] pathForResource:@"page-flip-4" ofType:@"wav"];
        url = [NSURL fileURLWithPath:path];
        if (_usesAudioToolbox) AudioServicesCreateSystemSoundID((__bridge CFURLRef)url, &_pageFlipSoundID);
        else _pageFlipPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:NULL];

        path =  [[NSBundle mainBundle] pathForResource:@"melodic1_affirm" ofType:@"wav"];
        url = [NSURL fileURLWithPath:path];
        if (_usesAudioToolbox) AudioServicesCreateSystemSoundID((__bridge CFURLRef)url, &_chatSentSoundID);
        else _chatSentPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:NULL];
        
        path =  [[NSBundle mainBundle] pathForResource:@"echo_affirm1" ofType:@"wav"];
        url = [NSURL fileURLWithPath:path];
        if (_usesAudioToolbox) AudioServicesCreateSystemSoundID((__bridge CFURLRef)url, &_chatReceivedSoundID);
        else _chatReceivedPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:NULL];
    }
    
    return self;
}


+ (SoundManager*)sharedSoundManager
{
    static dispatch_once_t once;
    
    dispatch_once(&once, ^{
        
        sharedSoundManager = [[SoundManager alloc] init];
        
    });
    
    return sharedSoundManager;
}


- (void)shootSuccessSound
{
    if (! UD_BOOL(UDKeySoundOn)) return;
    
    if ( [self tooFrequent] ) return;
    
    if (_usesAudioToolbox) AudioServicesPlaySystemSound(_successSoundID);
    else [_successPlayer play];
    
    _lastPlayDate = [NSDate date];
}


- (void)shootErrorSound
{
    if (! UD_BOOL(UDKeySoundOn)) return;
    
    if ( [self tooFrequent] ) return;
    
    if (_usesAudioToolbox) AudioServicesPlaySystemSound(_errorSoundID);
    else [_errorPlayer play];
    
    _lastPlayDate = [NSDate date];
}


- (void)shootPageFlipSound
{
    if (! UD_BOOL(UDKeySoundOn)) return;
    
    if (_usesAudioToolbox) AudioServicesPlaySystemSound(_pageFlipSoundID);
    else [_pageFlipPlayer play];
    
    _lastPlayDate = [NSDate date];
}


- (void)shootChatSentSound
{
    if (! UD_BOOL(UDKeySoundOn)) return;
    
    if ( [self tooFrequent] ) return;
    
    if (_usesAudioToolbox) AudioServicesPlaySystemSound(_chatSentSoundID);
    else [_chatSentPlayer play];
    
    _lastPlayDate = [NSDate date];
}


- (void)shootChatReceivedSound
{
    if (! UD_BOOL(UDKeySoundOn)) return;
    
    if ( [self tooFrequent] ) return;
    
    if (_usesAudioToolbox) AudioServicesPlaySystemSound(_chatReceivedSoundID);
    else [_chatReceivedPlayer play];
    
    _lastPlayDate = [NSDate date];
}


- (BOOL)tooFrequent
{
    if (_lastPlayDate != nil) {
        NSInteger interval = [_lastPlayDate timeIntervalSinceNow];
        if (abs(interval) < 0.5) {
            return YES;
        }
    }
    
    return NO;
}

@end
