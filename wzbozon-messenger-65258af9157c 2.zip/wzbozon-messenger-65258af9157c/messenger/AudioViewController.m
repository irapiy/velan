//
//  AudioViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 02.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "AudioViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface AudioViewController ()
{
    AVAudioPlayer *_audioPlayer;
    BOOL _isMediaPlayerActive;
}

@property (nonatomic, strong) NSString *durationString;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSArray *tableData;
@property (nonatomic) CGFloat cellHeight;

- (void)handleNowPlayingItemChanged:(id)notification;
- (void)handlePlaybackStateChanged:(id)notification;
- (void)handleExternalVolumeChanged:(id)notification;

@end

@implementation AudioViewController


#pragma mark - View lifecycle

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"194-note-2_active"]
                      withFinishedUnselectedImage:[UIImage imageNamed:@"194-note-2"]];
        self.title = LOCS(@"Player");
        

    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden = YES;
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view bringSubviewToFront:self.tableView];
    self.cellHeight = 15;
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeRepeatMode)];
    tapGestureRecognizer.numberOfTapsRequired = 1;
    self.repeatLabel.userInteractionEnabled = YES;
    [self.repeatLabel addGestureRecognizer:tapGestureRecognizer];
    
#if !TARGET_IPHONE_SIMULATOR
    self.musicPlayer = [MPMusicPlayerController iPodMusicPlayer];
    
    // Initial sync of display with music player state
    [self handleNowPlayingItemChanged:nil];
    [self handlePlaybackStateChanged:nil];
    [self handleExternalVolumeChanged:nil];
    
    [self.volumeSlider setValue:0.5 animated:NO];
    _audioPlayer.volume = 0.5;
    
    // Register for music player notifications
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter addObserver:self
                           selector:@selector(handleNowPlayingItemChanged:)
                               name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification
                             object:self.musicPlayer];
    [notificationCenter addObserver:self
                           selector:@selector(handlePlaybackStateChanged:)
                               name:MPMusicPlayerControllerPlaybackStateDidChangeNotification
                             object:self.musicPlayer];
    [notificationCenter addObserver:self
                           selector:@selector(handleExternalVolumeChanged:)
                               name:MPMusicPlayerControllerVolumeDidChangeNotification
                             object:self.musicPlayer];
    [self.musicPlayer beginGeneratingPlaybackNotifications];
    
    if (!_audioPlayer) [self playDefaultAudio];
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(onTimer:) userInfo:nil repeats:YES];
#endif
}


- (void)viewDidUnload
{
    // Stop music player notifications
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification
                                                  object:self.musicPlayer];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MPMusicPlayerControllerPlaybackStateDidChangeNotification
                                                  object:self.musicPlayer];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MPMusicPlayerControllerVolumeDidChangeNotification
                                                  object:self.musicPlayer];
    [self.musicPlayer endGeneratingPlaybackNotifications];
    
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
    self.musicPlayer = nil;
    self.playPauseButton = nil;
    self.songLabel = nil;
    self.artworkImageView = nil;
    self.volumeSlider = nil;
}


#pragma mark Media player notification handlers

- (void)handleNowPlayingItemChanged:(id)notification
{
    if (! _isMediaPlayerActive) return;
    
    MPMediaItem *currentItem = self.musicPlayer.nowPlayingItem;
    if (currentItem == nil) {
        [self.musicPlayer play];
        return;
    }
    
    NSString *songName = [currentItem valueForProperty:MPMediaItemPropertyTitle];
    NSString *artistName = [currentItem valueForProperty:MPMediaItemPropertyAlbumArtist];
    NSString *string = [NSString stringWithFormat:@"%@ - %@", artistName, songName];
    
    self.songLabel.text   = string;
    self.trackNoLabel.text = [NSString stringWithFormat:@"Track no. %d", self.musicPlayer.indexOfNowPlayingItem + 1];
    
    [self updateRepeatLabel];
    
    long totalPlaybackTime = [[[self.musicPlayer nowPlayingItem] valueForProperty: @"playbackDuration"] longValue];
    int tHours = (totalPlaybackTime / 3600);
    int tMins = ((totalPlaybackTime/60) - tHours*60);
    int tSecs = (totalPlaybackTime % 60 );
    self.durationString = (tHours > 0) ? [NSString stringWithFormat:@"%i:%02d:%02d", tHours, tMins, tSecs ] : [NSString stringWithFormat:@"%02d:%02d", tMins, tSecs];
    
    // Display album artwork. self.artworkImageView is a UIImageView.
    CGSize artworkImageViewSize = self.artworkImageView.bounds.size;
    MPMediaItemArtwork *artwork = [currentItem valueForProperty:MPMediaItemPropertyArtwork];
    if (artwork != nil) {
        self.artworkImageView.image = [artwork imageWithSize:artworkImageViewSize];
    } else {
        self.artworkImageView.image = nil;
    }
    
    [self scrollToCurrentItem];
}

// When the playback state changes, set the play/pause button appropriately.
- (void)handlePlaybackStateChanged:(id)notification {
    MPMusicPlaybackState playbackState = self.musicPlayer.playbackState;
    if (playbackState == MPMusicPlaybackStatePaused || playbackState == MPMusicPlaybackStateStopped) {
        
        [self.playPauseButton setImage:nil forState:UIControlStateNormal];
        

    } else if (playbackState == MPMusicPlaybackStatePlaying) {
        
        [self.playPauseButton setImage:[UIImage imageNamed:@"PlayerUI_Play"] forState:UIControlStateNormal];
        
    }
}


// When the volume changes, sync the volume slider
- (void)handleExternalVolumeChanged:(id)notification {
    // self.volumeSlider is a UISlider used to display music volume.
    // self.musicPlayer.volume ranges from 0.0 to 1.0.
    [self.volumeSlider setValue:self.musicPlayer.volume animated:YES];
}



#pragma mark Button actions

- (IBAction)playOrPauseMusic:(id)sender
{
    if (! _isMediaPlayerActive) {
        if (_audioPlayer.playing) {
            [_audioPlayer pause];
        }
        else {
            [_audioPlayer play];
        }
    }
    else {
        MPMusicPlaybackState playbackState = self.musicPlayer.playbackState;
        if (playbackState == MPMusicPlaybackStateStopped || playbackState == MPMusicPlaybackStatePaused || playbackState == MPMusicPlaybackStateInterrupted) {
            [self.musicPlayer play];
        } else if (playbackState == MPMusicPlaybackStatePlaying) {
            [self.musicPlayer pause];
        }
    }
}


- (IBAction)playNextSong:(id)sender
{
    if (! _isMediaPlayerActive) {
        [_audioPlayer pause];
        _audioPlayer = nil;
        _isMediaPlayerActive = YES;
        [self.musicPlayer play];
    }
    [self.musicPlayer skipToNextItem];
}


- (IBAction)playPreviousSong:(id)sender
{
    if (! _isMediaPlayerActive) {
        [_audioPlayer pause];
        _audioPlayer = nil;
        _isMediaPlayerActive = YES;
        [self.musicPlayer play];
    }
    
    static NSTimeInterval skipToBeginningOfSongIfElapsedTimeLongerThan = 3.5;
    
    NSTimeInterval playbackTime = self.musicPlayer.currentPlaybackTime;
    if (playbackTime <= skipToBeginningOfSongIfElapsedTimeLongerThan) {
        [self.musicPlayer skipToPreviousItem];
    } else {
        [self.musicPlayer skipToBeginning];
    }
}


- (IBAction)openMediaPicker:(id)sender
{
#if !TARGET_IPHONE_SIMULATOR
	{
    MPMediaPickerController *mediaPicker = [[MPMediaPickerController alloc] initWithMediaTypes:MPMediaTypeMusic];
    mediaPicker.delegate = self;
    mediaPicker.allowsPickingMultipleItems = YES; // this is the default
    [self presentViewController:mediaPicker animated:YES completion:nil];
    }
#endif
}


- (void)openUserLibrary:(id)sender
{
    UserAudioPickerController *c = [[UserAudioPickerController alloc] initWithStyle:UITableViewStyleGrouped];
    c.delegate = self;
    UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:c];
    [self presentViewController:nc animated:YES completion:nil];
}


- (IBAction)volumeSliderChanged:(id)sender
{
    self.musicPlayer.volume = self.volumeSlider.value;
    
    _audioPlayer.volume = self.volumeSlider.value;
}



#pragma mark MPMediaPickerController delegate methods

- (void)mediaPicker: (MPMediaPickerController *)mediaPicker didPickMediaItems:(MPMediaItemCollection *)mediaItemCollection {
    // We need to dismiss the picker
    [self dismissViewControllerAnimated:YES completion:nil];
    
    // Assign the selected item(s) to the music player and start playback.
    [self.musicPlayer stop];
    [self.musicPlayer setQueueWithItemCollection:mediaItemCollection];
    [self.musicPlayer play];
    
    _isMediaPlayerActive = YES;
    
    self.nextButton.enabled = YES;
    self.playPauseButton.enabled = YES;
    self.prevButton.enabled = YES;
    
    self.tableData = mediaItemCollection.items;
    [self.tableView reloadData];
}


- (void)mediaPickerDidCancel:(MPMediaPickerController *)mediaPicker
{
    // User did not select anything
    // We need to dismiss the picker
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - UserAudioPickerControllerDelegate

- (void)userAudioPicker:(UserAudioPickerController *)userAudioPicker didPickItems:(NSArray *)userAudioItemsArray
{
    if ([userAudioItemsArray count] > 0) {
        
        NSLog(@"Items picked: %@", userAudioItemsArray);                                
        [self playAudioFile:userAudioItemsArray[0]];
        
    }
}


#pragma mark - Other Methods

- (void)playAudioFile:(NSString *)fileName
{
    _isMediaPlayerActive = NO;
    
    NSString *path = [AppDel.documentsDir stringByAppendingPathComponent:fileName];
    NSURL *url = [NSURL fileURLWithPath:path];
    NSError *error = nil;
    _audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
    
    if (! error) {
        
        self.songLabel.text   = fileName;
        self.trackNoLabel.text = [NSString stringWithFormat:@"Track no. 1"];
        self.artworkImageView.image = nil;
        self.nextButton.enabled = YES;
        self.prevButton.enabled = YES;
        
        long totalPlaybackTime = _audioPlayer.duration;
        int tHours = (totalPlaybackTime / 3600);
        int tMins = ((totalPlaybackTime/60) - tHours*60);
        int tSecs = (totalPlaybackTime % 60 );
        self.durationString = (tHours > 0) ? [NSString stringWithFormat:@"%i:%02d:%02d", tHours, tMins, tSecs ] : [NSString stringWithFormat:@"%02d:%02d", tMins, tSecs];
        
        [_audioPlayer play];
        
    }
    else {
        [SVProgressHUD showErrorWithStatus:@"Please, try to select another file"];
    }
}


- (void)playDefaultAudio
{
    _isMediaPlayerActive = YES;

    MPMediaQuery* query = [MPMediaQuery songsQuery];
    NSArray *songs = [query items];
    
    if ([songs count] == 0) return;
    
    MPMediaItem *randomTrack = [songs objectAtIndex:arc4random_uniform([songs count])];

    [self.musicPlayer setQueueWithQuery:query];
    [self.musicPlayer setNowPlayingItem:randomTrack];
    
    self.tableData = songs;
    [self.tableView reloadData];
    
    [self performSelector:@selector(scrollToCurrentItem) withObject:nil afterDelay:0.3];
    
}


- (void)scrollToCurrentItem
{
    NSInteger row = [self.tableData indexOfObject:self.musicPlayer.nowPlayingItem];
    NSLog(@"row:%d", row);
    if (([self.tableData count] > 0) && (row != NSNotFound)) {
        [self.tableView scrollToRowAtIndexPath:INDEX_PATH(row, 0) atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
        [self.tableView reloadRowsAtIndexPaths:[self.tableView indexPathsForVisibleRows] withRowAnimation:UITableViewRowAnimationFade];
    }
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSArray *indexPathsForVisibleRows = [self.tableView indexPathsForVisibleRows];
    NSIndexPath *selectedIndexPath = [indexPathsForVisibleRows lastObject];
    NSLog(@"row to scroll:%d", selectedIndexPath.row);
    [self.tableView scrollToRowAtIndexPath:selectedIndexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
}


- (void)onTimer:(NSTimer *)timer
{
    long currentPlaybackTime = (_isMediaPlayerActive) ? self.musicPlayer.currentPlaybackTime : _audioPlayer.currentTime;
    
    int currentHours = (currentPlaybackTime / 3600);
    int currentMinutes = ((currentPlaybackTime / 60) - currentHours*60);
    int currentSeconds = (currentPlaybackTime % 60);
    NSString *currentTimeString = (currentHours > 0) ? [NSString stringWithFormat:@"%i:%02d:%02d", currentHours, currentMinutes, currentSeconds] : [NSString stringWithFormat:@"%02d:%02d", currentMinutes, currentSeconds];
    
    NSString *string = [NSString stringWithFormat:@"%@ / %@", currentTimeString, self.durationString];
    self.timeLabel.text = string;
}


- (void)changeRepeatMode
{
    if (! _isMediaPlayerActive) return;
    
    // One -> All -> No
    switch (self.musicPlayer.repeatMode) {
        case MPMusicRepeatModeAll:
            [self.musicPlayer setRepeatMode:MPMusicRepeatModeNone];
            break;
        case MPMusicRepeatModeOne:
            [self.musicPlayer setRepeatMode:MPMusicRepeatModeAll];
            break;
        case MPMusicRepeatModeNone:
            [self.musicPlayer setRepeatMode:MPMusicRepeatModeOne];
            break;
        default:
            break;
    }

    [self updateRepeatLabel];
}


- (void)updateRepeatLabel
{
    NSString *repeatModeString = nil;
    switch (self.musicPlayer.repeatMode) {
        case MPMusicRepeatModeAll:
            repeatModeString = @"all";
            break;
        case MPMusicRepeatModeOne:
            repeatModeString = @"one";
            break;
        case MPMusicRepeatModeNone:
            repeatModeString = @"no";
            break;
        default:
            repeatModeString = @"no";
            break;
    }
    NSString *string = [NSString stringWithFormat:@"Repeat: one | all | no"];
    NSMutableAttributedString *repeatString = [[NSMutableAttributedString alloc] initWithString:string];
    NSRange range = [string rangeOfString:@"one | all | no"];
    [repeatString addAttribute:NSForegroundColorAttributeName value:RGB(0x837b6a) range:range];
    range = [string rangeOfString:repeatModeString];
    [repeatString addAttribute:NSForegroundColorAttributeName value:self.repeatLabel.textColor range:range];
    [self.repeatLabel setAttributedText:repeatString];
}


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.tableData count];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return self.cellHeight;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.textLabel.font = [UIFont fontWithName:@"ArialMT" size:10];
        
    }
    
    MPMediaItem *mediaItem = self.tableData[indexPath.row];
    
    cell.textLabel.textColor = (mediaItem == self.musicPlayer.nowPlayingItem) ? [UIColor darkGrayColor] : [UIColor grayColor];
    
    NSString *songName = [mediaItem valueForProperty:MPMediaItemPropertyTitle];
    if (! songName) songName = LOCS(@"Unknown");
    NSString *artistName = [mediaItem valueForProperty:MPMediaItemPropertyAlbumArtist];
    if (! artistName) artistName = LOCS(@"Unknown");
    NSString *string = [NSString stringWithFormat:@"%@ - %@", artistName, songName];
    cell.textLabel.text = string;
    
    return cell;
}


@end
