//
//  UserAudioTableViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 04.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol UserAudioPickerControllerDelegate;

@interface UserAudioPickerController : UITableViewController

@property (nonatomic, unsafe_unretained) id <UserAudioPickerControllerDelegate> delegate;

@end


@protocol UserAudioPickerControllerDelegate <NSObject>

- (void)userAudioPicker: (UserAudioPickerController *)userAudioPicker didPickItems:(NSArray *)userAudioItemsArray;

@end
