//
//  MSGFile.m
//  messenger
//
//  Created by Denis Kutlubaev on 29.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "MSGFile.h"
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"

@implementation MSGFile


#pragma mark - Database operations

- (id)initWithFileID:(NSInteger)fileID messageID:(NSInteger)messageID fileName:(NSString *)fileName contentType:(NSString *)contentType size:(NSInteger)size
{
    self = [super init];
    
    if (self) {
        
        _fileID = fileID;
        _messageID = messageID;
        _fileName = fileName;
        _contentType = contentType;
        _size = size;
        
    }
    
    return self;
}


- (BOOL)addToDb
{
    if ( ! [AppDel.db open] ) {
        return NO;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"INSERT INTO files (message_id, file_name, content_type, size) VALUES (?, ?, ?, ?)" withArgumentsInArray:@[@(self.messageID), self.fileName, self.contentType, @(self.size)]];
    
    [AppDel.db close];
    
    return result;
}


- (BOOL)deleteFromDb
{
    if ( ! [AppDel.db open] ) {
        return NO;
    }
    
    BOOL result = [AppDel.db executeUpdate:@"DELETE FROM files WHERE file_id = ?" withArgumentsInArray:@[@(self.fileID)]];
    
    [AppDel.db close];
    
    return result;
}


+ (NSArray *)retrieveFromDb
{
    NSMutableArray *temp = [NSMutableArray new];
    
    if ( ! [AppDel.db open] ) {
        return nil;
    }
    
    NSMutableString *sql = [NSMutableString new];
    [sql appendString:@"SELECT * FROM files"];
    
    FMResultSet *rs = [AppDel.db executeQuery:sql];
    while ( [rs next] ) {
        
        MSGFile *file = [[MSGFile alloc] initWithFileID:[rs intForColumn:@"file_id"]
                                              messageID:[rs intForColumn:@"message_id"]
                                               fileName:[rs stringForColumn:@"file_name"]
                                            contentType:[rs stringForColumn:@"content_type"]
                                                   size:[rs intForColumn:@"size"]];
		[temp addObject:file];
        
    }
    
    [rs close];
    
    [AppDel.db close];
    
	return temp;
}


@end
