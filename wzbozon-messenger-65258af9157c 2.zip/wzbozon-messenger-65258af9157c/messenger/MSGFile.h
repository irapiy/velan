//
//  MSGFile.h
//  messenger
//
//  Created by Denis Kutlubaev on 29.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MSGFile : NSObject

@property (nonatomic) NSInteger fileID;
@property (nonatomic) NSInteger messageID;
@property (nonatomic, strong) NSString *fileName;
@property (nonatomic, strong) NSString *contentType;
@property (nonatomic) NSInteger size;

#pragma mark - Database operations

- (id)initWithFileID:(NSInteger)fileID messageID:(NSInteger)messageID fileName:(NSString *)fileName contentType:(NSString *)contentType size:(NSInteger)size;

- (BOOL)addToDb;

- (BOOL)deleteFromDb;

+ (NSArray *)retrieveFromDb;

@end
