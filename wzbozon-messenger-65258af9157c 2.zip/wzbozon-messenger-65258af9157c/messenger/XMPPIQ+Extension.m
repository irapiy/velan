//
//  XMPPIQ+Extension.m
//  messenger
//
//  Created by Denis Kutlubaev on 01.08.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "XMPPIQ+Extension.h"

@implementation XMPPIQ (Extension)


- (NSError *)errorFromXMPPIQ
{
    if ([self isErrorIQ]) {
        
        NSXMLElement *errorElement = [self elementForName:@"error"];
        NSUInteger errorCode = [errorElement attributeIntegerValueForName:@"code"];
        NSString *errorType = [errorElement attributeStringValueForName:@"type"];
        NSXMLElement *errorText = [errorElement elementForName:@"text"];
        NSString *errorString = [errorText stringValue];
        
        NSString *errorDescription = [NSString stringWithFormat:@"Type:%@ \n %@", errorType, errorString];
        
        NSError *error = [[NSError alloc] initWithDomain:XMPPStreamErrorDomain code:errorCode userInfo:@{NSLocalizedDescriptionKey: errorDescription}];
        
        return error;
    }
    
    else return nil;
}

@end
