//
//  MySQLConnection.m
//  messenger
//
//  Created by Denis Kutlubaev on 30.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "MySQLConnection.h"

static MySQLConnection *shared;

@implementation MySQLConnection


+ (MySQLConnection *)shared
{
    static MySQLConnection *shared = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        
        shared = [[self alloc] initWithBaseURL:[NSURL URLWithString:API_HOST_NAME]];
        
    });
    
    return shared;
}


- (MySQLConnection *)init
{
    self = [super init];
    
    if (self != nil) {
        
        [self registerHTTPOperationClass:[AFJSONRequestOperation class]];
        
        // Accept HTTP Header; see http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html#sec14.1
        [self setDefaultHeader:@"Accept" value:@"application/json"];
    }
    
    return self;
}


- (void)commandWithParams:(NSMutableDictionary*)params onCompletion:(JSONResponseBlock)completionBlock
{
	NSData* uploadFile = nil;
	if ([params objectForKey:@"file"]) {
		uploadFile = (NSData*)[params objectForKey:@"file"];
		[params removeObjectForKey:@"file"];
	}
    
    NSMutableURLRequest *apiRequest = [self multipartFormRequestWithMethod:@"POST" path:API_PATH parameters:params constructingBodyWithBlock: ^(id <AFMultipartFormData>formData) {
        
		if (uploadFile) {
			[formData appendPartWithFileData:uploadFile name:@"file" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
            
		}
	}];
    
    AFJSONRequestOperation* operation = [[AFJSONRequestOperation alloc] initWithRequest: apiRequest];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        //success!
        completionBlock(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        //failure :(
        completionBlock([NSDictionary dictionaryWithObject:[error localizedDescription] forKey:@"error"]);
    }];
    [operation start];
}


- (NSURL *)urlForImageWithId:(NSNumber*)IdPhoto isThumb:(BOOL)isThumb
{
    NSString *urlString = [NSString stringWithFormat:@"%@/%@upload/%@%@.jpg", API_HOST_NAME, API_PATH, IdPhoto, (isThumb)?@"-thumb":@""];
    return [NSURL URLWithString:urlString];
}


- (void)loginUserWithDelegate:(id<MySQLConnectionDelegate>)delegate
{
    self.delegate = delegate;
    
    ClientInfo *clientInfo = [ClientInfo shared];
    
    NSString *command = @"login";
    NSMutableDictionary *params =[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                  command, @"command",
                                  clientInfo.phone, @"phone",
                                  clientInfo.password, @"pass",
                                  nil];
    
    [AFJSONRequestOperation addAcceptableContentTypes:[NSSet setWithObject:@"text/html"]];
    
    [[MySQLConnection shared] commandWithParams:params
                                   onCompletion:^(NSDictionary *json) {
                    
                                       NSDictionary* res = [[json objectForKey:@"result"] objectAtIndex:0];
                                       
                                       if ([json objectForKey:@"error"] == nil && [[res objectForKey:@"user_id"] intValue] > 0) {
                                           
                                           clientInfo.registered = YES;
                                           clientInfo.loggedIn = YES;
                                           
                                           [self.delegate userDidLogin];
                                           
                                       } else {
                                           
                                           [self.delegate userFailedToLogin];
                                           
                                       }
                                   }];
}


- (void)registerUserWithDelegate:(id<MySQLConnectionDelegate>)delegate
{
    ClientInfo *clientInfo = [ClientInfo shared];
    
    NSString *command = @"register";
    NSMutableDictionary *params =[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                  command, @"command",
                                  clientInfo.phone, @"phone",
                                  clientInfo.password, @"pass",
                                  nil];
    
    [AFJSONRequestOperation addAcceptableContentTypes:[NSSet setWithObject:@"text/html"]];
    
    [[MySQLConnection shared] commandWithParams:params
                               onCompletion:^(NSDictionary *json) {

                                   NSDictionary* res = [[json objectForKey:@"result"] objectAtIndex:0];
                                   
                                   if ([json objectForKey:@"error"]==nil && [[res objectForKey:@"user_id"] intValue]>0) {
                                       
                                       [delegate userDidRegister];
                                       
                                   } else {
                                       
                                       NSLog(@"Failed to register user. Error:%@", [json objectForKey:@"error"]);
                                       
                                       [delegate userFailedToRegister];
                                       
                                   }
                               }];
}


- (NSString *)cleanPhoneNumber:(NSString *)phoneNumber
{
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    
    NSArray *array = [phoneNumber componentsSeparatedByCharactersInSet :[NSCharacterSet whitespaceCharacterSet] ];
    phoneNumber = [array componentsJoinedByString:@""];
    
    return phoneNumber;
}


@end
