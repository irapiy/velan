//
//  StatusesTableViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 13.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "StatusesTableViewController.h"
#import "StatusDetailsViewController.h"

@interface StatusesTableViewController ()



@end

@implementation StatusesTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.title = LOCS(@"Statuses");
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self loadData];
}


- (void)loadData
{
    _tableData = [[[NSUserDefaults standardUserDefaults] arrayForKey:UDKeyStatuses] mutableCopy];
    [self.tableView reloadData];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSInteger numberOfSections = self.tableView.editing ? 2 : 1;
    return numberOfSections;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger numberOfRows = (section == 0) ? [self.tableData count] : 1;
    return numberOfRows;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    }
    
    if (indexPath.section == 1) {
        cell.textLabel.text = LOCS(@"Add new status");
    }
    else {
        cell.textLabel.text = self.tableData[indexPath.row];
    }
    
    if ([self.tableData[indexPath.row] isEqualToString:UD_OBJECT(UDKeyCurrentStatus)]) {
        cell.textLabel.textColor = [UIColor blueColor];
    }
    else {
        cell.textLabel.textColor = [UIColor blackColor];
    }
    
    return cell;
}


- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1)
        return UITableViewCellEditingStyleInsert;
    
    return UITableViewCellEditingStyleDelete;
}


- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    
    if (editing)
        [self.tableView insertSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationTop];
    else
        [self.tableView deleteSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationNone];
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        [self deleteItem:self.tableData[indexPath.row]];
        [self.tableData removeObjectAtIndex:indexPath.row];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        
        [self setEditing:NO animated:NO];
        StatusDetailsViewController *c = [[StatusDetailsViewController alloc] initWithNibName:nil bundle:nil];
        [self.navigationController pushViewController:c animated:YES];
        
    }
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:_tableData[indexPath.row] forKey:UDKeyCurrentStatus];
    [ud synchronize];
    
    [[EJConnection shared] updateCurrentStatus];
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    StatusDetailsViewController *c = [[StatusDetailsViewController alloc] initWithNibName:nil bundle:nil];
    c.status = self.tableData[indexPath.row];
    [self.navigationController pushViewController:c animated:YES];
}


#pragma mark - Other methods

- (void)deleteItem:(NSString *)bookmark
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSMutableArray *items = [[ud arrayForKey:UDKeyStatuses] mutableCopy];
    [items removeObject:bookmark];
    [ud setObject:items forKey:UDKeyStatuses];
    [ud synchronize];
}


@end
