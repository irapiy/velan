//
//  ViewController.m
//
//  Created by Alex Barinov
//  Project home page: http://alexbarinov.github.com/UIBubbleTableView/
//
//  This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//  To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/
//

// 
// Images used in this example by Petr Kratochvil released into public domain
// http://www.publicdomainpictures.net/view-image.php?image=9806
// http://www.publicdomainpictures.net/view-image.php?image=1358
//

#import "ChatViewController.h"
#import "UIBubbleTableView.h"
#import "UIBubbleTableViewDataSource.h"
#import "NSBubbleData.h"
#import "EJConnection.h"
#import "DAKeyboardControl.h"
#import "ContactsTableViewController.h"
#import "HPTextViewInternal.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "NSString+Emojize.h"

typedef enum ChatVisibilityStates {
    ChatVisiblityFullScreen,
    ChatVisiblityKeyboardVisible,
    ChatVisiblityNavBarVisible
} ChatVisiblityState;


@interface ChatViewController ()
{
    NSMutableArray *bubbleData;
    
    CGFloat _containerHeight;
    ChatVisiblityState _chatVisibilityState;
    
    CGRect _savedTableFrame;
}

@property (nonatomic, strong) UIView *keyboard;
@property (nonatomic, readwrite) float originalKeyboardY;

@end

@implementation ChatViewController


#pragma mark - View lifecycle

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.hidesBottomBarWhenPushed = NO;
        
    }
    return self;
}


- (void)loadView
{
    [super loadView];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Background_iPhone5"]];
    
    self.title = self.contact.fullName;
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(actionsClicked:)];
    self.navigationItem.rightBarButtonItem = rightButton;
    
    _chatVisibilityState = ChatVisiblityKeyboardVisible;
    
    _containerHeight = 40;
    CGRect bubbleTableFrame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - KEYBOARD_HEIGHT - NAVBAR_HEIGHT - _containerHeight);
    
    _bubbleTable = [[UIBubbleTableView alloc] initWithFrame:bubbleTableFrame];
    _bubbleTable.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _bubbleTable.bubbleDataSource = self;
    _bubbleTable.snapInterval = 24 * 60 * 60;
    _bubbleTable.showAvatars = NO;
    _bubbleTable.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_bubbleTable];
    
    [self addTextEntryView];
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self selector:@selector(loadData) name:MESSAGES_CHANGED object:nil];
    [nc addObserver:self selector:@selector(keyboardDidShow:) name:UIKeyboardDidShowNotification object:nil];
    [nc addObserver:self selector:@selector(contactIsTyping:) name:CONTACT_IS_TYPING object:nil];
    [nc addObserver:self selector:@selector(contactFinishedTyping:) name:CONTACT_FINISHED_TYPING object:nil];
    
    [_textView becomeFirstResponder];
    
    UITapGestureRecognizer *doubleTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fullScreenClicked:)];
    doubleTapGestureRecognizer.numberOfTapsRequired = 2;
    doubleTapGestureRecognizer.delegate = self;
    [self.view addGestureRecognizer:doubleTapGestureRecognizer];
    
    UITapGestureRecognizer *singleTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(removeKeyboardClicked:)];
    singleTapGestureRecognizer.numberOfTapsRequired = 1;
    singleTapGestureRecognizer.delegate = self;
    [singleTapGestureRecognizer requireGestureRecognizerToFail:doubleTapGestureRecognizer];
    [self.view addGestureRecognizer:singleTapGestureRecognizer];
    
    __weak ChatViewController *temp = self;
    
    self.view.keyboardTriggerOffset = 0;
    
    [self.view addKeyboardPanningWithActionHandler:^(CGRect keyboardFrameInView) {
        
        CGRect containerFrame = temp.containerView.frame;
        containerFrame.origin.y = keyboardFrameInView.origin.y - containerFrame.size.height;
        temp.containerView.frame = containerFrame;
        
        CGRect tableViewFrame = temp.bubbleTable.frame;
        tableViewFrame.size.height = containerFrame.origin.y;
        temp.bubbleTable.frame = tableViewFrame;
        
    }];
    
    [self loadData];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self loadData];
    
    _textView.text = UD_OBJECT(UDKeyNotSentText);
    
    _isVisible = YES;
    
    [[EJConnection shared] resendMyPresence];
}


- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    [[NSUserDefaults standardUserDefaults] setObject:_textView.text forKey:UDKeyNotSentText];
    
    _isVisible = NO;
}


- (void)dealloc
{
    [self.view removeKeyboardControl];
}


#pragma mark - UIBubbleTableViewDataSource implementation

- (NSInteger)rowsForBubbleTable:(UIBubbleTableView *)tableView
{
    return [bubbleData count];
}


- (NSBubbleData *)bubbleTableView:(UIBubbleTableView *)tableView dataForRow:(NSInteger)row
{
    return [bubbleData objectAtIndex:row];
}


#pragma mark - TextView delegate

- (BOOL)growingTextView:(HPGrowingTextView *)growingTextView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@" "]) {
        [[EJConnection shared] sendPrintNotificationToContact:_contact];
    }
    
    return YES;
}


- (void)growingTextView:(HPGrowingTextView *)growingTextView willChangeHeight:(float)height
{
    float diff = (growingTextView.frame.size.height - height);
    
	CGRect r = _containerView.frame;
    r.size.height -= diff;
    r.origin.y += diff;
	_containerView.frame = r;
    
    r = _bubbleTable.frame;
    r.size.height += diff;
    _bubbleTable.frame = r;
    [self scrollToBottom];
}


#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSLog(@"info:%@", info);
    NSLog(@"%@", (NSString *)kUTTypeImage);
    
    if (info[@"UIImagePickerControllerMediaType"] == (NSString *)kUTTypeImage) {
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        // Определение размера изображения
        NSData *imgData = UIImagePNGRepresentation(image);
        NSInteger size = [imgData length];
        self.textView.text = [NSString stringWithFormat:@"Size of image:\n%d bytes", size];
    }
    else if (info[@"UIImagePickerControllerMediaType"] == (NSString *)kUTTypeMovie) {
        NSURL *url = [info objectForKey:UIImagePickerControllerMediaURL];
        self.textView.text = [NSString stringWithFormat:@"Picked a movie at URL %@", [url absoluteString]];
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:NO completion:nil];
}


#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return NO;
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    NSArray *bubbleCells = [self.bubbleTable visibleCells];
    BOOL touchIsInBubble = NO;
    for (UIBubbleTableViewCell *cell in bubbleCells) {
        if (! [cell respondsToSelector:@selector(customView)]) continue;
        CGPoint touchLocation = [touch locationInView:cell.customView];
        if ([cell.customView pointInside:touchLocation withEvent:nil]) {
            touchIsInBubble = YES;
            break;
        }
    }
    
    return (! touchIsInBubble);
}


#pragma mark - Other methods

- (void)sendClicked:(id)sender
{
    NSString *messageBody = _textView.text;
    if ([allTrim(messageBody) length] == 0) return;
    NSString *jidFrom = [[ClientInfo shared] jidString];
    NSString *jidTo = [[self.contact jid] bare];
    NSInteger dateDelivered = [[NSDate date] timeIntervalSince1970];
    MSGMessage *message = [[MSGMessage alloc] initWithMessageID:0 jidFrom:jidFrom jidTo:jidTo messageBody:messageBody dateDelivered:dateDelivered];
    
    [[EJConnection shared] sendMessage:message];
    
    _textView.text = @"";
}


- (void)scrollToBottom
{
    CGPoint bottomOffset = CGPointMake(0, _bubbleTable.contentSize.height - _bubbleTable.bounds.size.height);
    if ( bottomOffset.y > 0 ) {
        [_bubbleTable setContentOffset:bottomOffset animated:YES];
    }
}


- (void)loadData
{
    bubbleData = [NSMutableArray new];
    
    for (MSGMessage *message in self.contact.messages) {
        
        NSBubbleType bubbleType = [message.jidTo isEqualToString:[self.contact.jid bare]] ? BubbleTypeMine : BubbleTypeSomeoneElse;
        
        NSBubbleData *bubble = [NSBubbleData dataWithText:[message.messageBody emojizedString] date:[NSDate dateWithTimeIntervalSince1970:message.dateDelivered] type:bubbleType];
        
        bubble.message = message;
        
        [bubbleData addObject:bubble];
        
    }
    
    [_bubbleTable reloadData];
    
    [self scrollToBottom];
}


- (void)addTextEntryView
{
    _containerView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - _containerHeight, self.view.bounds.size.width, _containerHeight)];
    _containerView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    
	_textView = [[HPGrowingTextView alloc] initWithFrame:CGRectMake(36, 3, 210, _containerHeight)];
    _textView.internalTextView.gestureRecognizers = nil;
    _textView.contentInset = UIEdgeInsetsMake(0, 5, 0, 5);
	_textView.minNumberOfLines = 1;
	_textView.maxNumberOfLines = 6;
	_textView.returnKeyType = UIReturnKeyDefault;
	_textView.font = [UIFont systemFontOfSize:15.0f];
	_textView.delegate = self;
    _textView.internalTextView.scrollIndicatorInsets = UIEdgeInsetsMake(5, 0, 5, 0);
    _textView.backgroundColor = [UIColor whiteColor];
    _textView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
	
    UIImage *rawEntryBackground = [UIImage imageNamed:@"MessageEntryInputField.png"];
    UIImage *entryBackground = [rawEntryBackground stretchableImageWithLeftCapWidth:13 topCapHeight:22];
    UIImageView *entryImageView = [[UIImageView alloc] initWithImage:entryBackground];
    entryImageView.frame = CGRectMake(35, 0, 218, _containerHeight);
    entryImageView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    UIImage *rawBackground = [UIImage imageNamed:@"MessageEntryBackground.png"];
    UIImage *background = [rawBackground stretchableImageWithLeftCapWidth:13 topCapHeight:22];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:background];
    imageView.frame = CGRectMake(0, 0, _containerView.frame.size.width, _containerView.frame.size.height);
    imageView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    UIButton *selectFileButton = [UIButton buttonWithType:UIButtonTypeContactAdd];
    [selectFileButton setFrame:CGRectMake(3, 5, 30, 30)];
    [selectFileButton addTarget:self action:@selector(selectFileClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [_containerView addSubview:imageView];
    [_containerView addSubview:_textView];
    [_containerView addSubview:entryImageView];
    [_containerView addSubview:selectFileButton];
    
    UIButton *doneBtn = [UIButton buttonWithType:UIButtonTypeCustom];
	doneBtn.frame = CGRectMake(_containerView.frame.size.width - 69, 8, 63, 27);
    doneBtn.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin;
	[doneBtn setTitle:LOCS(@"Send") forState:UIControlStateNormal];
    [doneBtn setTitleShadowColor:[UIColor colorWithWhite:0 alpha:0.4] forState:UIControlStateNormal];
    doneBtn.titleLabel.shadowOffset = CGSizeMake (0.0, -1.0);
    doneBtn.titleLabel.font = [UIFont boldSystemFontOfSize:18.0f];
    [doneBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[doneBtn addTarget:self action:@selector(sendClicked:) forControlEvents:UIControlEventTouchUpInside];
    UIImage *sendBtnBackground = [[UIImage imageNamed:@"MessageEntrySendButton.png"] stretchableImageWithLeftCapWidth:13 topCapHeight:0];
    UIImage *selectedSendBtnBackground = [[UIImage imageNamed:@"MessageEntrySendButton.png"] stretchableImageWithLeftCapWidth:13 topCapHeight:0];
    [doneBtn setBackgroundImage:sendBtnBackground forState:UIControlStateNormal];
    [doneBtn setBackgroundImage:selectedSendBtnBackground forState:UIControlStateSelected];
	[_containerView addSubview:doneBtn];
    
    [self.view addSubview:_containerView];
}


- (void)fullScreenClicked:(id)sender
{
    if (_chatVisibilityState != ChatVisiblityFullScreen) {
        
        _savedTableFrame = self.bubbleTable.frame;
        
        [self.view hideKeyboard];
        
        [self.navigationController setNavigationBarHidden:YES animated:YES];
        [[UIApplication sharedApplication] setStatusBarHidden:YES];
        
        self.containerView.hidden = YES;

        CGRect bubbleTableFrame = self.bubbleTable.frame;
        bubbleTableFrame.size.height += _containerHeight;
        self.bubbleTable.frame = bubbleTableFrame;

        _chatVisibilityState = ChatVisiblityFullScreen;

    }
    else {
        
        [[UIApplication sharedApplication] setStatusBarHidden:NO];
        [self.navigationController setNavigationBarHidden:NO animated:YES];
        
        self.containerView.hidden = NO;
        
        _bubbleTable.frame = _savedTableFrame;
        
        [_textView becomeFirstResponder];
        
        _chatVisibilityState = ChatVisiblityNavBarVisible;
    }
}


- (void)removeKeyboardClicked:(id)sender
{
    [self.view hideKeyboard];
}


- (void)keyboardDidShow:(NSNotification *)notification
{
    _chatVisibilityState = ChatVisiblityKeyboardVisible;
    
    [self scrollToBottom];
}


- (void)actionsClicked:(id)sender
{
    BlockAlertView *alert = [[BlockAlertView alloc] initWithTitle:nil message:nil];
    [alert addButtonWithTitle:LOCS(@"Copy all") block:^{
        [self copyAllClicked];
    }];
    
    [alert setCancelButtonWithTitle:LOCS(@"Cancel") block:nil];
    [alert show];
}


- (void)copyAllClicked
{
    [[UIPasteboard generalPasteboard] setString:[self.contact entireChat]];
    [SVProgressHUD showSuccessWithStatus:LOCS(@"Copied!")];
}


- (void)contactIsTyping:(NSNotification *)notification
{
    self.bubbleTable.typingBubble = NSBubbleTypingTypeSomebody;
    [self.bubbleTable reloadData];
    [self scrollToBottom];
}


- (void)contactFinishedTyping:(NSNotification *)notification
{
    self.bubbleTable.typingBubble = NSBubbleTypingTypeNobody;
}


- (void)selectFileClicked:(id)sender
{
    [self.view hideKeyboard];
    
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum]) {
        imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        imagePickerController.mediaTypes = @[(NSString *)kUTTypeImage, (NSString *)kUTTypeMovie];
    }
    
    [self presentViewController:imagePickerController animated:YES completion:nil];
}


- (BOOL)isChatOpenedWith:(XMPPJID *)xmppJID
{
    return ([self.contact.jid isEqualToJID:xmppJID options:XMPPJIDCompareBare] && self.isVisible);
}


@end
