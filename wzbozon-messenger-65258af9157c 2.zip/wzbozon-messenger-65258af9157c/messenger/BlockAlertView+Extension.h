//
//  BlockAlertView+Extension.h
//  messenger
//
//  Created by Denis Kutlubaev on 01.08.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "BlockAlertView.h"

@interface BlockAlertView (Extension)

+ (void)showError:(NSString *)msg;

@end
