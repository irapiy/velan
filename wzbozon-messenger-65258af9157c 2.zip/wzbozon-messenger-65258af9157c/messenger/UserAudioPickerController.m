//
//  UserAudioTableViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 04.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "UserAudioPickerController.h"
#import "NSFileManager+DKAdditionals.h"
#import <MediaPlayer/MediaPlayer.h>

@interface UserAudioPickerController ()
{
    NSArray *_tableData;
    NSMutableArray *_itemsPicked;
}

@end

@implementation UserAudioPickerController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
        _itemsPicked = [NSMutableArray new];
        
    }
    return self;
}


- (void)loadView
{
    [super loadView];
    
    self.title = LOCS(@"User Audio Library");
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.backgroundView = nil;
    
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelClicked:)];
    self.navigationItem.leftBarButtonItem = cancelButton;
    
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneClicked:)];
    self.navigationItem.rightBarButtonItem = doneButton;
    
    [self loadData];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_tableData count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text = _tableData[indexPath.row];
    
    if ([_itemsPicked containsObject:_tableData[indexPath.row]]) {
        cell.textLabel.textColor = [UIColor lightGrayColor];
    }
    else {
        cell.textLabel.textColor = [UIColor blackColor];
    }
    
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *item = _tableData[indexPath.row];
    if (! [_itemsPicked containsObject:item]) {
        [_itemsPicked addObject:item];
        [self doneClicked:nil];
    }
    else {
        [_itemsPicked removeObject:item];
    }
    
    [self.tableView reloadData];
}


#pragma mark - Other methods

- (void)loadData
{
    NSArray *dirContents = [[NSFileManager defaultManager]contentsOfDirectoryAtPath:AppDel.documentsDir error:nil];
    NSPredicate *fltr = [NSPredicate predicateWithFormat:@"self ENDSWITH '.mp3' OR self ENDSWITH '.wav'"];
    _tableData = [dirContents filteredArrayUsingPredicate:fltr];
    
    [self.tableView reloadData];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [_itemsPicked removeAllObjects];
}


- (void)cancelClicked:(id)sender
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}


- (void)doneClicked:(id)sender
{
    [self.delegate userAudioPicker:self didPickItems:_itemsPicked];
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

@end
