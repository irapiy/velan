//
//  MSGMessage.h
//  messenger
//
//  Created by Denis Kutlubaev on 29.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>

@class XMPPMessage;

@interface MSGMessage : NSObject

@property (nonatomic) NSInteger messageID;
@property (nonatomic, strong) NSString *jidFrom;
@property (nonatomic, strong) NSString *jidTo;
@property (nonatomic, strong) NSString *messageBody;
@property (nonatomic) NSInteger dateDelivered;

@property (nonatomic, strong) XMPPMessage *xmppMessage;

#pragma mark - Database operations

- (id)initWithMessageID:(NSInteger)messageID jidFrom:(NSString *)jidFrom jidTo:(NSString *)jidTo messageBody:(NSString *)messageBody dateDelivered:(NSInteger)dateDelivered;

- (BOOL)addToDb;

- (BOOL)deleteFromDb;

+ (NSArray *)retrieveFromDb;

+ (NSArray *)retrieveFromDbWithJIDFrom:(NSString *)jidFrom JIDTo:(NSString *)jidTo;

@end
