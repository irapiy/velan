//
//  StatusesTableViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 13.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StatusesTableViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *tableData;

@end
