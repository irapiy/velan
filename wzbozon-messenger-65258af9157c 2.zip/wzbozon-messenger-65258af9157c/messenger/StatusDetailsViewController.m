//
//  AddStatusViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 17.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "StatusDetailsViewController.h"

@interface StatusDetailsViewController ()

@property (nonatomic, strong) UITextView *textView;

@end

@implementation StatusDetailsViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.title = self.status ? LOCS(@"Editing") : LOCS(@"New Status");
    
    self.textView = [[UITextView alloc] initWithFrame:CGRectMake(10, 10, 300, self.view.frame.size.height - KEYBOARD_HEIGHT - NAVBAR_HEIGHT - 20)];
    self.textView.font = REG_FONT(17);
    [self.view addSubview:self.textView];
    self.textView.text = self.status;
    
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self.textView becomeFirstResponder];
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    NSString *newItem = self.textView.text;
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSMutableArray *items = [[ud arrayForKey:UDKeyStatuses] mutableCopy];
    if (self.status) {
        NSInteger index = [items indexOfObject:self.status];
        [items replaceObjectAtIndex:index withObject:newItem];
    }
    else {
        [items addObject:newItem];
    }
    [ud setObject:items forKey:UDKeyStatuses];
    [ud synchronize];
}

@end
