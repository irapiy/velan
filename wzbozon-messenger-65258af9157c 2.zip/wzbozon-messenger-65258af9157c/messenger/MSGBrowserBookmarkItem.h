//
//  MSGBrowserBookmarkItem.h
//  messenger
//
//  Created by Denis Kutlubaev on 17.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MSGBrowserBookmarkItem : NSObject

@property (nonatomic) NSInteger pageID;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *address;
@property (nonatomic) NSInteger dateAdded;

- (id)initWithPageID:(NSInteger)pageID name:(NSString *)name address:(NSString *)address dateAdded:(NSInteger)dateAdded;

- (BOOL)addToDb;

- (BOOL)deleteFromDb;

+ (NSArray *)retrieveFromDb;

@end
