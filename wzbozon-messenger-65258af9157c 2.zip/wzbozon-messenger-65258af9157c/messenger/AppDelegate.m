//
//  AppDelegate.m
//  messenger
//
//  Created by Denis Kutlubaev on 22.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "AppDelegate.h"
#import "TestFlight.h"
#import "ContactsTableViewController.h"
#import "ChatsTableViewController.h"
#import "SettingsTableViewController.h"
#import "RegistrationViewController.h"
#import "FMDatabase.h"
#import "ChatViewController.h"
#import "WebViewController.h"
#import "AudioViewController.h"
#import "NSFileManager+DKAdditionals.h"
#import "DDLog.h"
#import "DDTTYLogger.h"
#import "AppDelegate.h"


@interface AppDelegate()
{
    
}

@end


@implementation AppDelegate


- (FMDatabase *)db
{
    if (! _db) {
        
        _db = [FMDatabase databaseWithPath:self.databasePath];
        
    }
    
    return _db;
}


- (NSString *)databasePath
{
    if (! _databasePath) {
        
        self.databaseName = @"messenger.sqlite";
        NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDir = [documentPaths objectAtIndex:0];
        _databasePath = [documentsDir stringByAppendingPathComponent:self.databaseName];
        
        NSLog(@"Database Path : %@", self.databasePath);
        NSLog(@"Database Name : %@", self.databaseName);
        
    }
    
    return _databasePath;
}


- (NSString *)documentsDir
{
    if (! _documentsDir) {
        
        NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        _documentsDir = [documentPaths objectAtIndex:0];
        
    }
    
    return _documentsDir;
}


- (UITabBarController *)tabBarController
{
    if (! _tabBarController) {
        
        _tabBarController = [UITabBarController new];
        _tabBarController.delegate = self;
        
        ContactsTableViewController *contactsTableViewController = [[ContactsTableViewController alloc] initWithStyle:UITableViewStylePlain];
        UINavigationController *contactsNavController = [[UINavigationController alloc] initWithRootViewController:contactsTableViewController];
        
        ChatsTableViewController *chatsTableViewController = [[ChatsTableViewController alloc] initWithStyle:UITableViewStylePlain];
        _chatsNavController = [[UINavigationController alloc] initWithRootViewController:chatsTableViewController];
        
        _webViewController = [[WebViewController alloc] initWithAddress:UD_OBJECT(UDKeyDefaultPage)];
        UINavigationController *webNavController = [[UINavigationController alloc] initWithRootViewController:_webViewController];
        
        NSString *nibName = IS_WIDESCREEN ? @"AudioViewController~568h" : @"AudioViewController";
        _audioViewController = [[AudioViewController alloc] initWithNibName:nibName bundle:nil];
        UINavigationController *audioNavController = [[UINavigationController alloc] initWithRootViewController:_audioViewController];
        
        SettingsTableViewController *settingsTableViewController = [[SettingsTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
        UINavigationController *settingsNavController = [[UINavigationController alloc] initWithRootViewController:settingsTableViewController];
        
        [_tabBarController setViewControllers:@[contactsNavController, _chatsNavController, webNavController, audioNavController, settingsNavController]];
        
        [_tabBarController.tabBar setSelectionIndicatorImage:[UIImage imageNamed:@"tabBarSelectionIndicator"]];
    }
    
    return _tabBarController;
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [DDLog addLogger:[DDTTYLogger sharedInstance]];
    
//    [TestFlight setDeviceIdentifier:[[UIDevice currentDevice] uniqueIdentifier]];
    [TestFlight takeOff:@"98e9b2e3-d128-4be2-8edd-f8920a90ea0a"];

	[self checkAndCreateDatabase];
    
    [self executeScriptFromFile:@"SQLScript"];
    
    if (! UD_BOOL(UDKeyDefaultBrowserItemsWereAdded)) {
        
        [self executeScriptFromFile:@"DefaultBrowserItemsScript"];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:UDKeyDefaultBrowserItemsWereAdded];
        [[NSUserDefaults standardUserDefaults] synchronize];
    
    }
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    NSString *phone = UD_OBJECT(UDKeyPhone);
    if (! phone) {
        
        RegistrationViewController *c = [[RegistrationViewController alloc] initWithNibName:@"RegistrationViewController" bundle:nil];
        self.window.rootViewController = c;
        
    }
    else {
        
        self.window.rootViewController = self.tabBarController;
    }
    
    [self.window makeKeyAndVisible];
    
    [self customizeAppearance];
    
    return YES;
}


- (void)applicationWillEnterForeground:(UIApplication *)application
{
    if (AppDel.chatViewController.isVisible) {
        [[NSNotificationCenter defaultCenter] postNotificationName:CONTACT_FINISHED_TYPING object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:MESSAGES_CHANGED object:nil];
    }
}


- (void)applicationDidBecomeActive:(UIApplication *)application
{
    self.isActive = YES;
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
    self.isActive = NO;
}


- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    NSString *jidFrom = [notification.userInfo objectForKey:NotificationInfoKeyFrom];
    XMPPJID *jid = [XMPPJID jidWithString:jidFrom];
    NSString *body = [notification.userInfo objectForKey:NotificationInfoKeyMessage];
    MSGContact *contactFrom;
    for (MSGContact *contact in [[ClientInfo shared] contacts]) {
        if ([contact.jid isEqualToJID:jid]) {
            contactFrom = contact;
            break;
        }
    } 
    
    if (! self.isActive) {
        // Если мы вошли из неактивного состояния через уведомление, открыть чат
        
        [self openChatViewWithContact:contactFrom];
    }
    else if ( ! [AppDel.chatViewController isChatOpenedWith:jid] )
    {
        // Если приложение активно и при этом чат не ведется c текущим контактом, прислать уведомление внутри приложения
        // Чат при этом не открывается
        
        [MPNotificationView notifyWithText:jid.user
                                    detail:body
                                     image:[UIImage imageNamed:@"missingAvatar"]
                                  duration:1.0
                             andTouchBlock:^(MPNotificationView *notificationView) {
                                 
                                 NSLog( @"Received touch for notification with text: %@", notificationView.textLabel.text );
                                 [self openChatViewWithContact:contactFrom];
                                 
                             }];
        [[SoundManager sharedSoundManager] shootChatReceivedSound];
    }
}


#pragma mark - Other methods

- (void)checkAndCreateDatabase
{
	// Check if the SQL database has already been saved to the users phone, if not then copy it over
	BOOL success;
	
	// Create a FileManager object, we will use this to check the status
	// of the database and to copy it over if required
	NSFileManager *fileManager = [NSFileManager defaultManager];
	
	// Check if the database has already been created in the users filesystem
	success = [fileManager fileExistsAtPath:self.databasePath];
	
	// If the database already exists then return without doing anything
	if(success) return;
	
	// If not then proceed to copy the database from the application to the users filesystem
	
	// Get the path to the database in the application package
	NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:self.databaseName];
	
	// Copy the database from the package to the users filesystem
	[fileManager copyItemAtPath:databasePathFromApp toPath:self.databasePath error:nil];
}


- (void)openChatViewWithContact:(MSGContact *)contact
{
    if (self.chatViewController.contact == contact) {
        [[NSNotificationCenter defaultCenter] postNotificationName:CONTACT_FINISHED_TYPING object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:MESSAGES_CHANGED object:nil];
        return;
    }
    
    if (contact != nil) {
    
        self.tabBarController.selectedIndex = 1;
        [self.chatsNavController popToRootViewControllerAnimated:NO];

        self.chatViewController = [[ChatViewController alloc] initWithNibName:nil bundle:nil];
        self.chatViewController.hidesBottomBarWhenPushed = YES;
        self.chatViewController.contact = contact;
        [self.chatsNavController pushViewController:self.chatViewController animated:YES];
    }
}


#pragma mark - UITabBarControllerDelegate

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{

}


#pragma mark - Other methods

- (void)customizeAppearance
{
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"4-light-menu-bar"] forBarMetrics:UIBarMetricsDefault];
    
    UIImage *image = [[UIImage imageNamed:@"4-light-menu-bar"] resizableImageWithCapInsets:UIEdgeInsetsMake(22, 0, 22, 0)];
    [[UIToolbar appearance] setBackgroundImage:image forToolbarPosition:UIToolbarPositionAny barMetrics:UIBarMetricsDefault];
    
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0], UITextAttributeTextColor,
                                [UIColor colorWithRed:0.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:1.0], UITextAttributeTextShadowColor,
                                [NSValue valueWithUIOffset:UIOffsetMake(0, 1)], UITextAttributeTextShadowOffset,
                                [UIFont fontWithName:@"Georgia" size:22], UITextAttributeFont,
                                nil];
    
    [[UINavigationBar appearance] setTitleTextAttributes:attributes];
    
    // UIBarButtonItems
    
    /*image = [[UIImage imageNamed:@"barButtonDone"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 15, 0, 15)];
    [[UIBarButtonItem appearance] setBackgroundImage:image forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    
    image = [[UIImage imageNamed:@"barButtonDoneHighlighted"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 15, 0, 15)];
    [[UIBarButtonItem appearance] setBackgroundImage:image forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
    
    image = [[UIImage imageNamed:@"backButton"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 20, 0, 10)];
    [[UIBarButtonItem appearance] setBackButtonBackgroundImage:image forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    
    image = [[UIImage imageNamed:@"backButtonHighlighted"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 20, 0, 13)];
    [[UIBarButtonItem appearance] setBackButtonBackgroundImage:image forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
    
    NSDictionary *barButtonAttributes = @{
                                          
                                          UITextAttributeFont : [UIFont fontWithName:@"Georgia" size:12],
                                          UITextAttributeTextColor : [UIColor blackColor],
                                          UITextAttributeTextShadowOffset : [NSValue valueWithUIOffset:UIOffsetMake(0, 0)],
                                          UITextAttributeTextShadowColor: RGB(0x000000)
                                          
                                          };
    [[UIBarButtonItem appearance] setTitleTextAttributes:barButtonAttributes forState:UIControlStateNormal];
    [[UIBarButtonItem appearance] setTitleTextAttributes:barButtonAttributes forState:UIControlStateHighlighted];
    [[UIBarButtonItem appearance] setTitleTextAttributes:barButtonAttributes forState:UIControlStateDisabled];*/
    
    // TabBar
    
    [[UITabBarItem appearance] setTitleTextAttributes:@{ UITextAttributeTextColor : [UIColor whiteColor] }
                                             forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ UITextAttributeTextColor : RGB(0xcdbb76) }
                                             forState:UIControlStateHighlighted];
    
    [[UITabBar appearance] setBackgroundImage:[UIImage imageNamed:@"tabbar"]];
    

    // Slider
    
    UIImage *minImage = [[UIImage imageNamed:@"PlayerUI_VolumeTrack"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 15, 0, 15)];
    UIImage *maxImage = [[UIImage imageNamed:@"PlayerUI_Background_off"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 15, 0, 15)];
    UIImage *thumbImage = [UIImage imageNamed:@"PlayerUI_VolumeControl"];
    
    [[UISlider appearance] setMaximumTrackImage:maxImage forState:UIControlStateNormal];
    [[UISlider appearance] setMinimumTrackImage:minImage forState:UIControlStateNormal];
    [[UISlider appearance] setThumbImage:thumbImage forState:UIControlStateNormal];
    [[UISlider appearance] setThumbImage:thumbImage forState:UIControlStateHighlighted];
}


- (BOOL)executeScriptFromFile:(NSString *)fileName
{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"plist"];
    NSArray *instructions = [NSArray arrayWithContentsOfFile:filePath];
    NSLog(@"instructions:%@", instructions);
    
    if ( ! [self.db open] ) {
        return NO;
    }
    
    for (NSString *instruction in instructions) {
        if (! [self.db executeUpdate:instruction]) {
            NSLog(@"Failed to execute instruction:%@", instruction);
        }
    }
    
    [self.db close];
    
    return YES;
}


@end
