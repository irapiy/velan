//
//  SmartTableViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 15.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SmartTableItem.h"

@protocol SmartTableViewControllerDelegate <NSObject>

- (void)itemPicked:(id <SmartTableItem> )item;
- (void)hideSmartTable;

@end


@interface SmartTableViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *tableData;
@property (nonatomic, strong) NSArray *itemsArray;
@property (nonatomic, strong) NSString *searchString;
@property (nonatomic, weak) id <SmartTableViewControllerDelegate> delegate;

@end
