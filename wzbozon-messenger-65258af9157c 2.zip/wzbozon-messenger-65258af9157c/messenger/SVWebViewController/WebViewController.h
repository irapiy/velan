//
//  WebViewController.h
//
//  Created by Denis Kutlubaev on 04.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//
//  https://github.com/samvermette/SVWebViewController

#import <MessageUI/MessageUI.h>
#import "SVModalWebViewController.h"
#import "DocumentPickerController.h"
#import "SmartTableViewController.h"

@interface WebViewController : UIViewController <UITextFieldDelegate, UIGestureRecognizerDelegate, SmartTableViewControllerDelegate>

- (id)initWithAddress:(NSString*)urlString;
- (id)initWithURL:(NSURL*)URL;

@property (nonatomic, strong) UIWebView *mainWebView;
@property (nonatomic, readwrite) SVWebViewControllerAvailableActions availableActions;
@property (nonatomic, strong) NSString *topTitle;

- (void)loadAddress:(NSString *)address;

@end
