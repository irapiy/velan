//
//  SearchTextField.m
//  messenger
//
//  Created by Denis Kutlubaev on 04.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "SearchTextField.h"

@implementation SearchTextField


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        self.textColor = [UIColor darkGrayColor];
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        self.borderStyle = UITextBorderStyleRoundedRect;
        self.font = [UIFont systemFontOfSize:14];
        self.keyboardType = UIKeyboardTypeDefault;
        self.autocapitalizationType = UITextAutocapitalizationTypeNone;
        self.autocorrectionType = UITextAutocorrectionTypeNo;
        self.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.returnKeyType = UIReturnKeyGo;
        
    }
    return self;
}


// placeholder position
- (CGRect)textRectForBounds:(CGRect)bounds
{
    return CGRectInset(bounds, 8, 6);
}


// text position
- (CGRect)editingRectForBounds:(CGRect)bounds
{
    CGRect rect = CGRectMake(5, 5, 180, 18);
    
    NSLog(@"rect:%@", NSStringFromCGRect(rect));
    return rect;
}

@end
