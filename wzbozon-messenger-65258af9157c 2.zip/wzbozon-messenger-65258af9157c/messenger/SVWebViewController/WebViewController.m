//
//  WebViewController.m
//
//  Created by Denis Kutlubaev on 04.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//
//  https://github.com/samvermette/SVWebViewController

#import "WebViewController.h"
#import "SearchTextField.h"
#import "NSFileManager+DKAdditionals.h"
#import "WebViewController.h"
#import "BookmarksTableViewController.h"
#import "MSGBrowserHistoryItem.h"
#import "MSGBrowserBookmarkItem.h"
#import "MSGPrintPageRenderer.h"
#import "AFNetworking.h"
#import "MCCircleButton.h"
#import "BNHtmlPdfKit.h"
#import "BNHtmlPdfKitPageRenderer.h"

#define PPI 326
#define BNSizeMakeWithPPI(width, height) CGSizeMake(width * PPI, height * PPI)

@interface WebViewController () <UIWebViewDelegate, MFMailComposeViewControllerDelegate>
{
    SearchTextField *_addressField;
    UILabel *_label;
    NSURL *_URL;
    BOOL _isFullScreen;
    UIToolbar *_topToolBar;
    NSDictionary *_fileTypesDic;
    dispatch_queue_t _backgroundQueue;
}

@property (nonatomic, strong, readonly) UIBarButtonItem *backBarButtonItem;
@property (nonatomic, strong, readonly) UIBarButtonItem *forwardBarButtonItem;
@property (nonatomic, strong, readonly) UIBarButtonItem *refreshBarButtonItem;
@property (nonatomic, strong, readonly) UIBarButtonItem *stopBarButtonItem;
@property (nonatomic, strong, readonly) UIBarButtonItem *actionBarButtonItem;

@property (strong, nonatomic) SmartTableViewController *smartTableViewController;
@property (strong, nonatomic) UITableView *smartTable;

- (id)initWithAddress:(NSString*)urlString;
- (id)initWithURL:(NSURL*)URL;

@end


@implementation WebViewController

@synthesize availableActions;

@synthesize backBarButtonItem, forwardBarButtonItem, refreshBarButtonItem, stopBarButtonItem, actionBarButtonItem;

#pragma mark - setters and getters


- (UIBarButtonItem *)backBarButtonItem {
    
    if (! backBarButtonItem) {
        backBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"SVWebViewController.bundle/iPhone/back"] style:UIBarButtonItemStylePlain target:self action:@selector(goBackClicked:)];
        backBarButtonItem.imageInsets = UIEdgeInsetsMake(2.0f, 0.0f, -2.0f, 0.0f);
		backBarButtonItem.width = 18.0f;
    }
    return backBarButtonItem;
}

- (UIBarButtonItem *)forwardBarButtonItem {
    
    if (! forwardBarButtonItem) {
        forwardBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"SVWebViewController.bundle/iPhone/forward"] style:UIBarButtonItemStylePlain target:self action:@selector(goForwardClicked:)];
        forwardBarButtonItem.imageInsets = UIEdgeInsetsMake(2.0f, 0.0f, -2.0f, 0.0f);
		forwardBarButtonItem.width = 18.0f;
    }
    return forwardBarButtonItem;
}

- (UIBarButtonItem *)refreshBarButtonItem {
    
    if (! refreshBarButtonItem) {
        refreshBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(reloadClicked:)];
    }
    
    return refreshBarButtonItem;
}

- (UIBarButtonItem *)stopBarButtonItem {
    
    if (! stopBarButtonItem) {
        stopBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemStop target:self action:@selector(stopClicked:)];
    }
    return stopBarButtonItem;
}

- (UIBarButtonItem *)actionBarButtonItem {
    
    if (! actionBarButtonItem) {
        actionBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(actionButtonClicked:)];
    }
    return actionBarButtonItem;
}


#pragma mark - Initialization

- (id)initWithAddress:(NSString *)urlString {
    return [self initWithURL:[NSURL URLWithString:urlString]];
}

- (id)initWithURL:(NSURL*)pageURL {
    
    if(self = [super init]) {
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"41-feed_active"]
                      withFinishedUnselectedImage:[UIImage imageNamed:@"41-feed"]];
        self.title = LOCS(@"Browser");
        
        _URL = pageURL;
        self.availableActions = SVWebViewControllerAvailableActionsOpenInSafari | SVWebViewControllerAvailableActionsMailLink;
    }
    
    return self;
}

- (id)init
{
    self = [super init];
    
    if (self) {
        
    }
    return self;
}


- (UIWebView *)mainWebView
{
    if (! _mainWebView) {
        
        _mainWebView = [[UIWebView alloc] init];
        _mainWebView.delegate = self;
        _mainWebView.scalesPageToFit = YES;
        _mainWebView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    }
    
    return _mainWebView;
}


#pragma mark - View lifecycle

- (void)loadView
{
    [super loadView];
    
    _fileTypesDic = @{
                      @"application/msword": @"doc",
                      @"application/vnd.ms-excel": @"xls",
                      @"application/vnd.ms-powerpoint": @"ppt",
                      @"application/vnd.openxmlformats-officedocument.wordprocessingml.document": @"doc",
                      @"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": @"xls",
                      @"application/vnd.openxmlformats-officedocument.presentationml.presentation": @"ppt",
                      @"application/pdf": @"pdf",
                      @"text/plain": @"txt",
                      @"text/rtf": @"rtf",
                      @"text/x-rtf": @"rtf",
                      @"text/richtext": @"rtf",
                      @"text/html": @"html",
                      @"application/octet-stream": @"txt",
                      @"image/jpeg": @"jpg",
                      @"image/png": @"png",
                      @"image/tiff": @"tiff",
                      @"image/gif": @"gif",
                      @"image/bmp": @"bmp",
                      @"audio/mpeg": @"mp3",
                      @"image/jpg": @"jpg"
                      };
    
    _backgroundQueue = dispatch_queue_create("browser background queue", nil);
    
    self.view.backgroundColor = RGB(0xdbdbdb);
    self.navigationController.navigationBarHidden = YES;

    CGRect webViewFrame = self.view.bounds;
    webViewFrame.origin.y = 55;
    webViewFrame.size.height -= (55 + 49);
    [self.mainWebView setFrame:webViewFrame];
    [self.view addSubview:self.mainWebView];
    
    CGRect topToolBarFrame = CGRectMake(0, 0, self.view.frame.size.width, 55);
    _topToolBar = [[UIToolbar alloc] initWithFrame:topToolBarFrame];
    _topToolBar.backgroundColor = [UIColor blackColor];
    _topToolBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:_topToolBar];
    
    UIImage *image = [UIImage imageNamed:@"BookmarksNavbar"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:CGRectMake(5, 13, 40, 35)];
    [button.imageView setContentMode:UIViewContentModeScaleAspectFill];
    [button setImage:image forState:UIControlStateNormal];
    
    [button addTarget:self action:@selector(bookmarksClicked:) forControlEvents:UIControlEventTouchUpInside];
    [_topToolBar addSubview:button];
    
    image = [UIImage imageNamed:@"UIButtonBarAction"];
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button.imageView setContentMode:UIViewContentModeScaleAspectFill];
    [button setImage:image forState:UIControlStateNormal];
    [button addTarget:self action:@selector(actionsClicked:) forControlEvents:UIControlEventTouchUpInside];
    [button setFrame:CGRectMake(5 + 40 + 5 + 220 + 5, 13, 40, 35)];
    [_topToolBar addSubview:button];
    
    _addressField = [[SearchTextField alloc] initWithFrame:CGRectMake(5 + 40 + 5, 18, 220, 30)];
    _addressField.delegate = self;
    _addressField.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [_topToolBar addSubview:_addressField];
    
    CGRect labelFrame = CGRectMake(0, 0, self.view.frame.size.width, 16);
    _label = [[UILabel alloc] initWithFrame:labelFrame];
    _label.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _label.backgroundColor = [UIColor clearColor];
    _label.font = BOLD_FONT(12);
    _label.textAlignment = NSTextAlignmentCenter;
    [_topToolBar addSubview:_label];
    
    UITapGestureRecognizer *gr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fullScreenClicked:)];
    gr.numberOfTapsRequired = 2;
    gr.delegate = self;
    [self.view addGestureRecognizer:gr];
    
    CGPoint center = CGPointMake(SCREEN_WIDTH / 2.0, SCREEN_HEIGHT / 2.0);
    NSLog(@"%@", NSStringFromCGPoint(center));
    
    /*CGFloat buttonY = IS_WIDESCREEN ? center.y * 1.5 : center.y * 1.5;
    
    MCCircleButton *nextButton = [[MCCircleButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44) target:self action:@selector(nextClicked) imageName:@"next"];
    nextButton.center = CGPointMake(center.x * 1.7, buttonY);
    [self.view addSubview:nextButton];
    
    MCCircleButton *prevButton = [[MCCircleButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44) target:self action:@selector(prevClicked) imageName:@"prev"];
    prevButton.center = CGPointMake(center.x * 0.3, buttonY);
    [self.view addSubview:prevButton];*/
}


- (void)viewDidLoad
{
	[super viewDidLoad];
    
    //[self updateToolbarItems];
    
    if ([self.topTitle length] == 0) {
        _addressField.text = UD_OBJECT(UDKeyDefaultPage);
        [self loadAddress:UD_OBJECT(UDKeyDefaultPage)];
    }
}


- (void)viewDidUnload {
    [super viewDidUnload];
    _mainWebView = nil;
    backBarButtonItem = nil;
    forwardBarButtonItem = nil;
    refreshBarButtonItem = nil;
    stopBarButtonItem = nil;
    actionBarButtonItem = nil;
}

- (void)viewWillAppear:(BOOL)animated {
    NSAssert(self.navigationController, @"SVWebViewController needs to be contained in a UINavigationController. If you are presenting SVWebViewController modally, use SVModalWebViewController instead.");
    
	[super viewWillAppear:animated];
	
    /*if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        [self.navigationController setToolbarHidden:NO animated:animated];
    }*/
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    /*if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        [self.navigationController setToolbarHidden:YES animated:animated];
    }*/
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    
    if (IPAD)
        return YES;
    
    return toInterfaceOrientation != UIInterfaceOrientationPortraitUpsideDown;
}

/*#pragma mark - Toolbar

- (void)updateToolbarItems {
    self.backBarButtonItem.enabled = self.mainWebView.canGoBack;
    self.forwardBarButtonItem.enabled = self.mainWebView.canGoForward;
    self.actionBarButtonItem.enabled = !self.mainWebView.isLoading;
    
    UIBarButtonItem *refreshStopBarButtonItem = self.mainWebView.isLoading ? self.stopBarButtonItem : self.refreshBarButtonItem;
    
    UIBarButtonItem *fixedSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    fixedSpace.width = 5.0f;
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    if (IPAD) {
        NSArray *items;
        CGFloat toolbarWidth = 250.0f;
        
        if(self.availableActions == 0) {
            toolbarWidth = 200.0f;
            items = [NSArray arrayWithObjects:
                     fixedSpace,
                     refreshStopBarButtonItem,
                     flexibleSpace,
                     self.backBarButtonItem,
                     flexibleSpace,
                     self.forwardBarButtonItem,
                     fixedSpace,
                     nil];
        } else {
            items = [NSArray arrayWithObjects:
                     fixedSpace,
                     refreshStopBarButtonItem,
                     flexibleSpace,
                     self.backBarButtonItem,
                     flexibleSpace,
                     self.forwardBarButtonItem,
                     flexibleSpace,
                     self.actionBarButtonItem,
                     fixedSpace,
                     nil];
        }
        
        UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, toolbarWidth, 44.0f)];
        toolbar.items = items;
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:toolbar];
    } 
    
    else {
        NSArray *items;
        
        if(self.availableActions == 0) {
            items = [NSArray arrayWithObjects:
                     flexibleSpace,
                     self.backBarButtonItem, 
                     flexibleSpace,
                     self.forwardBarButtonItem,
                     flexibleSpace,
                     refreshStopBarButtonItem,
                     flexibleSpace,
                     nil];
        } else {
            items = [NSArray arrayWithObjects:
                     fixedSpace,
                     self.backBarButtonItem, 
                     flexibleSpace,
                     self.forwardBarButtonItem,
                     flexibleSpace,
                     refreshStopBarButtonItem,
                     flexibleSpace,
                     self.actionBarButtonItem,
                     fixedSpace,
                     nil];
        }
        
        self.toolbarItems = items;
    }
}*/


#pragma mark - UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    //[self updateToolbarItems];
}


- (void)webViewDidFinishLoad:(UIWebView *)webView
{    
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    
    NSString *title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    if ([title length] != 0) {
        self.topTitle = title;
        _addressField.text = self.mainWebView.request.URL.absoluteString;
        [self savePageToHistory];
    }
    else {
        _addressField.text = self.topTitle;
    }
    
    [self updateTopLabel];
}


- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}


- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if(navigationType == UIWebViewNavigationTypeOther) {
        NSURL *requestedURL = [request URL];
        NSString *fileExtension = [[requestedURL pathExtension] lowercaseString];

        if (fileExtension != nil) {
            NSArray *allTypes = [_fileTypesDic allKeysForObject:fileExtension];
            NSString *mimeType = ([allTypes count] > 0) ? allTypes[0] : nil;
            
            if ((mimeType)&&(! [mimeType isEqualToString:@"text/html"])) {
                
                BlockActionSheet *sheet = [[BlockActionSheet alloc] initWithTitle:LOCS(@"Download file?")];
                [sheet addButtonWithTitle:LOCS(@"Download") block:^{
                    [self downloadFileFromURL:requestedURL];
                }];
                [sheet setCancelButtonWithTitle:LOCS(@"Cancel") block:nil];
                [sheet showInView:self.view];
                return NO;
            }
        }
    }
    
    return YES;
}



#pragma mark -
#pragma mark MFMailComposeViewControllerDelegate

- (void)mailComposeController:(MFMailComposeViewController *)controller 
          didFinishWithResult:(MFMailComposeResult)result 
                        error:(NSError *)error 
{
	[self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - UITextFieldDelegate

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self loadAddress:allTrim(textField.text)];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *searchString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    [self.view addSubview:self.smartTable];

    [self.smartTableViewController setSearchString:searchString];

	return YES;
}


#pragma mark - Other methods


- (void)updateTopLabel
{    
    if (_label == nil) return;
    
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:self.topTitle];
    NSRange range = NSMakeRange(0, [attString length]);
    [attString addAttribute:NSFontAttributeName value:_label.font range:range];
    [attString addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    
    NSShadow* shadow = [[NSShadow alloc] init];
    shadow.shadowColor = [UIColor lightGrayColor];
    shadow.shadowOffset = CGSizeMake(0.0f, 1.0f);
    [attString addAttribute:NSShadowAttributeName value:shadow range:range];
    
    _label.attributedText = attString;
}


- (NSString *)getSearchQuery:(NSString *)urlString
{
    NSString *translatedToGoogleSearchQuery=nil;
    
    NSString *encodedSearchTerm = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    translatedToGoogleSearchQuery = [NSString stringWithFormat:@"https://encrypted.google.com/search?q=%@",encodedSearchTerm];
    
    return translatedToGoogleSearchQuery;
}


- (void)loadAddress:(NSString *)address
{
    [_addressField resignFirstResponder];
    [self.smartTable removeFromSuperview];
    
    if ([address rangeOfString:@" "].location != NSNotFound
        || [address rangeOfString:@"."].location == NSNotFound) {
        
        address = [self getSearchQuery:address];
        
    } else {
        
        if (([address rangeOfString:@"http://" options:NSCaseInsensitiveSearch].location == NSNotFound)&&([address rangeOfString:@"https://" options:NSCaseInsensitiveSearch].location == NSNotFound)) {

            address = [@"http://" stringByAppendingString:address];

        }
        
    }
    
    _URL = [NSURL URLWithString:address];
    _addressField.text = address;
    
    if ( self.mainWebView ) {
        
        [self.mainWebView loadRequest:[NSURLRequest requestWithURL:_URL]];
        
    }
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}


- (void)fullScreenClicked:(id)sender
{
    NSLog(@"Full screen clicked");
    
    if (! _isFullScreen) {
        
        CGRect frame = self.mainWebView.frame;
        frame.origin.y -= _topToolBar.frame.size.height;
        frame.size.height += (_topToolBar.frame.size.height + self.navigationController.toolbar.frame.size.height);
        
        [UIView animateWithDuration:0.3
                         animations:^{
                             
                             self.mainWebView.frame = frame;
                             
        }
                         completion:^(BOOL completed){
                             
                             _topToolBar.hidden = YES;
                             //self.navigationController.toolbarHidden = YES;
                             _isFullScreen = YES;
            
        }];
    }
    else {
        
        CGRect frame = self.mainWebView.frame;
        frame.origin.y += _topToolBar.frame.size.height;
        frame.size.height -= (_topToolBar.frame.size.height + self.navigationController.toolbar.frame.size.height);
        
        _topToolBar.hidden = NO;
        //self.navigationController.toolbarHidden = NO;
        
        [UIView animateWithDuration:0.3
                         animations:^{
                             
                             self.mainWebView.frame = frame;
                             
                         }
                         completion:^(BOOL completed){
                             
                             _isFullScreen = NO;
                             
                         }];
        
    }
}


- (void)nextClicked
{
    [self.mainWebView goForward];
}


- (void)prevClicked
{
    [self.mainWebView goBack];
}


- (void)actionsClicked:(id)sender
{
    BlockActionSheet *sheet = [[BlockActionSheet alloc] initWithTitle:nil];
    [sheet addButtonWithTitle:LOCS(@"Add Bookmark") block:^{
        [self addBookmarkClicked];
    }];
    [sheet addButtonWithTitle:LOCS(@"Back") block:^{
        [self prevClicked];
    }];
    [sheet addButtonWithTitle:LOCS(@"Forward") block:^{
        [self nextClicked];
    }];
    [sheet addButtonWithTitle:LOCS(@"Reload") block:^{
        [self.mainWebView reload];
    }];
    [sheet addButtonWithTitle:LOCS(@"Save/Share") block:^{
        [self showShareSaveOptions];
    }];
    [sheet setCancelButtonWithTitle:LOCS(@"Cancel") block:^{}];
    [sheet showInView:self.view];
}


- (void)showShareSaveOptions
{
    NSURL *url = self.mainWebView.request.URL;
    NSString *sheetTitle = url.absoluteString;
    int maxLength = 80;
    if (sheetTitle.length > maxLength)
        sheetTitle = [NSString stringWithFormat:@"%@ ...", [sheetTitle substringToIndex:maxLength]];
    BlockActionSheet *sheet = [[BlockActionSheet alloc] initWithTitle:sheetTitle];
    
    [sheet addButtonWithTitle:LOCS(@"Copy Link") block:^{
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = self.mainWebView.request.URL.absoluteString;
    }];
    
    [sheet addButtonWithTitle:LOCS(@"Open in Safari") block:^{
        [[UIApplication sharedApplication] openURL:url];
    }];
    
    [sheet addButtonWithTitle:LOCS(@"Mail Link to this Page") block:^{
        MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init];
		mailViewController.mailComposeDelegate = self;
        [mailViewController setSubject:[self.mainWebView stringByEvaluatingJavaScriptFromString:@"document.title"]];
  		[mailViewController setMessageBody:self.mainWebView.request.URL.absoluteString isHTML:NO];
		mailViewController.modalPresentationStyle = UIModalPresentationFormSheet;
		[self presentViewController:mailViewController animated:YES completion:nil];
    }];
    
    // Отображается кнопка "Сохранить файл", если тип файла определен
    NSString *fileExtension = [[url pathExtension] lowercaseString];
    NSArray *allTypes = [_fileTypesDic allKeysForObject:fileExtension];
    NSString *mimeType = ([allTypes count] > 0) ? allTypes[0] : nil;
    
    if (mimeType != nil) {
        [sheet addButtonWithTitle:LOCS(@"Save file") block:^{
            
            NSString *fileName = [url lastPathComponent];
            NSString *filePath = [AppDel.documentsDir stringByAppendingPathComponent:fileName];
            
            NSData *tmp = [NSData dataWithContentsOfURL:url];
            if (tmp != nil) {
                NSError *error = nil;
                [tmp writeToFile:filePath options:NSDataWritingAtomic error:&error];
                if (error != nil) {
                    NSLog(@"Failed to save the file: %@", [error description]);
                } else {
                    [SVProgressHUD showSuccessWithStatus:LOCS(@"File saved!")];
                }
            } else {
                // File could notbe loaded -> handle errors
            }
        }];
    }
    else {
        
        [sheet addButtonWithTitle:LOCS(@"Save Page As WebPage") block:^{
            
            NSData *data = [NSData dataWithContentsOfURL:url];
            NSString *fileName = [NSString stringWithFormat:@"%@.webpage", _label.text];
            NSString *filePath = [AppDel.documentsDir stringByAppendingPathComponent:fileName];
            [data writeToFile:filePath atomically:YES];
            [SVProgressHUD showSuccessWithStatus:LOCS(@"Page saved!")];
            
        }];
        
        [sheet addButtonWithTitle:LOCS(@"Save Page As PDF") block:^{
            
            [self saveCurrentPageAsPDF];
            
        }];
    }

    [sheet setCancelButtonWithTitle:LOCS(@"Cancel") block:^{}];
	
    [sheet showInView:self.view];
}


- (void)doneButtonClicked:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)addBookmarkClicked
{
    MSGBrowserBookmarkItem *browserBookmarkItem = [[MSGBrowserBookmarkItem alloc] initWithPageID:0 name:self.topTitle address:_addressField.text dateAdded:[[NSDate date] timeIntervalSince1970]];
    [browserBookmarkItem addToDb];
    
    [SVProgressHUD showSuccessWithStatus:LOCS(@"Bookmark added!")];
}


- (void)bookmarksClicked:(id)sender
{
    BookmarksTableViewController *c = [[BookmarksTableViewController alloc] initWithNibName:@"BookmarksTableViewController" bundle:nil];
    UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:c];
    [self presentViewController:nc animated:YES completion:nil];
}


- (void)savePageToHistory
{
    MSGBrowserHistoryItem *browserHistoryItem = [[MSGBrowserHistoryItem alloc] initWithPageID:0 name:self.topTitle address:_addressField.text dateAdded:[[NSDate date] timeIntervalSince1970]];
    [browserHistoryItem addToDb];
}


- (void)downloadFileFromURL:(NSURL *)url
{
    __block NSString *status = [NSString stringWithFormat:@"%@ %.f%%", LOCS(@"Downloading"), 0.0];
    [SVProgressHUD showProgress:0 status:status];
    
    NSString *fileName = [url lastPathComponent];
    NSString *filePath = [AppDel.documentsDir stringByAppendingPathComponent:fileName];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    AFURLConnectionOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    operation.outputStream = [NSOutputStream outputStreamToFileAtPath:filePath append:NO];
    
    [operation setDownloadProgressBlock:
     ^(NSInteger bytesRead, long long totalBytesRead, long long totalBytesExpectedToRead) {
         
        CGFloat progress = (float)totalBytesRead / totalBytesExpectedToRead;
        status = [NSString stringWithFormat:@"%@ %.f%%", LOCS(@"Downloading"), progress * 100];
        [SVProgressHUD showProgress:progress status:status];
        
    }];
    
    [operation setCompletionBlock:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            [SVProgressHUD showSuccessWithStatus:LOCS(@"File saved!")];
        });
    }];
    
    [operation start];
}


/*- (void)saveCurrentPageAsPDF
{
    [SVProgressHUD show];
    [SVProgressHUD setStatus:@"Saving ..."];
    
    NSString *fileName = [NSString stringWithFormat:@"%@.pdf", _label.text];
    NSString *filePath = [AppDel.documentsDir stringByAppendingPathComponent:fileName];
    
    CGSize pageSize = [self.mainWebView sizeThatFits:CGSizeZero];
    CGRect pageRect = CGRectMake(0, 0, pageSize.width, pageSize.height);
    
    CGFloat screenHeight = self.mainWebView.bounds.size.height;
    int pages = ceil(pageSize.height / screenHeight);
    
    NSMutableData *pdfData = [NSMutableData data];
    
    UIGraphicsBeginPDFContextToData(pdfData, pageRect, nil);
    
    // Начало страницы, у нас будет всего 1 страница, которая содержит все данные.
    // Если требуется сделать много страниц, то эту строку нужно перенести внутрь цикла.
    UIGraphicsBeginPDFPage();
    CGContextRef currentContext = UIGraphicsGetCurrentContext();
    
    // Запоминаем фрейм
    CGRect frame = self.mainWebView.frame;
    for (int i = 0; i < pages; i++) {
        
        if ((i+1) * screenHeight  > pageSize.height) {
            CGRect f = self.mainWebView.frame;
            f.size.height -= (((i+1) * screenHeight) - pageSize.height);
            [self.mainWebView setFrame:f];
        }
        
        [[[self.mainWebView subviews] lastObject] setContentOffset:CGPointMake(0, screenHeight * i) animated:NO];
        [self.mainWebView.layer renderInContext:currentContext];
        
        // Смещаем Context вниз на величину экрана, чтобы рисовать не поверх, а ниже в следующий раз.
        CGContextTranslateCTM(UIGraphicsGetCurrentContext(), 0, screenHeight);
    }
    
    UIGraphicsEndPDFContext();
    
    [self.mainWebView setFrame:frame];
    [[[self.mainWebView subviews] lastObject] setContentOffset:CGPointMake(0,0) animated:NO];
    
    [pdfData writeToFile:filePath atomically:YES];
    
    [SVProgressHUD showSuccessWithStatus:LOCS(@"Page Saved to PDF!")];
}*/


- (void)saveCurrentPageAsPDF
{
    NSString *fileName = [NSString stringWithFormat:@"%@.pdf", _label.text];
    NSString *filePath = [AppDel.documentsDir stringByAppendingPathComponent:fileName];
    
    UIPrintFormatter *formatter = self.mainWebView.viewPrintFormatter;
    
    BNHtmlPdfKitPageRenderer *renderer = [[BNHtmlPdfKitPageRenderer alloc] init];
    renderer.topAndBottomMarginSize = 0;
    renderer.leftAndRightMarginSize = 0;
    
    [renderer addPrintFormatter:formatter startingAtPageAtIndex:0];
    
    NSMutableData *currentReportData = [NSMutableData data];
    
    CGSize pageSize = [_mainWebView sizeThatFits:CGSizeZero];
    NSLog(@"page size:%@", NSStringFromCGSize(pageSize));
    CGRect pageRect = CGRectMake(0, 0, pageSize.width, pageSize.height);
    
    UIGraphicsBeginPDFContextToData(currentReportData, pageRect, nil);
    
    [renderer prepareForDrawingPages:NSMakeRange(0, 1)];
    
    int pages = [renderer numberOfPages];
    
    for (int i = 0; i < pages; i++) {
        UIGraphicsBeginPDFPage();
        [renderer drawPageAtIndex:i inRect:renderer.paperRect];
    }
    
    UIGraphicsEndPDFContext();
    
    [currentReportData writeToFile:filePath atomically:YES];
    
    [SVProgressHUD showSuccessWithStatus:LOCS(@"Page Saved to PDF!")];
}


#pragma mark - SmartTable

- (SmartTableViewController *)smartTableViewController
{
    if (! _smartTableViewController) {
        _smartTableViewController = [[SmartTableViewController alloc] initWithStyle:UITableViewStylePlain];
        _smartTableViewController.delegate = self;
    }
    
    _smartTableViewController.itemsArray = [MSGBrowserHistoryItem retrieveFromDb];
    
    return _smartTableViewController;
}


- (UITableView *)smartTable
{
    if (! _smartTable) {
        _smartTable = self.smartTableViewController.tableView;
        CGRect frame = _smartTable.frame;
        frame.origin.y = _topToolBar.frame.size.height;
        
        frame.size.height = self.view.frame.size.height - KEYBOARD_HEIGHT - _topToolBar.frame.size.height;
        
        _smartTable.frame = frame;
    }
    
    return _smartTable;
}


- (void)itemPicked:(id <SmartTableItem> )item
{
    [self.smartTable removeFromSuperview];

    _addressField.text = [item detailText];
    [_addressField resignFirstResponder];
}


- (void)hideSmartTable
{
    [self.smartTable removeFromSuperview];
}


@end
