//
//  HistorySmartTableViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 15.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "SmartTableViewController.h"

@interface SmartTableViewController ()

@end

@implementation SmartTableViewController


- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    self.tableData = [[NSMutableArray alloc] initWithCapacity:[self.itemsArray count]];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.tableData count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    }
    
    id <SmartTableItem> item = [self.tableData objectAtIndex:indexPath.row];
    cell.textLabel.text = [item text];
    cell.detailTextLabel.text = [item detailText];
    
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    id <SmartTableItem> item = self.tableData[indexPath.row];

    [self.delegate itemPicked:item];
}


- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    id <SmartTableItem> item = self.tableData[indexPath.row];
    [SVProgressHUD showSuccessWithStatus:[item text]];
}


#pragma mark - Other methods

- (void)setSearchString:(NSString *)searchString
{
    _searchString = searchString;
    
    [_tableData removeAllObjects];
    
    for (id <SmartTableItem> item in self.itemsArray)
    {
        BOOL a = [[item text] rangeOfString:searchString options:NSCaseInsensitiveSearch].location == 0;
        BOOL b = [[item detailText] rangeOfString:searchString options:NSCaseInsensitiveSearch].location == 0;
        if (a || b) {
            [self.tableData addObject:item];
        }
    }
    
    // Если ни один элемент не найден, прячем таблицу
    if ([_tableData count] == 0) {
        //[self.delegate hideSmartTable];
        [self.tableData addObjectsFromArray:self.itemsArray];
    }
    
    [self.tableView reloadData];
}

@end
