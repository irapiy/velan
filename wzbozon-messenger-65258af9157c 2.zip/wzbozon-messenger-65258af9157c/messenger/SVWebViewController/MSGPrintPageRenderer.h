//
//  MSGPrintPageRenderer.h
//  messenger
//
//  Created by Denis Kutlubaev on 19.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MSGPrintPageRenderer : UIPrintPageRenderer

@property (nonatomic) CGRect pdfRect;

@end
