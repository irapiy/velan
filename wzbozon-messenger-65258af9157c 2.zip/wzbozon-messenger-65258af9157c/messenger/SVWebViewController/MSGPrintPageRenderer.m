//
//  MSGPrintPageRenderer.m
//  messenger
//
//  Created by Denis Kutlubaev on 19.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "MSGPrintPageRenderer.h"

@implementation MSGPrintPageRenderer

- (CGRect)paperRect
{
	return self.pdfRect;
}


- (CGRect)printableRect {
	return [self paperRect];
}


- (NSInteger)numberOfPages
{
    return 1;
}

@end
