//
//  BookmarksTableViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 12.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "BookmarksTableViewController.h"
#import "WebViewController.h"
#import "MSGBrowserBookmarkItem.h"
#import "MSGBrowserHistoryItem.h"

@interface BookmarksTableViewController ()

@end

@implementation BookmarksTableViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    self.title = (self.historyMode) ? LOCS(@"History") : LOCS(@"Bookmarks");
    
    UIBarButtonItem *closeButton = [[UIBarButtonItem alloc] initWithTitle:LOCS(@"Close") style:UIBarButtonItemStyleDone target:self action:@selector(closeClicked:)];
    self.navigationItem.rightBarButtonItem = closeButton;
    
    if (self.historyMode) {
        UIBarButtonItem *clearHistoryItem = [[UIBarButtonItem alloc] initWithTitle:LOCS(@"Clear") style:UIBarButtonItemStyleBordered target:self action:@selector(clearHistoryClicked:)];
        UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        self.toolbar.items = @[self.editButtonItem, spaceItem, clearHistoryItem];
    }
    else {
        self.toolbar.items = @[self.editButtonItem];
    }
    
    self.toolbar.backgroundColor = [UIColor blackColor];
    
    [self loadData];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return (self.historyMode) ? 1 : 2;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.historyMode) {
        return [_tableData count];
    }
    else {
        return (section == 0) ? 1 : [_tableData count];
    }
    
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    if (self.historyMode) {
        MSGBrowserBookmarkItem *browserBookmarkItem = self.tableData[indexPath.row];
        cell.textLabel.text = browserBookmarkItem.name;
        cell.imageView.image = [UIImage imageNamed:@"Bookmark"];
    }
    else {
        switch (indexPath.section) {
            case 0: {
                cell.textLabel.text = LOCS(@"History");
                cell.imageView.image = [UIImage imageNamed:@"HistoryFolder"];
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                break;
            }
            case 1: {
                MSGBrowserBookmarkItem *browserBookmarkItem = self.tableData[indexPath.row];
                cell.textLabel.text = browserBookmarkItem.name;
                cell.imageView.image = [UIImage imageNamed:@"Bookmark"];
                cell.accessoryType = UITableViewCellAccessoryNone;
                break;
            }
            default:
                break;
        }
    }

    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        MSGBrowserBookmarkItem *browserBookmarkItem = self.tableData[indexPath.row];
        [browserBookmarkItem deleteFromDb];
        [self.tableData removeObjectAtIndex:indexPath.row];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ((indexPath.section == 0)&&(! self.historyMode)) return NO;
    
    return YES;
}


// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
    
}


- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.historyMode) return NO;
    
    return YES;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.historyMode) {
        MSGBrowserBookmarkItem *browserBookmarkItem = self.tableData[indexPath.row];
        [AppDel.webViewController loadAddress:browserBookmarkItem.address];
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }
    else {
        switch (indexPath.section) {
            case 0: {
                UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
                [cell setSelected:NO];
                
                BookmarksTableViewController *c = [[BookmarksTableViewController alloc] initWithNibName:@"BookmarksTableViewController" bundle:nil];
                c.historyMode = YES;
                [self.navigationController pushViewController:c animated:YES];
                break;
            }
            case 1: {
                MSGBrowserBookmarkItem *browserBookmarkItem = self.tableData[indexPath.row];
                [AppDel.webViewController loadAddress:browserBookmarkItem.address];
                [self.navigationController dismissViewControllerAnimated:YES completion:nil];
                break;
            }
            default:
                break;
        }
    }
}


#pragma mark - Other methods

- (void)closeClicked:(id)sender
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}


- (void)clearHistoryClicked:(id)sender
{
    BlockActionSheet *sheet = [[BlockActionSheet alloc] initWithTitle:nil];
    [sheet setDestructiveButtonWithTitle:LOCS(@"Clear") block:^{
        [MSGBrowserHistoryItem clearAllFromDb];
        [self loadData];
        [self setEditing:NO animated:YES];
    }];
    [sheet setCancelButtonWithTitle:LOCS(@"Cancel") block:nil];
    [sheet showInView:self.view];
}


- (void)loadData
{
    if (self.historyMode) {
        _tableData = [NSMutableArray arrayWithArray:[MSGBrowserHistoryItem retrieveFromDb]];
    }
    else {
        _tableData = [NSMutableArray arrayWithArray:[MSGBrowserBookmarkItem retrieveFromDb]];
    }
    
    [self.tableView reloadData];
}


- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    [self.tableView setEditing:editing animated:animated];
}


@end
