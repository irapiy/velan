//
//  SearchTextField.h
//  messenger
//
//  Created by Denis Kutlubaev on 04.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTextField : UITextField

@end
