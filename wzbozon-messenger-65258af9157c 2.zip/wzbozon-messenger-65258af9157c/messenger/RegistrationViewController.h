//
//  RegistrationViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 25.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EJRegistrator.h"
#import "MySQLConnection.h"

@interface RegistrationViewController : UIViewController <UITextFieldDelegate, EJRegistratorDelegate, MySQLConnectionDelegate>
{
    IBOutlet UITextField *_loginField;
    IBOutlet UIButton *_signInButton;
}

- (IBAction)signInClicked:(id)sender;

@end
