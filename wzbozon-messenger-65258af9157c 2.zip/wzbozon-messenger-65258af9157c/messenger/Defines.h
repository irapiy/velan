//
//  Defines.h
//  KIM
//
//  Created by Dennis Kutlubaev on 19.05.13.
//
//

#ifndef KIM_Defines_h
#define KIM_Defines_h

// Настройки PHP + MySQL API
#define SERVER_ON_AWS 0

#if SERVER_ON_AWS
    #define API_HOST_NAME @"http://54.229.102.236"
    #define API_PATH @"API/"
#else
    #define API_HOST_NAME @"http://localhost"
    #define API_PATH @"API/"
#endif

// Настройки Ejabberd
#if SERVER_ON_AWS
    #define EJABBERD_HOST_NAME @"ec2-54-229-102-236.eu-west-1.compute.amazonaws.com"
    #define EJABBERD_HOST_PORT 5222
    #define EJABBERD_DEFAULT_LOGIN @"admin@ec2-54-229-102-236.eu-west-1.compute.amazonaws.com"
    #define EJABBERD_DEFAULT_PASSWORD @"whiterabbit"
#else
    #define EJABBERD_HOST_NAME @"localhost"
    #define EJABBERD_HOST_PORT 5222
    #define EJABBERD_DEFAULT_LOGIN @"admin@localhost"
    #define EJABBERD_DEFAULT_PASSWORD @"admin"
#endif

#define EJABBERD_TLS 0
#define EJABBERD_CONNECTION_TIMEOUT 5




#define QuickCheck(SomeBool) { if (!(SomeBool)) { NSLog(@"Failure on line %d", __LINE__); abort(); } }

#define RGBA(rgbValue, opacity) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:opacity]

#define RGB(rgbValue) RGBA(rgbValue, 1.0)

#define REG_FONT(fsize)     [UIFont fontWithName:@"HelveticaNeue" size:fsize]
#define BOLD_FONT(fsize)    [UIFont fontWithName:@"HelveticaNeue-Bold" size:fsize]
#define MEDIUM_FONT(fsize)  [UIFont fontWithName:@"HelveticaNeue-Medium" size:fsize]

#define AppDel ((AppDelegate*)[UIApplication sharedApplication].delegate)

#define kFontTimesNewRomanPSMT @"TimesNewRomanPSMT"

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define allTrim( object ) [object stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet] ]

#define IS_WIDESCREEN [[UIScreen mainScreen] bounds].size.height >= 568

#define IPAD UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad

#define LOCS(string) NSLocalizedString(string, @"")

#define KEYBOARD_HEIGHT 216.0
#define NAVBAR_HEIGHT 44.0
#define TABBAR_HEIGHT 49.0
#define STATUS_BAR_HEIGHT 20.0

#define SCREEN_WIDTH ((([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortrait) || ([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortraitUpsideDown)) ? [[UIScreen mainScreen] bounds].size.width : [[UIScreen mainScreen] bounds].size.height)
#define SCREEN_HEIGHT ((([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortrait) || ([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortraitUpsideDown)) ? [[UIScreen mainScreen] bounds].size.height : [[UIScreen mainScreen] bounds].size.width)

#define UDKeyDefaultPage @"Default Page"
#define UDKeySoundOn @"Sound On"
#define UDKeyCurrentStatus @"Current Status"
#define UDKeyFontSize @"Font Size"
#define UDKeyFontFamily @"Font Family"
#define UDKeyFontName @"Font Name"
#define UDKeyPhone @"Login"
#define UDKeyPassword @"Password"
#define UDKeyStatuses @"Statuses"
#define UDKeyNotSentText @"Not Sent Text"
#define UDKeyDefaultBrowserItemsWereAdded @"Default Browser Items Were Added"
#define NotificationInfoKeyFrom @"From"
#define NotificationInfoKeyMessage @"Message"

#define UD_BOOL(key) [[NSUserDefaults standardUserDefaults] boolForKey:key]
#define UD_INTEGER(key) [[NSUserDefaults standardUserDefaults] integerForKey:key]
#define UD_OBJECT(key) [[NSUserDefaults standardUserDefaults] objectForKey:key]

#define INDEX_PATH(row,section) [NSIndexPath indexPathForRow:row inSection:section]

#define CONTACTS_CHANGED @"CONTACTS_CHANGED"
#define MESSAGES_CHANGED @"MESSAGES_CHANGED"
#define SETTINGS_CHANGED @"SETTINGS_CHANGED"
#define CONTACT_IS_TYPING @"CONTACT_IS_TYPING"
#define CONTACT_FINISHED_TYPING @"CONTACT_FINISHED_TYPING"
#define CONNECTION_FINISHED @"CONNECTION_FINISHED"

#define SQLITE_OK           0   /* Successful result */
/* beginning-of-error-codes */
#define SQLITE_ERROR        1   /* SQL error or missing database */
#define SQLITE_INTERNAL     2   /* Internal logic error in SQLite */
#define SQLITE_PERM         3   /* Access permission denied */
#define SQLITE_ABORT        4   /* Callback routine requested an abort */
#define SQLITE_BUSY         5   /* The database file is locked */
#define SQLITE_LOCKED       6   /* A table in the database is locked */
#define SQLITE_NOMEM        7   /* A malloc() failed */
#define SQLITE_READONLY     8   /* Attempt to write a readonly database */
#define SQLITE_INTERRUPT    9   /* Operation terminated by sqlite3_interrupt()*/
#define SQLITE_IOERR       10   /* Some kind of disk I/O error occurred */
#define SQLITE_CORRUPT     11   /* The database disk image is malformed */
#define SQLITE_NOTFOUND    12   /* Unknown opcode in sqlite3_file_control() */
#define SQLITE_FULL        13   /* Insertion failed because database is full */
#define SQLITE_CANTOPEN    14   /* Unable to open the database file */
#define SQLITE_PROTOCOL    15   /* Database lock protocol error */
#define SQLITE_EMPTY       16   /* Database is empty */
#define SQLITE_SCHEMA      17   /* The database schema changed */
#define SQLITE_TOOBIG      18   /* String or BLOB exceeds size limit */
#define SQLITE_CONSTRAINT  19   /* Abort due to constraint violation */
#define SQLITE_MISMATCH    20   /* Data type mismatch */
#define SQLITE_MISUSE      21   /* Library used incorrectly */
#define SQLITE_NOLFS       22   /* Uses OS features not supported on host */
#define SQLITE_AUTH        23   /* Authorization denied */
#define SQLITE_FORMAT      24   /* Auxiliary database format error */
#define SQLITE_RANGE       25   /* 2nd parameter to sqlite3_bind out of range */
#define SQLITE_NOTADB      26   /* File opened that is not a database file */
#define SQLITE_ROW         100  /* sqlite3_step() has another row ready */
#define SQLITE_DONE        101  /* sqlite3_step() has finished executing */
/* end-of-error-codes */

extern NSString *const EJConnectionErrorDomain;
extern NSString *const EJRegistratorErrorDomain;
extern NSString *const APIErrorDomain;
extern NSString *const ClientInfoErrorDomain;
extern NSString *const MySQLConnectionErrorDomain;

#endif
