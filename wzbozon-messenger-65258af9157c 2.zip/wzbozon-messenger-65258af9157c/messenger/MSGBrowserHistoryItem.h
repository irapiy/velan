//
//  MSGBrowserHistoryItem.h
//  messenger
//
//  Created by Denis Kutlubaev on 15.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SmartTableItem.h"

@interface MSGBrowserHistoryItem : NSObject <SmartTableItem>

@property (nonatomic) NSInteger pageID;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *address;
@property (nonatomic) NSInteger dateAdded;


- (id)initWithPageID:(NSInteger)pageID name:(NSString *)name address:(NSString *)address dateAdded:(NSInteger)dateAdded;

- (BOOL)addToDb;

- (BOOL)deleteFromDb;

+ (BOOL)clearAllFromDb;

+ (NSArray *)retrieveFromDb;


@end
