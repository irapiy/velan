//
//  DefaultPageSelectionViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 08.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "DefaultPageSelectionViewController.h"

@interface DefaultPageSelectionViewController ()

@end

@implementation DefaultPageSelectionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.label.text = LOCS(@"Select default page");
    self.textField.text = UD_OBJECT(UDKeyDefaultPage);
    [self.textField becomeFirstResponder];
}


#pragma mark - UITextFieldDelegate


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSString *regex = @"http://www.+[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    if (! [test evaluateWithObject:textField.text]) {
        
        [SVProgressHUD showErrorWithStatus:@"Incorrect address, try again."];
        return NO;
        
    }
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:allTrim(textField.text) forKey:UDKeyDefaultPage];
    [ud synchronize];
    
    [self.navigationController popViewControllerAnimated:YES];
    return NO;
}

@end
