//
//  DocumentsTableViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 04.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DocumentPickerDelegate;

@interface DocumentPickerController : UITableViewController

@property (nonatomic, unsafe_unretained) id <DocumentPickerDelegate> delegate;

@end


@protocol DocumentPickerDelegate <NSObject>

- (void)documentPicker:(DocumentPickerController *)documentPicker didPickItem:(NSString *)item;

@end