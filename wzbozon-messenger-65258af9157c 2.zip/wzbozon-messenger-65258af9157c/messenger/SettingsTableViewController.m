//
//  SettingsTableViewController.m
//  messenger
//
//  Created by Denis Kutlubaev on 27.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import "SettingsTableViewController.h"
#import "WhatsNewTableViewController.h"
#import "DocumentPickerController.h"
#import "DefaultPageSelectionViewController.h"
#import "StatusesTableViewController.h"

@interface SettingsTableViewController ()
{
    UIPopoverController *_popoverController;
}
@end


@implementation SettingsTableViewController

+ (void) load {
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    
    if ([ud objectForKey:UDKeyDefaultPage] == nil) [ud setObject:@"http://www.google.com" forKey:UDKeyDefaultPage];
    
    if ([ud objectForKey:UDKeySoundOn] == nil) [ud setBool:YES forKey:UDKeySoundOn];
    
    if ([ud objectForKey:UDKeyCurrentStatus] == nil) [ud setObject:LOCS(@"Available") forKey:UDKeyCurrentStatus];
    
    if ([ud objectForKey:UDKeyStatuses] == nil) {
        NSMutableArray *items = [[NSMutableArray alloc] init];
        [items addObject:LOCS(@"Available")];
        [items addObject:LOCS(@"Busy")];
        [items addObject:LOCS(@"Sleeping")];
        [items addObject:LOCS(@"Only on business")];
        [items addObject:LOCS(@"Open for proposals")];
        [ud setObject:items forKey:UDKeyStatuses];
    }
    
    [ud synchronize];
}


- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"19-gear_active"]
                      withFinishedUnselectedImage:[UIImage imageNamed:@"19-gear"]];
        self.title = LOCS(@"Settings");
        
    }
    return self;
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.tableView reloadData];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 1;
            break;
        case 1:
            return 1;
            break;
        case 2:
            return 2;
            break;
        case 3:
            return 1;
            break;
        default:
            break;
    }
    
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        
    }
    
    switch (indexPath.section) {
        case 0: {
            cell.textLabel.text = LOCS(@"Status");
            cell.detailTextLabel.text = UD_OBJECT(UDKeyCurrentStatus);
            break;
        }
        case 1:
            cell.textLabel.text = LOCS(@"Documents");
            break;
        case 2: {
            if (indexPath.row == 0) {
                cell.textLabel.text = LOCS(@"Default Page");
                cell.detailTextLabel.text = UD_OBJECT(UDKeyDefaultPage);
            }
            else if (indexPath.row == 1) {
                
                cell.textLabel.text = LOCS(@"Sounds");
                cell.detailTextLabel.text = nil;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                UISwitch *soundSwitcher = [[UISwitch alloc] init];
                cell.accessoryView = soundSwitcher;
                [soundSwitcher addTarget:self action:@selector(switchSound:) forControlEvents:UIControlEventValueChanged];
                soundSwitcher.on = UD_BOOL(UDKeySoundOn);
            }
            break;
        }
        case 3:
            cell.textLabel.text = LOCS(@"Release Notes");
            break;
        default:
            break;
    }
    
    
    return cell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case 0:
            [self showStatusesView];
            break;
        case 1:
            [self showFilesView];
            break;
        case 2: {
            if (indexPath.row == 0) {
                [self showDefaultPageSelection];
            }
            else if (indexPath.row == 1) {
                
            }
            break;
        }
        case 3:
            [self showWhatsNewPopup];
            break;
        default:
            break;
    }
}


#pragma mark - Other methods

- (void)switchSound:(id)sender
{
    UISwitch *switcher = (UISwitch *)sender;
    [[NSUserDefaults standardUserDefaults] setBool:switcher.on forKey:UDKeySoundOn];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


- (void)showWhatsNewPopup
{
    WhatsNewTableViewController *whatsNewTableViewController = [[WhatsNewTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
    
    if ( IPAD ) {
        [whatsNewTableViewController setContentSizeForViewInPopover:CGSizeMake(320, 548)];
        
        _popoverController = [[UIPopoverController alloc]
                              initWithContentViewController:whatsNewTableViewController];
        [_popoverController presentPopoverFromRect:CGRectMake(self.view.center.x, self.view.center.y, 1, 1) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }
    else {
        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:whatsNewTableViewController];
        [self presentViewController:navigationController animated:YES completion:nil];
    }
    
}


- (void)showFilesView
{
    DocumentPickerController *c = [[DocumentPickerController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:c animated:YES];
}


- (void)showDefaultPageSelection
{
    DefaultPageSelectionViewController *c = [[DefaultPageSelectionViewController alloc] initWithNibName:@"DefaultPageSelectionViewController" bundle:nil];
    [self.navigationController pushViewController:c animated:YES];
}


- (void)showStatusesView
{
    StatusesTableViewController *c = [[StatusesTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:c animated:YES];
}


@end
