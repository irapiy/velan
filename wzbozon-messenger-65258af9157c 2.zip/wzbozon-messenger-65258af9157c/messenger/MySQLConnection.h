//
//  MySQLConnection.h
//  messenger
//
//  Created by Denis Kutlubaev on 30.07.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.

// Класс предназначен для работы с базой данных MySQL на сервере через PHP API

#import <Foundation/Foundation.h>
#import "AFHTTPClient.h"
#import "AFNetworking.h"

typedef void (^JSONResponseBlock)(NSDictionary* json);


@protocol MySQLConnectionDelegate <NSObject>

- (void)userDidLogin;

- (void)userFailedToLogin;

- (void)userDidRegister;

- (void)userFailedToRegister;

@end


@interface MySQLConnection : AFHTTPClient

@property (unsafe_unretained, nonatomic) id <MySQLConnectionDelegate> delegate;

+ (MySQLConnection *)shared;

- (BOOL)isAuthorized;

- (void)commandWithParams:(NSMutableDictionary*)params onCompletion:(JSONResponseBlock)completionBlock;

- (NSURL*)urlForImageWithId:(NSNumber*)IdPhoto isThumb:(BOOL)isThumb;

- (void)registerUserWithDelegate:(id <MySQLConnectionDelegate>)delegate;

- (void)loginUserWithDelegate:(id <MySQLConnectionDelegate>)delegate;


@end
