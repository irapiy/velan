//
//  Common.h
//  Nanotechnology
//
//  Created by Denis Kutlubaev on 02.02.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Common : NSObject

void drawLinearGradient(CGContextRef context, CGRect rect, CGColorRef startColor,
                        CGColorRef  endColor);

CGRect rectFor1PxStroke(CGRect rect);

void draw1PxStroke(CGContextRef context, CGPoint startPoint, CGPoint endPoint,
                   CGColorRef color);

+ (UIImage *)backgroundGradientImageWithSize:(CGSize)size;

@end
