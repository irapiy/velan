//
//  SettingsTableViewController.h
//  messenger
//
//  Created by Denis Kutlubaev on 27.06.13.
//  Copyright (c) 2013 Alwawee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsTableViewController : UITableViewController

@end
